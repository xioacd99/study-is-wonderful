import Foundation
import AppKit
import Darwin
import UserNotifications

let userHome = NSHomeDirectory()
let herdrAppHome = ProcessInfo.processInfo.environment["HERDR_APP_HOME"] ?? "\(userHome)/.config/herdr-app"
let herdrAppCli = "\(userHome)/.local/bin/herdr-app"

struct Options {
    var title: String?
    var subtitle: String = ""
    var body: String = ""
    var group: String?
    var terminal: String = ""
    var pane: String = ""
    var imagePath: String?
    var authTest: Bool = false
    var raiseTest: Bool = false

    static func parse(_ args: [String]) -> Options {
        var opts = Options()
        var i = 1
        while i < args.count {
            let flag = args[i]
            switch flag {
            case "--title":
                if i + 1 < args.count { opts.title = args[i + 1]; i += 1 }
            case "--subtitle":
                if i + 1 < args.count { opts.subtitle = args[i + 1]; i += 1 }
            case "--body":
                if i + 1 < args.count { opts.body = args[i + 1]; i += 1 }
            case "--group":
                if i + 1 < args.count { opts.group = args[i + 1]; i += 1 }
            case "--terminal":
                if i + 1 < args.count { opts.terminal = args[i + 1]; i += 1 }
            case "--pane":
                if i + 1 < args.count { opts.pane = args[i + 1]; i += 1 }
            case "--image":
                if i + 1 < args.count { opts.imagePath = args[i + 1]; i += 1 }
            case "--auth-test":
                opts.authTest = true
            case "--raise-test":
                opts.raiseTest = true
            default:
                break
            }
            i += 1
        }
        if opts.authTest {
            if opts.title == nil { opts.title = "✅ Herdr 通知已就绪" }
            if opts.subtitle.isEmpty { opts.subtitle = "系统横幅通知已启用" }
            if opts.body.isEmpty { opts.body = "点击此横幅可直接切回 Herdr 并定位到对应 Agent。" }
            if opts.group == nil { opts.group = "herdr-auth-test" }
        }
        return opts
    }
}

@discardableResult
func runTool(_ executable: String, _ arguments: [String]) -> Int32 {
    let task = Process()
    task.executableURL = URL(fileURLWithPath: executable)
    task.arguments = arguments
    task.standardOutput = FileHandle.nullDevice
    task.standardError = FileHandle.nullDevice
    do {
        try task.run()
        task.waitUntilExit()
        return task.terminationStatus
    } catch {
        return -1
    }
}

@discardableResult
func sendHerdrRaiseSocket() -> Bool {
    let sockPath = "\(herdrAppHome)/herdr-app.sock"
    let fd = Darwin.socket(AF_UNIX, SOCK_STREAM, 0)
    guard fd >= 0 else { return false }
    defer { Darwin.close(fd) }

    var tv = timeval(tv_sec: 1, tv_usec: 0)
    let tvSize = socklen_t(MemoryLayout<timeval>.size)
    Darwin.setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, tvSize)
    Darwin.setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, tvSize)

    var addr = sockaddr_un()
    addr.sun_len = UInt8(MemoryLayout<sockaddr_un>.size)
    addr.sun_family = sa_family_t(AF_UNIX)
    let maxLen = MemoryLayout.size(ofValue: addr.sun_path)
    guard sockPath.utf8.count < maxLen else { return false }
    _ = sockPath.withCString { cstr in
        withUnsafeMutablePointer(to: &addr.sun_path) { ptr in
            ptr.withMemoryRebound(to: CChar.self, capacity: maxLen) { dst in
                strncpy(dst, cstr, maxLen - 1)
            }
        }
    }

    let addrLen = socklen_t(MemoryLayout<sockaddr_un>.size)
    let connected = withUnsafePointer(to: &addr) { ptr in
        ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
            Darwin.connect(fd, sa, addrLen)
        }
    }
    guard connected == 0 else { return false }

    let payload = "{\"raise\":true}\n"
    let sent = payload.withCString { cstr in
        Darwin.send(fd, cstr, strlen(cstr), 0)
    }
    guard sent > 0 else { return false }

    var buf = [UInt8](repeating: 0, count: 256)
    _ = Darwin.recv(fd, &buf, buf.count, 0)
    return true
}

func focusHerdr(terminal: String, pane: String) {
    var focused = false
    if !terminal.isEmpty {
        let code = runTool(herdrAppCli, ["do", "agent.focus", "--terminal", terminal])
        focused = (code == 0)
    }
    if !focused && !pane.isEmpty {
        runTool(herdrAppCli, ["do", "pane.focus", "--pane", pane])
    }

    if let running = NSRunningApplication.runningApplications(withBundleIdentifier: "dev.herdr.app").first {
        DispatchQueue.main.async {
            if running.isHidden {
                running.unhide()
            }
            running.activate(options: .activateIgnoringOtherApps)
        }
        sendHerdrRaiseSocket()
    } else {
        let userApp = "\(userHome)/Applications/Herdr.app"
        let appPath = FileManager.default.fileExists(atPath: userApp) ? userApp : "/Applications/Herdr.app"
        runTool("/usr/bin/open", ["-a", appPath])
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, UNUserNotificationCenterDelegate {
    let options: Options
    var idleTimer: Timer?
    var safetyTimer: Timer?

    init(options: Options) {
        self.options = options
        super.init()
    }

    func applicationWillFinishLaunching(_ notification: Notification) {
        UNUserNotificationCenter.current().delegate = self
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        if options.raiseTest {
            DispatchQueue.global(qos: .userInitiated).async {
                focusHerdr(terminal: "", pane: "")
                print("RAISE_OK")
                fflush(stdout)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    exit(0)
                }
            }
            return
        }

        if let title = options.title, !title.isEmpty {
            postNotification(title: title)
        } else {
            // Launched by Notification Center when user clicked a delivered banner.
            idleTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { _ in
                NSApp.terminate(nil)
            }
        }
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .list])
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        DispatchQueue.main.async {
            self.idleTimer?.invalidate()
            self.idleTimer = nil
        }

        let userInfo = response.notification.request.content.userInfo
        let terminal = (userInfo["terminal"] as? String) ?? ""
        let pane = (userInfo["pane"] as? String) ?? ""

        DispatchQueue.global(qos: .userInitiated).async {
            focusHerdr(terminal: terminal, pane: pane)
            DispatchQueue.main.async {
                completionHandler()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    NSApp.terminate(nil)
                }
            }
        }
    }

    private func postNotification(title: String) {
        safetyTimer = Timer.scheduledTimer(withTimeInterval: 25.0, repeats: false) { _ in
            fputs("TIMEOUT: notification authorization or delivery timed out\n", stderr)
            fflush(stderr)
            exit(3)
        }

        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert]) { granted, error in
            guard granted else {
                let msg = error?.localizedDescription ?? "permission denied"
                fputs("DENIED: \(msg)\n", stderr)
                fflush(stderr)
                exit(2)
            }

            let content = UNMutableNotificationContent()
            content.title = title
            if !self.options.subtitle.isEmpty {
                content.subtitle = self.options.subtitle
            }
            if !self.options.body.isEmpty {
                content.body = self.options.body
            }
            content.sound = nil
            content.userInfo = [
                "terminal": self.options.terminal,
                "pane": self.options.pane
            ]

            if let imagePath = self.options.imagePath,
               !imagePath.isEmpty,
               FileManager.default.fileExists(atPath: imagePath) {
                let ext = URL(fileURLWithPath: imagePath).pathExtension
                let extSuffix = ext.isEmpty ? "png" : ext
                let tempURL = FileManager.default.temporaryDirectory
                    .appendingPathComponent("herdr-notify-\(UUID().uuidString).\(extSuffix)")
                do {
                    try FileManager.default.copyItem(at: URL(fileURLWithPath: imagePath), to: tempURL)
                    let attachment = try UNNotificationAttachment(identifier: "icon", url: tempURL, options: nil)
                    content.attachments = [attachment]
                } catch {
                    // Proceed without attachment if copy/attachment fails.
                }
            }

            let identifier = (self.options.group?.isEmpty == false) ? self.options.group! : UUID().uuidString
            let request = UNNotificationRequest(identifier: identifier, content: content, trigger: nil)
            center.add(request) { addError in
                if let addError = addError {
                    fputs("ERROR: \(addError.localizedDescription)\n", stderr)
                    fflush(stderr)
                    exit(1)
                }
                print("OK")
                fflush(stdout)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                    exit(0)
                }
            }
        }
    }
}

let app = NSApplication.shared
app.setActivationPolicy(.accessory)
let opts = Options.parse(CommandLine.arguments)
let delegate = AppDelegate(options: opts)
app.delegate = delegate
app.run()
