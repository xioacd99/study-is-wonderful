#!/usr/bin/env bun
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";

const CHROME_PATH = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const DATA_DIR = import.meta.dir;
const MAX_CACHED_PNGS = 60;

function parseArgs(argv) {
  const args = { theme: "dark", bg: null, outDir: DATA_DIR, file: null, codeB64: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--theme" && argv[i + 1]) args.theme = argv[++i];
    else if (a === "--bg" && argv[i + 1]) args.bg = argv[++i];
    else if (a === "--out-dir" && argv[i + 1]) args.outDir = argv[++i];
    else if (a === "--file" && argv[i + 1]) args.file = argv[++i];
    else if (a === "--code-b64" && argv[i + 1]) args.codeB64 = argv[++i];
  }
  args.theme = args.theme === "light" ? "light" : "dark";
  if (!args.bg) args.bg = args.theme === "dark" ? "#18181b" : "#ffffff";
  return args;
}

async function readCode(args) {
  if (args.codeB64) {
    return Buffer.from(args.codeB64, "base64").toString("utf8");
  }
  if (args.file) {
    return fs.readFileSync(args.file, "utf8");
  }
  return await Bun.stdin.text();
}

function resolveMermaidScript() {
  const candidates = [
    path.join(DATA_DIR, "node_modules/mermaid/dist/mermaid.min.js"),
    path.join(DATA_DIR, "node_modules/mermaid/dist/mermaid.js"),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  throw new Error("mermaid bundle not found under " + path.join(DATA_DIR, "node_modules/mermaid/dist"));
}

function buildHtml({ code, theme, bg, mermaidJsPath }) {
  const safeBg = /^#[0-9a-fA-F]{3,8}$/.test(bg) ? bg : (theme === "dark" ? "#18181b" : "#ffffff");
  const safeCodeJson = JSON.stringify(code).replace(/<\/script/gi, "<\\/script");
  const mermaidTheme = theme === "dark" ? "dark" : "default";
  const fontFamily = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif';
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<style>
  * { box-sizing: border-box; }
  html, body {
    margin: 0;
    padding: 0;
    background: ${safeBg};
    font-family: ${fontFamily};
    overflow: hidden;
  }
  #container {
    display: inline-block;
    padding: 24px;
    background: ${safeBg};
  }
  #container svg {
    display: block;
    max-width: none !important;
  }
</style>
<script src="file://${mermaidJsPath}"></script>
</head>
<body>
<div id="container"></div>
<script>
(async () => {
  try {
    const code = ${safeCodeJson};
    mermaid.initialize({
      startOnLoad: false,
      theme: ${JSON.stringify(mermaidTheme)},
      securityLevel: "loose",
      flowchart: { htmlLabels: true },
      themeVariables: { fontFamily: ${JSON.stringify(fontFamily)} }
    });
    const { svg, bindFunctions } = await mermaid.render("mermaid-svg", code);
    const container = document.getElementById("container");
    container.innerHTML = svg;
    if (bindFunctions) bindFunctions(container);
    const svgEl = container.querySelector("svg");
    const rect = (svgEl || container).getBoundingClientRect();
    window.__MERMAID_DONE__ = {
      ok: true,
      width: Math.max(100, Math.ceil(rect.width)),
      height: Math.max(80, Math.ceil(rect.height))
    };
  } catch (err) {
    window.__MERMAID_DONE__ = {
      ok: false,
      error: err && err.message ? err.message : String(err)
    };
  }
})();
</script>
</body>
</html>
`;
}

function pruneCache(outDir) {
  try {
    const pngs = fs.readdirSync(outDir)
      .filter((f) => f.endsWith(".png"))
      .map((f) => {
        const full = path.join(outDir, f);
        return { name: f, full, mtime: fs.statSync(full).mtimeMs };
      })
      .sort((a, b) => b.mtime - a.mtime);
    for (const item of pngs.slice(MAX_CACHED_PNGS)) {
      const stem = item.name.slice(0, -4);
      for (const ext of [".png", ".meta.json", ".html"]) {
        try { fs.unlinkSync(path.join(outDir, stem + ext)); } catch {}
      }
    }
  } catch {}
}

function createCdpClient(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let nextId = 1;
    const pending = new Map();

    ws.addEventListener("open", () => {
      resolve({
        call(method, params = {}, sessionId = undefined) {
          const id = nextId++;
          return new Promise((res, rej) => {
            pending.set(id, { res, rej });
            const payload = sessionId ? { id, method, params, sessionId } : { id, method, params };
            ws.send(JSON.stringify(payload));
          });
        },
        close() {
          try { ws.close(); } catch {}
        },
      });
    });

    ws.addEventListener("message", (event) => {
      const msg = JSON.parse(String(event.data));
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) rej(new Error(msg.error.message || JSON.stringify(msg.error)));
        else res(msg.result);
      }
    });

    ws.addEventListener("error", (err) => {
      reject(new Error("CDP WebSocket error: " + (err?.message || "connection failed")));
    });
  });
}

async function waitForWsUrl(proc, timeoutMs = 10000) {
  const decoder = new TextDecoder();
  const reader = proc.stderr.getReader();
  let buf = "";
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    const remaining = Math.max(50, deadline - Date.now());
    const chunk = await Promise.race([
      reader.read(),
      new Promise((_, rej) => setTimeout(() => rej(new Error("Timed out waiting for Chrome DevTools")), remaining)),
    ]);
    if (chunk.done) break;
    buf += decoder.decode(chunk.value, { stream: true });
    const m = buf.match(/DevTools listening on (ws:\/\/[^\s]+)/);
    if (m) return m[1];
  }
  throw new Error("Chrome failed to report DevTools WebSocket URL: " + buf.slice(0, 400));
}

async function renderWithChrome({ htmlPath, pngPath }) {
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), "herdr-mermaid-chrome-"));
  const proc = Bun.spawn(
    [
      CHROME_PATH,
      "--headless=new",
      "--disable-gpu",
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--allow-file-access-from-files",
      "--remote-debugging-port=0",
      `--user-data-dir=${userDataDir}`,
      "about:blank",
    ],
    { stdout: "ignore", stderr: "pipe" },
  );

  let client = null;
  try {
    const wsUrl = await waitForWsUrl(proc);
    client = await createCdpClient(wsUrl);
    const { targetId } = await client.call("Target.createTarget", { url: "about:blank" });
    const { sessionId } = await client.call("Target.attachToTarget", { targetId, flatten: true });
    await client.call("Page.enable", {}, sessionId);
    await client.call("Runtime.enable", {}, sessionId);
    await client.call("Page.navigate", { url: `file://${htmlPath}` }, sessionId);

    let done = null;
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline) {
      const evalRes = await client.call("Runtime.evaluate", {
        expression: "window.__MERMAID_DONE__ || null",
        returnByValue: true,
      }, sessionId);
      if (evalRes?.result?.value) {
        done = evalRes.result.value;
        break;
      }
      await Bun.sleep(40);
    }

    if (!done) throw new Error("Mermaid render timed out in headless Chrome");
    if (!done.ok) throw new Error(done.error || "Mermaid syntax error");

    const width = Math.ceil(done.width + 48);
    const height = Math.ceil(done.height + 48);

    await client.call("Emulation.setDeviceMetricsOverride", {
      width,
      height,
      deviceScaleFactor: 2,
      mobile: false,
    }, sessionId);
    await Bun.sleep(40);

    const shot = await client.call("Page.captureScreenshot", {
      format: "png",
      fromSurface: true,
    }, sessionId);
    fs.writeFileSync(pngPath, Buffer.from(shot.data, "base64"));
    return { width, height };
  } finally {
    client?.close();
    try { proc.kill(); } catch {}
    await proc.exited.catch(() => {});
    try { fs.rmSync(userDataDir, { recursive: true, force: true }); } catch {}
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const code = (await readCode(args)).trim();
  if (!code) throw new Error("Empty Mermaid input");

  fs.mkdirSync(args.outDir, { recursive: true });
  const shortHash = crypto
    .createHash("sha256")
    .update(JSON.stringify({ code, theme: args.theme, bg: args.bg }))
    .digest("hex")
    .slice(0, 16);
  const key = `${shortHash}-${args.theme}`;
  const pngPath = path.join(args.outDir, `${key}.png`);
  const metaPath = path.join(args.outDir, `${key}.meta.json`);
  const htmlPath = path.join(args.outDir, `${key}.html`);
  const relPath = `data/mermaid-viewer/${key}.png`;

  if (fs.existsSync(pngPath) && fs.existsSync(metaPath) && fs.existsSync(htmlPath)) {
    try {
      const meta = JSON.parse(fs.readFileSync(metaPath, "utf8"));
      if (meta?.width && meta?.height) {
        console.log(JSON.stringify({ relPath, absPath: pngPath, htmlPath, width: meta.width, height: meta.height, cached: true }));
        return;
      }
    } catch {}
  }

  const mermaidJsPath = resolveMermaidScript();
  fs.writeFileSync(htmlPath, buildHtml({ code, theme: args.theme, bg: args.bg, mermaidJsPath }), "utf8");

  const { width, height } = await renderWithChrome({ htmlPath, pngPath });
  fs.writeFileSync(metaPath, JSON.stringify({ width, height }), "utf8");
  pruneCache(args.outDir);

  console.log(JSON.stringify({ relPath, absPath: pngPath, htmlPath, width, height, cached: false }));
}

main().catch((err) => {
  console.error(err?.message || String(err));
  process.exit(1);
});
