#!/usr/bin/env node
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const EMOJI_PALETTE = ["🦊", "🐙", "🐝", "🦉", "⚡", "🧩", "🚀", "🔮", "🐬", "🦋", "🎯", "🌟", "🐼", "🦄"];
const ROLE_EMOJI_RULES = [
  [/\b(ui|design\w*|icon|image|style|css|layout|paint)\b/i, "🎨"],
  [/\b(test\w*|qa|verif\w*|replay|check\w*|spec)\b/i, "🧪"],
  [/\b(review\w*|lint|critique)\b/i, "🔎"],
  [/\b(research\w*|explor\w*|search\w*|grep|find|audit\w*|inspect\w*|scan\w*)\b/i, "🔍"],
  [/\b(doc\w*|writ\w*|note|summary|report|readme)\b/i, "📝"],
  [/\b(monitor\w*|watch\w*|stall|observ\w*|health)\b/i, "👀"],
  [/\b(plan\w*|architect\w*|coord\w*|orchestr\w*)\b/i, "🧭"],
  [/\b(build\w*|fix\w*|code|impl\w*|patch\w*|refactor\w*|dev|edit\w*)\b/i, "⚙️"],
];

const GENERIC_CHILD_NAMES = new Set(["research", "self", "agent", "worker", "subagent", "image-generator"]);
const GENERIC_KEYWORD_STOP = new Set(["please", "you", "the", "this", "scope", "review", "read", "fix", "check", "analyze", "inspect", "current", "only"]);

const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
const MAX_RECENT_EVENTS = 25;
const CODEX_WORKING_IDLE_MS = 180_000;
const AGY_WORKING_IDLE_MS = 60_000;
const STATUS_RANK = { working: 0, pending: 1, done: 2 };

function normalizePath(p) {
  if (!p || typeof p !== "string") return "";
  const trimmed = p.trim();
  if (!trimmed) return "";
  return trimmed.replace(/\/+$/, "") || "/";
}

function unwrapQuoted(value) {
  if (value === null || value === undefined) return "";
  let s = typeof value === "string" ? value : JSON.stringify(value);
  s = s.trim();
  for (let i = 0; i < 2; i++) {
    if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
      try {
        const parsed = JSON.parse(s);
        if (typeof parsed === "string") {
          s = parsed.trim();
          continue;
        }
      } catch {
        s = s.slice(1, -1).trim();
        continue;
      }
    }
    break;
  }
  return s;
}

function isConversationalPrompt(raw) {
  const s = String(raw || "").trim();
  if (!s) return false;
  if (/^(我们现在|我有一个|请帮我|帮我|你试试|给我的|我想|能否)/.test(s)) return true;
  if (s.length > 16 && /[，。？！]/.test(s)) return true;
  return false;
}

function extractPromptKeyword(prompt) {
  const s = String(prompt || "").trim();
  const m = s.match(/^([A-Za-z][A-Za-z0-9_-]{1,12})\b/);
  if (!m) return "";
  const token = m[1];
  if (GENERIC_KEYWORD_STOP.has(token.toLowerCase())) return "";
  return token;
}

function shortenName(raw, maxLen = 24) {
  if (!raw) return "agent";
  let s = String(raw)
    .replace(/<\/?USER_REQUEST>/gi, " ")
    .trim()
    .replace(/^\/(swarm|plan|goal|grill-me|teamwork|boost)\b/i, " ")
    .replace(/\s+/g, " ")
    .trim();

  const workerMatch = s.match(/^(?:[A-Za-z]+\s+)?Worker\s+the\s+(\d+)(?:st|nd|rd|th)?$/i);
  if (workerMatch) return `Worker #${workerMatch[1]}`;
  if (/^(?:[A-Za-z]+\s+)?Worker$/i.test(s)) return "Worker";

  s = s
    .replace(/^(please\s+|help\s+me\s+|can\s+you\s+)/i, "")
    .replace(/^(你是|请帮我|帮我|请)/, "")
    .trim();

  const firstLine = s.split(/[\r\n]+/)[0].trim();
  s = firstLine || s;
  if (s.length <= maxLen) return s || "agent";
  return s.slice(0, Math.max(1, maxLen - 1)).trimEnd() + "…";
}

function pickEmoji(name, role = "", id = "") {
  const combined = `${name || ""} ${role || ""}`.trim();
  for (const [pattern, emoji] of ROLE_EMOJI_RULES) {
    if (pattern.test(combined)) return emoji;
  }
  const seed = id || combined || "agent";
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return EMOJI_PALETTE[hash % EMOJI_PALETTE.length];
}

function summarizeArgs(rawArgs, maxLen = 36) {
  if (rawArgs === null || rawArgs === undefined) return "";
  let obj = null;
  if (typeof rawArgs === "string") {
    const trimmed = rawArgs.trim();
    if (!trimmed) return "";
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) obj = parsed;
    } catch {
      return shortenName(trimmed, maxLen);
    }
  } else if (typeof rawArgs === "object" && !Array.isArray(rawArgs)) {
    obj = rawArgs;
  }

  if (obj) {
    const keys = [
      "CommandLine",
      "command",
      "cmd",
      "Path",
      "path",
      "file_path",
      "query",
      "Role",
      "name",
      "action",
      "toolSummary",
      "Description",
    ];
    for (const k of keys) {
      if (obj[k] !== undefined && obj[k] !== null) {
        const val = unwrapQuoted(obj[k]);
        if (val) return shortenName(val, maxLen);
      }
    }
    for (const val of Object.values(obj)) {
      const s = unwrapQuoted(val);
      if (s) return shortenName(s, maxLen);
    }
  }
  return "";
}

function wouldCreateCycle(parent, childId, nodeMap) {
  let curr = parent;
  const visited = new Set([childId]);
  while (curr) {
    if (visited.has(curr.id)) return true;
    visited.add(curr.id);
    curr = curr.parentId ? nodeMap.get(curr.parentId) : undefined;
  }
  return false;
}

function sortNodes(nodes) {
  nodes.sort((a, b) => {
    const d = (STATUS_RANK[a.status] ?? 2) - (STATUS_RANK[b.status] ?? 2);
    if (d !== 0) return d;
    return (b.updatedAt ?? 0) - (a.updatedAt ?? 0);
  });
  for (const n of nodes) {
    if (n.children && n.children.length > 0) sortNodes(n.children);
  }
  return nodes;
}

function collectCodexJsonl(rootDir, cutoffMs) {
  if (!fs.existsSync(rootDir)) return [];
  const results = [];
  const stack = [rootDir];
  while (stack.length > 0) {
    const dir = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        stack.push(fullPath);
      } else if (entry.isFile() && entry.name.endsWith(".jsonl")) {
        try {
          const st = fs.statSync(fullPath);
          if (st.mtimeMs >= cutoffMs) results.push({ filePath: fullPath, mtimeMs: st.mtimeMs, size: st.size });
        } catch {
          // ignore
        }
      }
    }
  }
  return results;
}

const GENERIC_SCOPE_DIRS = new Set(["out", "app", "src", "build", "dist", "tmp", "explore", "agents", "work", "workspace"]);

function isPathWithin(childPath, rootPath) {
  const c = normalizePath(childPath);
  const r = normalizePath(rootPath);
  return Boolean(c && r && (c === r || c.startsWith(`${r}/`)));
}

function nodeOrDescendantMatchesCwd(node, normCwd) {
  if (normalizePath(node.cwd) === normCwd) return true;
  for (const c of node.children ?? []) {
    if (nodeOrDescendantMatchesCwd(c, normCwd)) return true;
  }
  return false;
}

function tokenizeHint(raw) {
  return String(raw || "")
    .toLowerCase()
    .split(/[\s/\\:·,|()\[\]\-_]+/)
    .filter((t) => t.length >= 2);
}

const CODEX_SESSION_INDEX_PATH = path.join(os.homedir(), ".codex", "session_index.jsonl");

function loadCodexSessionIndex() {
  const map = new Map();
  if (!fs.existsSync(CODEX_SESSION_INDEX_PATH)) return map;
  let raw;
  try {
    raw = fs.readFileSync(CODEX_SESSION_INDEX_PATH, "utf8");
  } catch {
    return map;
  }
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const obj = JSON.parse(line);
      if (obj && typeof obj.id === "string" && typeof obj.thread_name === "string" && obj.thread_name.trim()) {
        map.set(obj.id, obj.thread_name.trim());
      }
    } catch {
      // ignore corrupt line
    }
  }
  return map;
}

function normalizeCodexTitle(raw) {
  return String(raw || "")
    .trim()
    .replace(/^[^\p{L}\p{N}]+/u, "")
    .replace(/\s+\|\s+[^|]+$/, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function isRawCliTitle(raw) {
  const s = String(raw || "").trim();
  if (!s) return true;
  if (/^[~/]|^[A-Za-z]:\\/.test(s)) return true;
  if (/\s--?[a-z0-9]/i.test(s)) return true;
  if (/^(agy|antigravity|codex|claude|opencode|gemini|zsh|bash|fish)\b/i.test(s) && !s.includes("|")) return true;
  return false;
}

function countTokenHits(tokens, haystack) {
  if (!tokens || tokens.length === 0 || !haystack) return 0;
  let hits = 0;
  for (const tok of tokens) {
    if (haystack.includes(tok)) hits++;
  }
  return hits;
}

function extractSlotFromText(text) {
  const s = String(text || "");
  const m = s.match(/\/(?:explore|runs?)\/([^/\s"']+)\/agents\/([^/\s"']+)\//i);
  if (m) return { runId: m[1], agentSlot: m[2] };
  const fb = s.match(/\/agents\/((?:agent|worker|subagent)[-_]?\d+|[a-z0-9_-]+-\d+)\//i);
  if (fb) return { runId: undefined, agentSlot: fb[1] };
  return { runId: undefined, agentSlot: undefined };
}

function extractSeedQuery(text) {
  const m = String(text || "").match(/"seed_query"\s*:\s*"((?:[^"\\]|\\.)*)"/);
  if (!m) return "";
  try {
    return JSON.parse(`"${m[1]}"`).trim();
  } catch {
    return m[1].trim();
  }
}

function cleanExecPrompt(text, seedQuery) {
  let cleaned = String(text || "")
    .replace(/<image\b[^>]*>[\s\S]*?<\/image>/gi, " ")
    .replace(/Codex could not read the local image[^\n]*\n?/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (seedQuery && !cleaned.startsWith(seedQuery)) {
    cleaned = `${seedQuery}${cleaned ? `\n${cleaned}` : ""}`;
  }
  const out = cleaned || String(text || "").trim();
  return out.length > 1500 ? `${out.slice(0, 1500)}…` : out;
}

function extractScopeTokens(cwd, runId, normCwd) {
  const tokens = [];
  const c = normalizePath(cwd);
  if (c && normCwd && c.startsWith(`${normCwd}/`)) {
    const rel = c.slice(normCwd.length).replace(/^\/+/, "");
    for (const seg of rel.split("/")) {
      const low = seg.toLowerCase();
      if (low.length >= 2 && !GENERIC_SCOPE_DIRS.has(low)) {
        tokens.push(low);
      }
    }
  }
  if (runId) tokens.push(String(runId).toLowerCase());
  return [...new Set(tokens)];
}

function parseEtimeMs(raw) {
  const s = String(raw || "").trim();
  if (!s) return 0;
  let days = 0;
  let timePart = s;
  const dashIdx = s.indexOf("-");
  if (dashIdx !== -1) {
    days = parseInt(s.slice(0, dashIdx), 10) || 0;
    timePart = s.slice(dashIdx + 1);
  }
  const parts = timePart.split(":").map((x) => parseInt(x, 10) || 0);
  let hours = 0;
  let mins = 0;
  let secs = 0;
  if (parts.length === 3) [hours, mins, secs] = parts;
  else if (parts.length === 2) [mins, secs] = parts;
  else if (parts.length === 1) [secs] = parts;
  return (((days * 24 + hours) * 60 + mins) * 60 + secs) * 1000;
}

function parseFlagValue(cmd, flag) {
  const esc = escapeRegExp(flag);
  const re = new RegExp(`(?:^|\\s)${esc}(?:=|\\s+)(?:"([^"]+)"|'([^']+)'|(\\S+))`);
  const m = String(cmd || "").match(re);
  return m ? (m[1] || m[2] || m[3] || "").trim() : "";
}

function shortHash(raw) {
  let hash = 0;
  const s = String(raw || "");
  for (let i = 0; i < s.length; i++) {
    hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

function scanLiveCodexProcesses() {
  let out = "";
  try {
    out = execFileSync("ps", ["-eo", "pid,ppid,etime,command"], { encoding: "utf8", timeout: 2000 });
  } catch {
    return { runners: [], liveExecs: [] };
  }

  const procByPid = new Map();
  const childrenByPid = new Map();
  const lines = out.split(/\r?\n/);
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    const m = line.match(/^\s*(\d+)\s+(\d+)\s+(\S+)\s+(.*)$/);
    if (!m) continue;
    const pid = Number(m[1]);
    const ppid = Number(m[2]);
    const etimeMs = parseEtimeMs(m[3]);
    const command = m[4].replace(/\\012/g, "\n").trim();
    const proc = { pid, ppid, etimeMs, command };
    procByPid.set(pid, proc);
    if (!childrenByPid.has(ppid)) childrenByPid.set(ppid, []);
    childrenByPid.get(ppid).push(proc);
  }

  const isAnchorCmd = (cmd) => {
    if (!cmd || /pid-update-loop|codex-code-mode-host|Codex Framework|CodexCLI\.app/i.test(cmd)) return false;
    if (/\bcodex\s+app-server\b/.test(cmd)) return true;
    if (/(?:^|\/)codex(?:\s|$)/.test(cmd) && !/(?:^|\/)codex\s+(?:exec|app-server)\b/.test(cmd)) return true;
    return false;
  };

  const isLiveExecCmd = (cmd) => {
    if (!cmd) return false;
    if (!/(?:^|\/)codex\s+exec(?:\s|$)/.test(cmd)) return false;
    if (cmd.includes("--ephemeral") || cmd.includes("name-schema.json")) return false;
    return true;
  };

  const isInfraCmd = (cmd) =>
    /codex-code-mode-host|mcp\/launch\.mjs|Codex Framework|CodexCLI\.app|dotbot-banner-watcher|browser_crashpad/i.test(cmd);

  const isWrapperCmd = (cmd) =>
    /^(?:\/\S+\/)?(?:zsh|bash|sh)\b/i.test(cmd) ||
    /\bconda\s+run\b/i.test(cmd) ||
    /\btools\/python\.sh\b/i.test(cmd) ||
    /\bmock-python-env\b/i.test(cmd);

  const isBrowserHelperCmd = (cmd) =>
    /\b(?:playwright|chromium|chrome-headless|Google Chrome|webkit|firefox)\b/i.test(cmd);

  const findAnchorPid = (startPid) => {
    let curPid = startPid;
    const seen = new Set();
    while (curPid && !seen.has(curPid)) {
      seen.add(curPid);
      const proc = procByPid.get(curPid);
      if (!proc) break;
      if (isAnchorCmd(proc.command)) return proc.pid;
      curPid = proc.ppid;
    }
    return null;
  };

  const liveExecByPid = new Map();
  const liveExecs = [];
  for (const proc of procByPid.values()) {
    if (!isLiveExecCmd(proc.command)) continue;
    const cwd = parseFlagValue(proc.command, "-C");
    const outPath = parseFlagValue(proc.command, "-o");
    const { runId, agentSlot } = extractSlotFromText(outPath);
    const ex = {
      pid: proc.pid,
      ppid: proc.ppid,
      anchorPid: findAnchorPid(proc.ppid),
      etimeMs: proc.etimeMs,
      cwd,
      outPath,
      runId,
      agentSlot,
      command: proc.command,
      runnerPid: null,
    };
    liveExecByPid.set(proc.pid, ex);
    liveExecs.push(ex);
  }

  const collectDescendantExecs = (rootPid) => {
    const found = [];
    const stack = [rootPid];
    const visited = new Set([rootPid]);
    while (stack.length > 0) {
      const pid = stack.pop();
      for (const child of childrenByPid.get(pid) ?? []) {
        if (visited.has(child.pid)) continue;
        visited.add(child.pid);
        if (liveExecByPid.has(child.pid)) {
          found.push(liveExecByPid.get(child.pid));
        }
        stack.push(child.pid);
      }
    }
    return found;
  };

  const hasLiveExecDescendant = (pid) => collectDescendantExecs(pid).length > 0;

  const anchorPids = [];
  for (const proc of procByPid.values()) {
    if (isAnchorCmd(proc.command)) anchorPids.push(proc.pid);
  }

  const runners = [];
  const seenRunnerPids = new Set();

  for (const anchorPid of anchorPids) {
    for (const branchRoot of childrenByPid.get(anchorPid) ?? []) {
      if (isInfraCmd(branchRoot.command) || liveExecByPid.has(branchRoot.pid) || isBrowserHelperCmd(branchRoot.command)) {
        continue;
      }

      let curr = branchRoot;
      const visited = new Set([curr.pid]);
      for (let depth = 0; depth < 12; depth++) {
        if (!isWrapperCmd(curr.command)) break;
        const kids = (childrenByPid.get(curr.pid) ?? []).filter(
          (k) =>
            !visited.has(k.pid) &&
            !liveExecByPid.has(k.pid) &&
            !isBrowserHelperCmd(k.command) &&
            !isInfraCmd(k.command)
        );
        if (kids.length === 0) break;
        const next =
          kids.find((k) => hasLiveExecDescendant(k.pid)) ||
          kids.find((k) => /\bpython|\btools\/|^\S+\.py\b/i.test(k.command)) ||
          kids[0];
        visited.add(next.pid);
        curr = next;
      }

      if (seenRunnerPids.has(curr.pid) || isInfraCmd(curr.command) || isBrowserHelperCmd(curr.command)) continue;
      const descExecs = collectDescendantExecs(branchRoot.pid);
      if (descExecs.length === 0 && curr.etimeMs < 5000) continue;

      seenRunnerPids.add(curr.pid);
      for (const ex of descExecs) {
        ex.runnerPid = curr.pid;
      }
      runners.push({
        pid: curr.pid,
        anchorPid,
        branchPid: branchRoot.pid,
        etimeMs: Math.max(curr.etimeMs, branchRoot.etimeMs),
        command: curr.command,
        liveExecs: descExecs,
      });
    }
  }

  return { runners, liveExecs };
}

function buildRunnerDisplayName(runner) {
  const cmd = runner.command || "";
  const appFlag = parseFlagValue(cmd, "--app");
  const scriptMatches = cmd.match(/\b([A-Za-z0-9_.-]+\.(?:py|js|mjs|ts|sh))\b/gi) ?? [];
  const scriptName = scriptMatches.find((m) => m.toLowerCase() !== "python.sh") || "";
  if (scriptName && appFlag) return `${scriptName} · ${appFlag}`;
  if (scriptName) return scriptName;
  if (appFlag) return appFlag;
  return shortenName(cmd, 32);
}

const CODEX_INDEX_CACHE_PATH = path.join(
  os.homedir(),
  ".config",
  "herdr-app",
  "data",
  "subagent-tree",
  "codex-index.json"
);

function loadCodexIndexCache() {
  try {
    const raw = fs.readFileSync(CODEX_INDEX_CACHE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    if (
      parsed &&
      parsed.version === 1 &&
      parsed.entries &&
      typeof parsed.entries === "object" &&
      !Array.isArray(parsed.entries)
    ) {
      return parsed;
    }
  } catch {
    // ignore missing or corrupt cache
  }
  return { version: 1, entries: {} };
}

function saveCodexIndexCache(cache, cutoffMs) {
  try {
    const entries = cache.entries || {};
    const keys = Object.keys(entries);
    for (const k of keys) {
      if ((entries[k]?.mtimeMs ?? 0) < cutoffMs) {
        delete entries[k];
      }
    }
    const remaining = Object.keys(entries);
    if (remaining.length > 600) {
      remaining.sort((a, b) => (entries[b]?.mtimeMs ?? 0) - (entries[a]?.mtimeMs ?? 0));
      for (let i = 600; i < remaining.length; i++) {
        delete entries[remaining[i]];
      }
    }
    fs.mkdirSync(path.dirname(CODEX_INDEX_CACHE_PATH), { recursive: true });
    const tmpPath = `${CODEX_INDEX_CACHE_PATH}.tmp.${process.pid}`;
    fs.writeFileSync(tmpPath, JSON.stringify(cache), "utf8");
    fs.renameSync(tmpPath, CODEX_INDEX_CACHE_PATH);
  } catch {
    // ignore cache write failure
  }
}

function readFirstLineHeader(filePath) {
  let fd;
  try {
    fd = fs.openSync(filePath, "r");
    const chunks = [];
    let total = 0;
    const chunkBuf = Buffer.allocUnsafe(8192);
    while (total < 65536) {
      const n = fs.readSync(fd, chunkBuf, 0, chunkBuf.length, total);
      if (n <= 0) break;
      const nlIdx = chunkBuf.indexOf(10, 0);
      if (nlIdx !== -1 && nlIdx < n) {
        chunks.push(chunkBuf.subarray(0, nlIdx));
        break;
      }
      chunks.push(Buffer.from(chunkBuf.subarray(0, n)));
      total += n;
    }
    const firstLine = Buffer.concat(chunks).toString("utf8").trim();
    if (!firstLine) return null;
    const obj = JSON.parse(firstLine);
    if (obj?.type !== "session_meta" || !obj.payload || typeof obj.payload !== "object") return null;
    return {
      cwd: typeof obj.payload.cwd === "string" ? obj.payload.cwd : "",
      isSubagent: Boolean(obj.payload.source?.subagent?.thread_spawn),
    };
  } catch {
    return null;
  } finally {
    if (fd !== undefined) {
      try {
        fs.closeSync(fd);
      } catch {
        // ignore
      }
    }
  }
}

function isRelevantCodexLine(line, needModel) {
  if (line.includes('"session_meta"')) return true;
  if (
    line.includes('"task_started"') ||
    line.includes('"task_complete"') ||
    line.includes('"thread_settings_applied"') ||
    line.includes('"CollabAgentToolCall"')
  ) {
    return true;
  }
  if (
    (line.includes('"function_call"') && !line.includes('"type":"function_call_output"') && !line.includes('"type": "function_call_output"')) ||
    (line.includes('"custom_tool_call"') && !line.includes('"type":"custom_tool_call_output"') && !line.includes('"type": "custom_tool_call_output"'))
  ) {
    return true;
  }
  if (line.includes('"message"') && (line.includes('"role":"user"') || line.includes('"role": "user"'))) {
    return true;
  }
  if (needModel && line.includes('"turn_context"')) return true;
  return false;
}

function scoreCodexRootTokens(tokens, root, sessionsById) {
  if (!tokens || tokens.length === 0) return 0;
  const primary = `${root.prompt || ""} ${root.name || ""}`.toLowerCase();
  const secondary = `${sessionsById.get(root.id)?.commandText || ""}`.toLowerCase();
  let score = 0;
  for (const tok of tokens) {
    if (primary.includes(tok)) {
      score += 10;
    } else if (secondary.includes(tok)) {
      score += /^\d{8}t\d{6}z-/i.test(tok) ? 6 : 1;
    }
  }
  return score;
}

function pickBestCodexRootByTokens(tokens, candidateRoots, sessionsById, targetStartedAt) {
  if (candidateRoots.length === 0) return null;
  if (candidateRoots.length === 1) return candidateRoots[0];
  if (!tokens || tokens.length === 0) return null;

  let maxScore = 0;
  const scored = candidateRoots.map((r) => {
    const score = scoreCodexRootTokens(tokens, r, sessionsById);
    if (score > maxScore) maxScore = score;
    return { root: r, score };
  });
  if (maxScore === 0) return null;

  const top = scored.filter((x) => x.score === maxScore).map((x) => x.root);
  if (top.length === 1) return top[0];
  top.sort((a, b) => {
    const aStarted = a.startedAt ?? 0;
    const bStarted = b.startedAt ?? 0;
    const aBefore = targetStartedAt ? aStarted <= targetStartedAt : true;
    const bBefore = targetStartedAt ? bStarted <= targetStartedAt : true;
    if (aBefore !== bBefore) return aBefore ? -1 : 1;
    if (aBefore && bBefore && aStarted !== bStarted) return bStarted - aStarted;
    return (b.updatedAt ?? 0) - (a.updatedAt ?? 0);
  });
  return top[0];
}

function cloneCodexNodeTree(node) {
  return {
    ...node,
    recentEvents: Array.isArray(node.recentEvents) ? [...node.recentEvents] : [],
    children: Array.isArray(node.children) ? node.children.map(cloneCodexNodeTree) : [],
  };
}

function buildCodexSessionNode(s, sourceOverride, now) {
  let status = "done";
  if (s.hasActiveTask && now - s.mtimeMs < CODEX_WORKING_IDLE_MS) status = "working";
  else if (!s.hasAnyTaskEvent && s.recentEvents.length === 0 && !s.prompt && now - s.mtimeMs < CODEX_WORKING_IDLE_MS) {
    status = "pending";
  }
  const displayName = s.name || s.role || shortenName(s.cwd ? path.basename(s.cwd) : s.id, 24);
  return {
    id: s.id,
    parentId: s.parentId,
    source: sourceOverride || (s.isExec ? "codex_exec" : "codex"),
    name: displayName,
    shortName: s.shortName || shortenName(displayName, 24),
    emoji: pickEmoji(displayName, s.role, s.id),
    status,
    currentAction: s.currentAction,
    prompt: s.prompt,
    startedAt: s.startedAt,
    updatedAt: s.updatedAt,
    filePath: s.filePath,
    cwd: s.cwd,
    model: s.model,
    recentEvents: s.recentEvents,
    children: [],
  };
}

function loadCodexCwdData(sessionsDir, normCwd, cutoffMs, now, sessionIndex) {
  const files = collectCodexJsonl(sessionsDir, cutoffMs);
  const sessionsById = new Map();
  const indexCache = loadCodexIndexCache();
  let cacheDirty = false;

  for (const { filePath, mtimeMs, size } of files) {
    const cached = indexCache.entries[filePath];
    if (cached && cached.mtimeMs === mtimeMs && cached.size === size) {
      if (cached.skipped) continue;
      if (cached.headerOnly) {
        if (!cached.isSubagent && !isPathWithin(cached.cwd, normCwd)) continue;
      } else if (cached.session) {
        const cs = cached.session;
        const existing = sessionsById.get(cs.id);
        if (!existing || cs.updatedAt >= existing.updatedAt) sessionsById.set(cs.id, cs);
        continue;
      }
    }

    if (!cached || cached.mtimeMs !== mtimeMs || cached.size !== size) {
      const header = readFirstLineHeader(filePath);
      if (header && !header.isSubagent && !isPathWithin(header.cwd, normCwd)) {
        indexCache.entries[filePath] = {
          mtimeMs,
          size,
          headerOnly: true,
          skipped: false,
          cwd: header.cwd,
          isSubagent: false,
        };
        cacheDirty = true;
        continue;
      }
    }

    let raw;
    try {
      raw = fs.readFileSync(filePath, "utf8");
    } catch {
      continue;
    }
    const s = {
      id: path.basename(filePath, ".jsonl"),
      parentId: undefined,
      originator: "",
      metaSource: "",
      isExec: false,
      name: "",
      shortName: "",
      role: undefined,
      cwd: undefined,
      model: undefined,
      prompt: undefined,
      rawUserText: "",
      seedQuery: undefined,
      runId: undefined,
      agentSlot: undefined,
      startedAt: undefined,
      updatedAt: mtimeMs,
      mtimeMs,
      filePath,
      hasActiveTask: false,
      hasAnyTaskEvent: false,
      currentAction: undefined,
      recentEvents: [],
      commandTexts: [],
      spawnedRefs: [],
    };
    let skipSession = false;

    for (const line of raw.split(/\r?\n/)) {
      if (!line.trim()) continue;
      if (!isRelevantCodexLine(line, !s.model)) continue;
      let obj;
      try {
        obj = JSON.parse(line);
      } catch {
        continue;
      }
      const ts = typeof obj.timestamp === "string" ? Date.parse(obj.timestamp) : NaN;
      if (!Number.isNaN(ts)) {
        if (s.startedAt === undefined || ts < s.startedAt) s.startedAt = ts;
        if (ts > s.updatedAt) s.updatedAt = ts;
      }
      const topType = obj.type;
      const payload = obj.payload && typeof obj.payload === "object" ? obj.payload : {};

      if (topType === "session_meta") {
        const metaId = payload.id || payload.session_id;
        if (typeof metaId === "string" && metaId) s.id = metaId;
        if (typeof payload.cwd === "string") s.cwd = payload.cwd;
        if (typeof payload.originator === "string") s.originator = payload.originator.toLowerCase();
        if (typeof payload.source === "string") s.metaSource = payload.source.toLowerCase();
        s.isExec = s.metaSource === "exec" || s.originator === "codex_exec";
        const metaNick = typeof payload.agent_nickname === "string" ? payload.agent_nickname : undefined;
        const metaRole = typeof payload.agent_role === "string" ? payload.agent_role : undefined;
        const tso = payload.source?.subagent?.thread_spawn;
        if (tso && typeof tso === "object") {
          if (typeof tso.parent_thread_id === "string") s.parentId = tso.parent_thread_id;
          const subNick = typeof tso.agent_nickname === "string" ? tso.agent_nickname : metaNick;
          const subRole = typeof tso.agent_role === "string" ? tso.agent_role : metaRole;
          s.role = subRole;
          if (subNick) {
            s.name = subNick;
            s.shortName = shortenName(subNick, 24);
          } else if (subRole) {
            s.name = subRole;
            s.shortName = shortenName(subRole, 24);
          }
        }
        if (!s.name && metaNick) {
          s.name = metaNick;
          s.shortName = shortenName(metaNick, 24);
        }
        if (!s.role && metaRole) s.role = metaRole;
      } else if (topType === "event_msg") {
        const pt = payload.type;
        if (pt === "task_started") {
          s.hasActiveTask = true;
          s.hasAnyTaskEvent = true;
        } else if (pt === "task_complete") {
          s.hasActiveTask = false;
          s.hasAnyTaskEvent = true;
        } else if (pt === "thread_settings_applied") {
          if (typeof payload.thread_settings?.model === "string") s.model = payload.thread_settings.model;
        } else if (pt === "item_completed") {
          const item = payload.item;
          if (item?.type === "CollabAgentToolCall" && item?.tool === "spawn_agent") {
            const receiverIds = Array.isArray(item.receiver_thread_ids) ? item.receiver_thread_ids : [];
            const receiverAgents = Array.isArray(item.receiver_agents) ? item.receiver_agents : [];
            const metaById = new Map();
            for (const ra of receiverAgents) {
              if (ra?.thread_id) metaById.set(ra.thread_id, { nickname: ra.agent_nickname, role: ra.agent_role });
            }
            for (const tid of receiverIds) {
              if (typeof tid === "string") {
                const m = metaById.get(tid);
                s.spawnedRefs.push({ threadId: tid, nickname: m?.nickname, role: m?.role });
              }
            }
          }
        }
      } else if (topType === "response_item") {
        const pt = payload.type;
        if (pt === "function_call" || pt === "custom_tool_call") {
          const toolName = typeof payload.name === "string" ? payload.name : String(pt);
          const summary = summarizeArgs(payload.arguments ?? payload.input ?? "", 36);
          s.currentAction = summary ? `${toolName}: ${summary}` : toolName;
          s.recentEvents.push({
            timestamp: typeof obj.timestamp === "string" ? obj.timestamp : undefined,
            tool: toolName,
            summary: summary || toolName,
          });
          if (s.recentEvents.length > MAX_RECENT_EVENTS) s.recentEvents.shift();

          const rawCmd =
            typeof payload.arguments === "string"
              ? payload.arguments
              : typeof payload.input === "string"
                ? payload.input
                : JSON.stringify(payload.arguments ?? payload.input ?? "");
          if (rawCmd) {
            s.commandTexts.push(rawCmd.slice(0, 400));
            if (s.commandTexts.length > 60) s.commandTexts.shift();
          }
        } else if (pt === "message" && payload.role === "user") {
          let text = "";
          if (typeof payload.content === "string") text = payload.content;
          else if (Array.isArray(payload.content)) {
            text = payload.content.map((c) => (typeof c?.text === "string" ? c.text : "")).join(" ");
          }
          text = text.trim();
          if (s.isExec && (text.includes("代码助手可视化面板的命名器") || text.includes("name-schema.json"))) {
            skipSession = true;
            break;
          }
          if (
            !s.prompt &&
            text &&
            !text.startsWith("<environment_context>") &&
            !text.startsWith("# AGENTS.md") &&
            !text.startsWith("<permissions") &&
            !text.startsWith("<skills_instructions>")
          ) {
            s.rawUserText = text;
            if (s.isExec) {
              const slotInfo = extractSlotFromText(text);
              s.runId = slotInfo.runId;
              s.agentSlot = slotInfo.agentSlot;
              s.seedQuery = extractSeedQuery(text) || undefined;
              s.prompt = cleanExecPrompt(text, s.seedQuery);
            } else {
              s.prompt = text;
            }
            if (!s.name) {
              const nameSource = s.seedQuery || s.prompt || text;
              s.nameFromPrompt = true;
              s.name = shortenName(nameSource, 48);
              s.shortName = shortenName(nameSource, 24);
            }
          }
        }
      } else if (topType === "turn_context" && typeof payload.model === "string" && !s.model) {
        s.model = payload.model;
      }
    }

    if (skipSession) {
      indexCache.entries[filePath] = {
        mtimeMs,
        size,
        headerOnly: false,
        skipped: true,
      };
      cacheDirty = true;
      continue;
    }

    if (!s.parentId && !s.isExec && (!s.name || (s.nameFromPrompt && isConversationalPrompt(s.name)))) {
      const folder = s.cwd ? path.basename(s.cwd) : "";
      const cleanRoot = folder ? `Codex · ${folder}` : "Codex";
      s.name = cleanRoot;
      s.shortName = shortenName(cleanRoot, 24);
    } else if (s.parentId && /^Worker #\d+$/.test(s.shortName) && s.prompt) {
      const kw = extractPromptKeyword(s.prompt);
      if (kw) {
        s.shortName = shortenName(`${s.shortName} · ${kw}`, 24);
      }
    }

    if (!s.name) {
      const base = s.agentSlot || (s.cwd ? path.basename(s.cwd) : `codex-${s.id.slice(0, 6)}`);
      s.name = base;
      s.shortName = shortenName(base, 24);
    }

    s.commandText = s.commandTexts.join("\n");
    delete s.rawUserText;
    delete s.commandTexts;

    indexCache.entries[filePath] = {
      mtimeMs,
      size,
      headerOnly: false,
      skipped: false,
      cwd: s.cwd || "",
      isSubagent: Boolean(s.parentId),
      session: s,
    };
    cacheDirty = true;

    const existing = sessionsById.get(s.id);
    if (!existing || s.updatedAt >= existing.updatedAt) sessionsById.set(s.id, s);
  }

  if (cacheDirty) {
    saveCodexIndexCache(indexCache, cutoffMs);
  }

  for (const s of sessionsById.values()) {
    const idxName = sessionIndex?.get(s.id);
    if (idxName && !s.parentId && !s.isExec) {
      s.threadName = idxName;
      s.name = idxName;
      s.shortName = shortenName(idxName, 24);
    }
  }

  // Build non-exec tree first
  const nonExecNodeMap = new Map();
  for (const s of sessionsById.values()) {
    if (s.isExec) continue;
    nonExecNodeMap.set(s.id, buildCodexSessionNode(s, "codex", now));
  }

  for (const s of sessionsById.values()) {
    if (s.isExec) continue;
    const parentNode = nonExecNodeMap.get(s.id);
    if (!parentNode) continue;
    for (const ref of s.spawnedRefs) {
      if (!ref.threadId || nonExecNodeMap.has(ref.threadId)) continue;
      const label = ref.nickname || ref.role || `sub-${ref.threadId.slice(0, 6)}`;
      nonExecNodeMap.set(ref.threadId, {
        id: ref.threadId,
        parentId: s.id,
        source: "codex",
        name: label,
        shortName: shortenName(label, 24),
        emoji: pickEmoji(label, ref.role, ref.threadId),
        status: "pending",
        currentAction: "spawned",
        updatedAt: s.updatedAt,
        cwd: s.cwd,
        recentEvents: [],
        children: [],
      });
    }
  }

  const nonExecRoots = [];
  for (const node of nonExecNodeMap.values()) {
    if (node.parentId && node.parentId !== node.id && nonExecNodeMap.has(node.parentId)) {
      const parent = nonExecNodeMap.get(node.parentId);
      if (!wouldCreateCycle(parent, node.id, nonExecNodeMap)) {
        parent.children.push(node);
        continue;
      }
    }
    nonExecRoots.push(node);
  }

  const matchedNonExec = nonExecRoots.filter((r) => nodeOrDescendantMatchesCwd(r, normCwd));
  const execSessions = [...sessionsById.values()].filter(
    (s) => s.isExec && !s.parentId && isPathWithin(s.cwd, normCwd)
  );

  return { sessionsById, matchedNonExec, execSessions };
}

function attachCodexChildren(baseRoot, matchedNonExec, sessionsById, execSessions, psData, normCwd, now, targetPid = null) {
  const selectedRoot = cloneCodexNodeTree(baseRoot);
  const { runners: psRunners, liveExecs: psLiveExecs } = psData;
  const selectedRootMeta = sessionsById.get(selectedRoot.id);
  const selectedRootHaystack = `${selectedRoot.prompt || ""} ${selectedRoot.name || ""} ${selectedRootMeta?.commandText || ""}`.toLowerCase();

  // Filter execSessions that belong to selectedRoot
  const selectedExecSessions = [];
  for (const s of execSessions) {
    const cmdLower = (selectedRootMeta?.commandText || "").toLowerCase();
    const hasExplicitRunId = Boolean(s.runId && cmdLower.includes(s.runId.toLowerCase()));
    if (s.startedAt && selectedRoot.startedAt && s.startedAt < selectedRoot.startedAt - 15_000 && !hasExplicitRunId) {
      continue;
    }

    if (matchedNonExec.length === 1) {
      selectedExecSessions.push(s);
      continue;
    }

    const tokens = extractScopeTokens(s.cwd, s.runId, normCwd);
    const best = pickBestCodexRootByTokens(tokens, matchedNonExec, sessionsById, s.startedAt);
    if (best) {
      if (best.id === selectedRoot.id) selectedExecSessions.push(s);
      continue;
    }

    if (tokens.length === 0 && normalizePath(s.cwd) === normCwd) {
      const atTime = s.startedAt ?? s.updatedAt ?? now;
      const activeAtStart = [...matchedNonExec].sort((a, b) => {
        const aOk = (a.startedAt ?? 0) <= atTime;
        const bOk = (b.startedAt ?? 0) <= atTime;
        if (aOk !== bOk) return aOk ? -1 : 1;
        return (b.startedAt ?? b.updatedAt ?? 0) - (a.startedAt ?? a.updatedAt ?? 0);
      });
      if (activeAtStart[0]?.id === selectedRoot.id) {
        selectedExecSessions.push(s);
      }
    }
  }

  // Match live background runners to selectedRoot
  const selectedRunners = [];
  const runnerExecKeySet = new Set();
  for (const runner of psRunners) {
    if (typeof targetPid === "number" && runner.anchorPid && runner.anchorPid !== targetPid) {
      continue;
    }
    if (runner.liveExecs.length > 0 && !runner.liveExecs.some((ex) => isPathWithin(ex.cwd, normCwd))) {
      continue;
    }

    let bestRoot = null;
    if (typeof targetPid === "number" && runner.anchorPid === targetPid) {
      bestRoot = selectedRoot;
    } else {
      const specificTokens = new Set();
      const appFlag = parseFlagValue(runner.command, "--app");
      if (appFlag) specificTokens.add(appFlag.toLowerCase());
      for (const ex of runner.liveExecs) {
        for (const tok of extractScopeTokens(ex.cwd, ex.runId, normCwd)) {
          specificTokens.add(tok);
        }
      }

      const scriptTokens = (runner.command.match(/\b([A-Za-z0-9_.-]+\.(?:py|js|mjs|ts|sh))\b/gi) ?? [])
        .map((x) => x.toLowerCase())
        .filter((x) => x !== "python.sh");

      if (specificTokens.size > 0) {
        bestRoot = pickBestCodexRootByTokens([...specificTokens], matchedNonExec, sessionsById, now - runner.etimeMs);
      }
      if (!bestRoot && matchedNonExec.length === 1) {
        if (runner.liveExecs.length > 0 || (runner.etimeMs >= 5000 && countTokenHits(scriptTokens, selectedRootHaystack) > 0)) {
          bestRoot = selectedRoot;
        }
      } else if (!bestRoot && matchedNonExec.length > 1 && runner.liveExecs.length === 0 && runner.etimeMs >= 5000) {
        bestRoot = pickBestCodexRootByTokens(scriptTokens, matchedNonExec, sessionsById, now - runner.etimeMs);
      }
    }

    if (bestRoot && bestRoot.id === selectedRoot.id) {
      selectedRunners.push(runner);
      for (const ex of runner.liveExecs) {
        if (ex.runId && ex.agentSlot) runnerExecKeySet.add(`${ex.runId}::${ex.agentSlot}`);
      }
    }
  }

  // Also include live ps `codex exec` processes matching selectedRoot that might not be under a matched runner
  const matchedLiveExecs = [];
  const liveSlotKeys = new Set(runnerExecKeySet);
  for (const runner of selectedRunners) {
    for (const ex of runner.liveExecs) {
      if (isPathWithin(ex.cwd, normCwd)) matchedLiveExecs.push(ex);
    }
  }
  for (const ex of psLiveExecs) {
    if (matchedLiveExecs.some((m) => m.pid === ex.pid)) continue;
    if (typeof targetPid === "number" && ex.anchorPid && ex.anchorPid !== targetPid) continue;
    if (!isPathWithin(ex.cwd, normCwd)) continue;
    let best = null;
    if (typeof targetPid === "number" && ex.anchorPid === targetPid) {
      best = selectedRoot;
    } else {
      const tokens = extractScopeTokens(ex.cwd, ex.runId, normCwd);
      best = matchedNonExec.length === 1
        ? selectedRoot
        : pickBestCodexRootByTokens(tokens, matchedNonExec, sessionsById, now - ex.etimeMs);
    }
    if (best && best.id === selectedRoot.id) {
      matchedLiveExecs.push(ex);
      if (ex.runId && ex.agentSlot) liveSlotKeys.add(`${ex.runId}::${ex.agentSlot}`);
    }
  }

  // Group exec sessions by (runId, agentSlot)
  const slotGroups = new Map();
  const pendingUngrouped = [];

  for (const s of selectedExecSessions) {
    if (s.runId && s.agentSlot) {
      const key = `${s.runId}::${s.agentSlot}`;
      if (!slotGroups.has(key)) slotGroups.set(key, { runId: s.runId, agentSlot: s.agentSlot, sessions: [], liveExecs: [] });
      slotGroups.get(key).sessions.push(s);
    } else {
      pendingUngrouped.push(s);
    }
  }

  for (const ex of matchedLiveExecs) {
    if (ex.runId && ex.agentSlot) {
      const key = `${ex.runId}::${ex.agentSlot}`;
      if (!slotGroups.has(key)) slotGroups.set(key, { runId: ex.runId, agentSlot: ex.agentSlot, sessions: [], liveExecs: [] });
      slotGroups.get(key).liveExecs.push(ex);
    } else {
      const alreadyHasSession = pendingUngrouped.some(
        (s) => s.cwd && normalizePath(s.cwd) === normalizePath(ex.cwd) && s.hasActiveTask
      );
      if (!alreadyHasSession) {
        pendingUngrouped.push({
          id: `codex-exec-pid:${ex.pid}`,
          name: ex.agentSlot || `codex-exec-${ex.pid}`,
          shortName: shortenName(ex.agentSlot || `codex-exec-${ex.pid}`, 24),
          cwd: ex.cwd,
          prompt: ex.command.length > 1500 ? `${ex.command.slice(0, 1500)}…` : ex.command,
          startedAt: now - ex.etimeMs,
          updatedAt: now,
          mtimeMs: now,
          hasActiveTask: true,
          hasAnyTaskEvent: true,
          currentAction: "codex exec",
          recentEvents: [],
          isExec: true,
          runId: ex.runId,
          agentSlot: ex.agentSlot,
        });
      }
    }
  }

  // Fold planning/supplement exec sessions that share seedQuery + cwd into their slotGroup
  const ungroupedExecs = [];
  for (const s of pendingUngrouped) {
    let matchedGroup = null;
    if (s.seedQuery) {
      const normSessionCwd = normalizePath(s.cwd);
      const candidates = [];
      for (const grp of slotGroups.values()) {
        const hasSeed = grp.sessions.some(
          (gs) => gs.seedQuery === s.seedQuery && (!normSessionCwd || normalizePath(gs.cwd) === normSessionCwd)
        );
        if (hasSeed) candidates.push(grp);
      }
      if (candidates.length > 0) {
        candidates.sort((a, b) => {
          const aTime = Math.max(...a.sessions.map((x) => x.updatedAt ?? 0));
          const bTime = Math.max(...b.sessions.map((x) => x.updatedAt ?? 0));
          const sTime = s.updatedAt ?? 0;
          return Math.abs(aTime - sTime) - Math.abs(bTime - sTime);
        });
        matchedGroup = candidates[0];
      }
    }
    if (matchedGroup) {
      matchedGroup.sessions.push(s);
    } else {
      ungroupedExecs.push(s);
    }
  }

  const execChildNodes = [];
  for (const [key, grp] of slotGroups.entries()) {
    grp.sessions.sort((a, b) => (a.updatedAt ?? 0) - (b.updatedAt ?? 0));
    let startedAt;
    let updatedAt = 0;
    let model;
    let currentAction;
    let seedQuery = "";
    let prompt = "";
    let filePath;
    let cwd = normCwd;
    const mergedEvents = [];
    let hasActiveSession = false;

    for (const s of grp.sessions) {
      if (s.startedAt !== undefined && (startedAt === undefined || s.startedAt < startedAt)) startedAt = s.startedAt;
      if ((s.updatedAt ?? 0) > updatedAt) updatedAt = s.updatedAt;
      if (s.model) model = s.model;
      if (s.currentAction) currentAction = s.currentAction;
      if (s.seedQuery) seedQuery = s.seedQuery;
      if (s.prompt) prompt = s.prompt;
      if (s.filePath) filePath = s.filePath;
      if (s.cwd) cwd = s.cwd;
      if (s.hasActiveTask && now - s.mtimeMs < CODEX_WORKING_IDLE_MS) hasActiveSession = true;
      for (const ev of s.recentEvents ?? []) mergedEvents.push(ev);
    }

    for (const ex of grp.liveExecs) {
      const exStart = now - ex.etimeMs;
      if (startedAt === undefined || exStart < startedAt) startedAt = exStart;
      updatedAt = Math.max(updatedAt, now);
      if (!cwd && ex.cwd) cwd = ex.cwd;
      if (!prompt) prompt = ex.command;
      if (!currentAction) currentAction = "running";
    }

    if (mergedEvents.length === 0 && grp.sessions.length > 0) {
      mergedEvents.push({
        tool: "codex_exec",
        summary: `${grp.agentSlot} (${grp.sessions.length} calls)`,
      });
    }

    const isLive = grp.liveExecs.length > 0 || liveSlotKeys.has(key) || hasActiveSession;
    const seedSnippet = seedQuery ? shortenName(seedQuery, 28) : "";
    const fullName = seedSnippet ? `${grp.agentSlot} · ${seedSnippet}` : grp.agentSlot;
    const id = `codex-exec-slot:${grp.runId}:${grp.agentSlot}`;

    execChildNodes.push({
      id,
      parentId: selectedRoot.id,
      source: "codex_exec",
      name: fullName,
      shortName: shortenName(fullName, 24),
      emoji: pickEmoji(fullName, "explore", id),
      status: isLive ? "working" : "done",
      currentAction: isLive ? currentAction || "running" : "done",
      prompt: prompt || undefined,
      startedAt,
      updatedAt: updatedAt || now,
      filePath,
      cwd,
      model,
      recentEvents: mergedEvents.slice(-MAX_RECENT_EVENTS),
      children: [],
      _runId: grp.runId,
      _scopeTokens: extractScopeTokens(cwd, grp.runId, normCwd),
    });
  }

  for (const s of ungroupedExecs) {
    const node = buildCodexSessionNode(s, "codex_exec", now);
    node.parentId = selectedRoot.id;
    node._runId = s.runId;
    node._scopeTokens = extractScopeTokens(s.cwd, s.runId, normCwd);
    execChildNodes.push(node);
  }

  // Nest execChildNodes under matched live runners when applicable
  const runnerNodes = selectedRunners.map((runner) => {
    const runIds = new Set(runner.liveExecs.map((ex) => ex.runId).filter(Boolean));
    const primaryRunId = [...runIds][0];
    const appFlag = parseFlagValue(runner.command, "--app");
    const runnerTokens = new Set();
    if (appFlag) runnerTokens.add(appFlag.toLowerCase());
    for (const rid of runIds) runnerTokens.add(rid.toLowerCase());
    for (const ex of runner.liveExecs) {
      for (const tok of extractScopeTokens(ex.cwd, ex.runId, normCwd)) runnerTokens.add(tok);
    }

    const id = `codex-bg:${primaryRunId || shortHash(runner.command)}`;
    const displayName = buildRunnerDisplayName(runner);
    const liveCount = runner.liveExecs.length;
    return {
      id,
      parentId: selectedRoot.id,
      source: "codex_bg",
      name: displayName,
      shortName: shortenName(displayName, 24),
      emoji: pickEmoji(displayName, "build", id),
      status: "working",
      currentAction: liveCount > 0 ? `running ${liveCount} subagents` : "background terminal",
      prompt: runner.command,
      startedAt: now - runner.etimeMs,
      updatedAt: now,
      cwd: normCwd,
      recentEvents: [],
      children: [],
      _runIds: runIds,
      _runnerTokens: [...runnerTokens],
    };
  });

  for (const child of execChildNodes) {
    let targetRunner = null;
    if (runnerNodes.length === 1) {
      const r = runnerNodes[0];
      const matchesToken =
        (child._runId && r._runIds.has(child._runId)) ||
        countTokenHits(child._scopeTokens, r._runnerTokens.join(" ")) > 0 ||
        (child.startedAt ?? child.updatedAt ?? now) >= (r.startedAt ?? 0) - 15_000;
      if (matchesToken) targetRunner = r;
    } else if (runnerNodes.length > 1) {
      targetRunner =
        runnerNodes.find((r) => child._runId && r._runIds.has(child._runId)) ||
        runnerNodes.find((r) => countTokenHits(child._scopeTokens, r._runnerTokens.join(" ")) > 0) ||
        null;
    }

    delete child._runId;
    delete child._scopeTokens;

    if (targetRunner) {
      child.parentId = targetRunner.id;
      if (child.status !== "working" && now - (child.updatedAt ?? 0) < 25_000) {
        child.status = "working";
      }
      targetRunner.children.push(child);
    } else {
      selectedRoot.children.push(child);
    }
  }

  for (const rNode of runnerNodes) {
    delete rNode._runIds;
    delete rNode._runnerTokens;
    selectedRoot.children.push(rNode);
  }

  sortNodes([selectedRoot]);
  return selectedRoot;
}

function titlesMatchCodex(normTargetTitle, normIdxTitle) {
  if (!normTargetTitle || !normIdxTitle) return false;
  if (normTargetTitle === normIdxTitle) return true;
  if (normTargetTitle.endsWith("…")) {
    const prefix = normTargetTitle.slice(0, -1).trimEnd();
    if (prefix.length >= 4 && normIdxTitle.startsWith(prefix)) return true;
  }
  if (normIdxTitle.endsWith("…")) {
    const prefix = normIdxTitle.slice(0, -1).trimEnd();
    if (prefix.length >= 4 && normTargetTitle.startsWith(prefix)) return true;
  }
  return false;
}

function matchCodexTargets(cwdTargets, cwdOtherTargets, cwdData, psData, sessionIndex, normCwd, now) {
  const { sessionsById, matchedNonExec, execSessions } = cwdData;
  if (matchedNonExec.length === 0) return [];

  const claimedRootIds = new Set();
  const assigned = new Map();
  const allTargets = [...cwdTargets, ...cwdOtherTargets];

  // Phase 1: Exact / Strong claims across current tab and other tabs
  for (const target of allTargets) {
    if (assigned.has(target.address)) continue;

    // 1a. Explicit UUID match
    if (target.convId) {
      const byId = matchedNonExec.find((r) => !claimedRootIds.has(r.id) && r.id === target.convId);
      if (byId) {
        claimedRootIds.add(byId.id);
        assigned.set(target.address, byId);
        continue;
      }
    }

    // 1b. session_index.jsonl title match
    if (target.title && !isRawCliTitle(target.title)) {
      const normTargetTitle = normalizeCodexTitle(target.title);
      if (normTargetTitle) {
        const candidates = matchedNonExec.filter((r) => {
          if (claimedRootIds.has(r.id)) return false;
          const idxTitle = sessionIndex.get(r.id) || "";
          return titlesMatchCodex(normTargetTitle, normalizeCodexTitle(idxTitle));
        });
        if (candidates.length > 0) {
          candidates.sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0));
          const hit = candidates[0];
          claimedRootIds.add(hit.id);
          assigned.set(target.address, hit);
        }
      }
    }
  }

  // Phase 2: Fallback for unmatched current-tab targets only, excluding claimedRootIds
  for (const target of cwdTargets) {
    if (assigned.has(target.address)) continue;
    const available = matchedNonExec.filter((r) => !claimedRootIds.has(r.id));
    if (available.length === 0) continue;

    const hintTokens = tokenizeHint([target.tabName, target.paneName, target.title].filter(Boolean).join(" "));
    const tWorking = target.status === "working";
    const isResume = Array.isArray(target.argv) && target.argv.some((a) => a === "resume" || a === "--continue");

    const scored = available.map((r) => {
      let score = 0;
      const rWorking = r.status === "working";
      if (tWorking && rWorking) score += 40;
      else if (!tWorking && rWorking) score -= 60;

      if (!isResume && typeof target.createdMs === "number" && typeof r.startedAt === "number") {
        const diff = Math.abs(r.startedAt - target.createdMs);
        if (diff <= 60_000) score += 50;
        else if (diff <= 300_000) score += 15;
      }

      if (typeof target.statusMs === "number" && typeof r.updatedAt === "number") {
        const diff = Math.abs(r.updatedAt - target.statusMs);
        if (diff <= 30_000) score += 35;
        else if (diff <= 180_000) score += 15;
      }

      if (hintTokens.length > 0) {
        score += scoreCodexRootTokens(hintTokens, r, sessionsById);
      }
      return { root: r, score };
    });

    scored.sort((a, b) => {
      if (a.score !== b.score) return b.score - a.score;
      return (b.root.updatedAt ?? 0) - (a.root.updatedAt ?? 0);
    });

    const best = scored[0];
    if (best && best.score > -30) {
      claimedRootIds.add(best.root.id);
      assigned.set(target.address, best.root);
    }
  }

  const results = [];
  for (const target of cwdTargets) {
    const baseRoot = assigned.get(target.address);
    if (!baseRoot) continue;
    const attached = attachCodexChildren(
      baseRoot,
      matchedNonExec,
      sessionsById,
      execSessions,
      psData,
      normCwd,
      now,
      typeof target.pid === "number" ? target.pid : null
    );
    attached.targetAddress = target.address;
    results.push(attached);
  }

  return results;
}

function parseCodexScoped(sessionsDir, normCwd, cutoffMs, now, tabHint = "", sessionIndex = loadCodexSessionIndex(), psData = scanLiveCodexProcesses()) {
  const { sessionsById, matchedNonExec, execSessions } = loadCodexCwdData(sessionsDir, normCwd, cutoffMs, now, sessionIndex);
  const { liveExecs: psLiveExecs } = psData;

  if (matchedNonExec.length === 0) {
    const fallbackRoots = execSessions
      .filter((s) => normalizePath(s.cwd) === normCwd)
      .map((s) => buildCodexSessionNode(s, "codex_exec", now));

    for (const ex of psLiveExecs) {
      if (normalizePath(ex.cwd) !== normCwd) continue;
      if (fallbackRoots.some((r) => ex.runId && r.prompt?.includes(ex.runId))) continue;
      fallbackRoots.push({
        id: `codex-exec-pid:${ex.pid}`,
        source: "codex_exec",
        name: ex.agentSlot || `codex-exec-${ex.pid}`,
        shortName: shortenName(ex.agentSlot || `codex-exec-${ex.pid}`, 24),
        emoji: pickEmoji(ex.agentSlot || "exec", "build", String(ex.pid)),
        status: "working",
        currentAction: "codex exec",
        prompt: ex.command,
        startedAt: now - ex.etimeMs,
        updatedAt: now,
        cwd: ex.cwd,
        recentEvents: [],
        children: [],
      });
    }
    sortNodes(fallbackRoots);
    return fallbackRoots.slice(0, 1);
  }

  const hintTokens = tokenizeHint(tabHint);
  if (hintTokens.length > 0 && matchedNonExec.length > 1) {
    matchedNonExec.sort((a, b) => {
      const sa = scoreCodexRootTokens(hintTokens, a, sessionsById);
      const sb = scoreCodexRootTokens(hintTokens, b, sessionsById);
      if (sa !== sb) return sb - sa;
      const d = (STATUS_RANK[a.status] ?? 2) - (STATUS_RANK[b.status] ?? 2);
      if (d !== 0) return d;
      return (b.updatedAt ?? 0) - (a.updatedAt ?? 0);
    });
  } else {
    sortNodes(matchedNonExec);
  }

  const selectedRoot = matchedNonExec[0];
  return [attachCodexChildren(selectedRoot, matchedNonExec, sessionsById, execSessions, psData, normCwd, now, null)];
}

function findSpawnedConversationId(steps, startIdx, nth = 0) {
  const limit = Math.min(steps.length, startIdx + 12);
  let seen = 0;
  for (let j = startIdx; j < limit; j++) {
    const next = steps[j];
    if (next.type === "PLANNER_RESPONSE") break;
    const content = typeof next.content === "string" ? next.content : "";
    if (!content) continue;
    if (content.includes("conversationId") || content.includes("Created the following subagent")) {
      const m = content.match(UUID_RE);
      if (m) {
        if (seen === nth) return m[0];
        seen++;
      }
    }
  }
  return undefined;
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function handleSwarmToolCall(session, args, steps, idx, eventTs) {
  const action = unwrapQuoted(args.action).toLowerCase();
  if (action === "title") {
    const title = unwrapQuoted(args.title);
    if (title) session.swarmTitle = title;
    return;
  }
  if (action === "add") {
    const baseName = unwrapQuoted(args.name) || "worker";
    const brief = unwrapQuoted(args.brief);
    const n = parseInt(unwrapQuoted(args.n) || "0", 10) || 0;
    let tasks = [];
    if (Array.isArray(args.tasks)) {
      tasks = args.tasks.map((t) => unwrapQuoted(t)).filter(Boolean);
    } else if (typeof args.tasks === "string") {
      try {
        const parsed = JSON.parse(unwrapQuoted(args.tasks));
        if (Array.isArray(parsed)) tasks = parsed.map((t) => unwrapQuoted(t)).filter(Boolean);
      } catch {
        // ignore
      }
    }
    if (tasks.length > 0) {
      for (let i = 0; i < tasks.length; i++) {
        const wName = `${baseName}-${i + 1}`;
        session.swarmWorkers.set(wName, { name: wName, brief: `${tasks[i]}${brief ? `\n${brief}` : ""}`, status: "working", updatedAt: eventTs });
      }
    } else if (n > 1) {
      for (let i = 1; i <= n; i++) {
        const wName = `${baseName}-${i}`;
        session.swarmWorkers.set(wName, { name: wName, brief, status: "working", updatedAt: eventTs });
      }
    } else {
      session.swarmWorkers.set(baseName, { name: baseName, brief, status: "working", updatedAt: eventTs });
    }
    return;
  }
  if (action === "kill") {
    const wName = unwrapQuoted(args.name);
    const existing = wName ? session.swarmWorkers.get(wName) : undefined;
    if (existing) {
      existing.status = "done";
      existing.updatedAt = eventTs;
    }
    return;
  }
  if (action === "status") {
    const next = steps[idx + 1];
    if (!next || next.type === "PLANNER_RESPONSE") return;
    const content = typeof next.content === "string" ? next.content : "";
    if (!content) return;
    for (const [wName, worker] of session.swarmWorkers.entries()) {
      const lineRe = new RegExp(`${escapeRegExp(wName)}[^\\n]*\\b(working|waiting|stopped|killed|done)\\b`, "i");
      const m = content.match(lineRe);
      if (m) {
        const st = m[1].toLowerCase();
        worker.status = st === "working" ? "working" : st === "waiting" ? "pending" : "done";
        worker.updatedAt = eventTs;
      }
    }
  }
}

function readAntigravityTranscript(brainDir, convId) {
  const filePath = path.join(brainDir, convId, ".system_generated", "logs", "transcript.jsonl");
  let stat;
  try {
    stat = fs.statSync(filePath);
    if (!stat.isFile()) return null;
  } catch {
    return null;
  }
  let raw;
  try {
    raw = fs.readFileSync(filePath, "utf8");
  } catch {
    return null;
  }

  const session = {
    id: convId,
    name: "",
    shortName: "",
    swarmTitle: undefined,
    model: undefined,
    prompt: undefined,
    startedAt: undefined,
    updatedAt: stat.mtimeMs,
    mtimeMs: stat.mtimeMs,
    filePath,
    lastStepStatus: undefined,
    lastStepType: undefined,
    currentAction: undefined,
    recentEvents: [],
    invokedSubagents: [],
    swarmWorkers: new Map(),
  };

  const steps = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      steps.push(JSON.parse(line));
    } catch {
      // ignore
    }
  }

  for (let idx = 0; idx < steps.length; idx++) {
    const step = steps[idx];
    const ts = typeof step.created_at === "string" ? Date.parse(step.created_at) : NaN;
    if (!Number.isNaN(ts)) {
      if (session.startedAt === undefined || ts < session.startedAt) session.startedAt = ts;
      if (ts > session.updatedAt) session.updatedAt = ts;
    }
    if (typeof step.type === "string") session.lastStepType = step.type;
    if (typeof step.status === "string") session.lastStepStatus = step.status;

    if (step.type === "USER_INPUT" && !session.prompt) {
      const content = typeof step.content === "string" ? step.content.trim() : "";
      if (content) {
        session.prompt = content;
        session.name = shortenName(content, 48);
        session.shortName = shortenName(content, 18);
      }
    }

    if (step.type === "PLANNER_RESPONSE") {
      if (typeof step.model === "string") session.model = step.model;
      const toolCalls = Array.isArray(step.tool_calls) ? step.tool_calls : [];
      let invokeOrdinal = 0;
      for (const tc of toolCalls) {
        if (!tc || typeof tc !== "object") continue;
        const toolName = typeof tc.name === "string" ? tc.name : "tool";
        const args = tc.args && typeof tc.args === "object" ? tc.args : {};
        const summary = summarizeArgs(args, 36);
        session.currentAction = summary ? `${toolName}: ${summary}` : toolName;
        session.recentEvents.push({
          timestamp: typeof step.created_at === "string" ? step.created_at : undefined,
          tool: toolName,
          summary: summary || toolName,
          status: typeof step.status === "string" ? step.status : undefined,
        });
        if (session.recentEvents.length > MAX_RECENT_EVENTS) session.recentEvents.shift();

        if (toolName === "invoke_subagent") {
          session.invokedSubagents.push({
            conversationId: findSpawnedConversationId(steps, idx + 1, invokeOrdinal++),
            role: unwrapQuoted(args.Role),
            typeName: unwrapQuoted(args.TypeName),
            prompt: unwrapQuoted(args.Prompt),
            timestamp: typeof step.created_at === "string" ? step.created_at : undefined,
            stepIndex: typeof step.step_index === "number" ? step.step_index : idx,
          });
        } else if (toolName === "swarm") {
          handleSwarmToolCall(session, args, steps, idx, !Number.isNaN(ts) ? ts : stat.mtimeMs);
        }
      }
    }
  }

  return session;
}

function mapDbStatus(row) {
  if (Number(row.killed) === 1) return "done";
  const st = String(row.status || "").toUpperCase();
  if (st.includes("RUNNING")) return "working";
  if (st.includes("WAITING") || st.includes("PENDING")) return "pending";
  return "done";
}

function workspaceUrisMatch(rawJson, normCwd) {
  try {
    const arr = JSON.parse(rawJson || "[]");
    if (!Array.isArray(arr)) return false;
    for (const uri of arr) {
      if (typeof uri !== "string") continue;
      if (!uri.startsWith("file://")) continue;
      const decoded = decodeURIComponent(uri.slice("file://".length));
      if (normalizePath(decoded) === normCwd) return true;
    }
  } catch {
    // ignore
  }
  return false;
}

function fetchAntigravityCandidateRows(dbPath, normCwd) {
  if (!fs.existsSync(dbPath) || !normCwd) return [];
  const escaped = normCwd.replace(/'/g, "''");
  const candidateSql = `
    SELECT conversation_id, workspace_uris, title, agent_name, status, killed, not_fully_idle, last_modified_time
    FROM conversation_summaries
    WHERE parent_conversation_id = ''
      AND (workspace_uris LIKE '%file://${escaped}%')
    ORDER BY
      (CASE WHEN status LIKE '%RUNNING%' OR not_fully_idle = 1 THEN 0 ELSE 1 END) ASC,
      last_modified_time DESC
    LIMIT 50;
  `;
  try {
    const out = execFileSync("sqlite3", ["-json", dbPath, candidateSql], { encoding: "utf8", timeout: 5000 });
    const rows = JSON.parse(out || "[]");
    return Array.isArray(rows) ? rows.filter((r) => workspaceUrisMatch(r.workspace_uris, normCwd)) : [];
  } catch {
    return [];
  }
}

function fetchAntigravityRowById(dbPath, convId) {
  if (!fs.existsSync(dbPath) || !convId) return null;
  const escaped = String(convId).replace(/'/g, "''");
  const sql = `
    SELECT conversation_id, workspace_uris, title, agent_name, status, killed, not_fully_idle, last_modified_time
    FROM conversation_summaries
    WHERE conversation_id = '${escaped}'
    LIMIT 1;
  `;
  try {
    const out = execFileSync("sqlite3", ["-json", dbPath, sql], { encoding: "utf8", timeout: 5000 });
    const rows = JSON.parse(out || "[]");
    return Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
  } catch {
    return null;
  }
}

function buildAntigravityTreeForRootId(dbPath, brainDir, rootId, normCwd, now) {
  const rootIdEsc = String(rootId).replace(/'/g, "''");
  const treeSql = `
    WITH RECURSIVE tree(conversation_id, parent_conversation_id, title, agent_name, status, killed, not_fully_idle, last_modified_time) AS (
      SELECT conversation_id, parent_conversation_id, title, agent_name, status, killed, not_fully_idle, last_modified_time
      FROM conversation_summaries
      WHERE conversation_id = '${rootIdEsc}'
      UNION ALL
      SELECT c.conversation_id, c.parent_conversation_id, c.title, c.agent_name, c.status, c.killed, c.not_fully_idle, c.last_modified_time
      FROM conversation_summaries c
      JOIN tree t ON c.parent_conversation_id = t.conversation_id
    )
    SELECT * FROM tree;
  `;

  let treeRows;
  try {
    const out = execFileSync("sqlite3", ["-json", dbPath, treeSql], { encoding: "utf8", timeout: 5000 });
    treeRows = JSON.parse(out || "[]");
  } catch {
    return null;
  }
  if (!Array.isArray(treeRows) || treeRows.length === 0) return [];

  const nodeMap = new Map();
  const transcriptMap = new Map();

  for (const row of treeRows) {
    const id = String(row.conversation_id);
    const parentId = row.parent_conversation_id ? String(row.parent_conversation_id) : undefined;
    const tx = readAntigravityTranscript(brainDir, id);
    if (tx) transcriptMap.set(id, tx);

    let status = mapDbStatus(row);
    if (tx && status === "done") {
      if (tx.lastStepStatus && tx.lastStepStatus !== "DONE") status = "working";
      else if (now - tx.mtimeMs < AGY_WORKING_IDLE_MS && tx.lastStepType && tx.lastStepType !== "PLANNER_RESPONSE") {
        status = "working";
      }
    }

    const dbUpdated = Date.parse(String(row.last_modified_time || "").replace(" ", "T"));
    const updatedAt = Math.max(Number.isNaN(dbUpdated) ? 0 : dbUpdated, tx?.updatedAt ?? 0) || now;
    const dbAgentName = row.agent_name ? String(row.agent_name).trim() : "";
    const dbTitle = row.title ? String(row.title).trim() : "";
    let rawName = "";
    if (!parentId) {
      const cleanTitle = dbTitle && !isConversationalPrompt(dbTitle) ? dbTitle : "";
      const folder = normCwd ? path.basename(normCwd) : "";
      rawName = dbAgentName || tx?.swarmTitle || cleanTitle || (folder ? `Antigravity · ${folder}` : "Antigravity");
    } else {
      rawName = dbAgentName || tx?.swarmTitle || dbTitle || tx?.name || `agy-${id.slice(0, 6)}`;
    }

    nodeMap.set(id, {
      id,
      parentId,
      source: "antigravity",
      name: rawName,
      shortName: shortenName(rawName, 24),
      emoji: pickEmoji(rawName, row.agent_name || "", id),
      status,
      currentAction: tx?.currentAction,
      prompt: tx?.prompt,
      startedAt: tx?.startedAt,
      updatedAt,
      filePath: tx?.filePath,
      cwd: normCwd,
      model: tx?.model,
      recentEvents: tx?.recentEvents ?? [],
      children: [],
    });
  }

  // Link DB parent-child edges first
  for (const node of nodeMap.values()) {
    if (node.parentId && node.parentId !== node.id && nodeMap.has(node.parentId)) {
      const parent = nodeMap.get(node.parentId);
      if (!wouldCreateCycle(parent, node.id, nodeMap)) {
        parent.children.push(node);
      }
    }
  }

  // Enrich with invoke_subagent / swarm workers from transcripts if not already in DB tree
  for (const [id, tx] of transcriptMap.entries()) {
    const parentNode = nodeMap.get(id);
    if (!parentNode) continue;

    const existingChildIds = new Set(parentNode.children.map((c) => c.id));
    const existingChildNames = new Set(parentNode.children.map((c) => c.name.toLowerCase()));

    for (let i = 0; i < tx.invokedSubagents.length; i++) {
      const ref = tx.invokedSubagents[i];
      if (ref.conversationId && nodeMap.has(ref.conversationId)) {
        const child = nodeMap.get(ref.conversationId);
        const roleLabel = ref.role || ref.typeName;
        const currLower = String(child.name || "").trim().toLowerCase();
        const isGeneric = !currLower || currLower.startsWith("agy-") || GENERIC_CHILD_NAMES.has(currLower);
        if (ref.role && isGeneric) {
          child.name = ref.role;
          child.shortName = shortenName(ref.role, 24);
          child.emoji = pickEmoji(ref.role, ref.typeName, child.id);
        } else if (roleLabel && isGeneric) {
          child.name = roleLabel;
          child.shortName = shortenName(roleLabel, 24);
          child.emoji = pickEmoji(roleLabel, ref.typeName, child.id);
        }
        if (!child.prompt && ref.prompt) child.prompt = ref.prompt;
        continue;
      }
      const syntheticId = ref.conversationId || `${id}::sub::${ref.stepIndex}::${i}`;
      if (existingChildIds.has(syntheticId)) continue;
      const label = ref.role || ref.typeName || `sub-${i + 1}`;
      const parentActive = parentNode.status === "working";
      parentNode.children.push({
        id: syntheticId,
        parentId: id,
        source: "antigravity",
        name: label,
        shortName: shortenName(label, 24),
        emoji: pickEmoji(label, ref.typeName, syntheticId),
        status: ref.conversationId ? (parentActive ? "working" : "done") : parentActive ? "pending" : "done",
        currentAction: ref.typeName || "subagent",
        prompt: ref.prompt,
        updatedAt: ref.timestamp ? Date.parse(ref.timestamp) || parentNode.updatedAt : parentNode.updatedAt,
        cwd: normCwd,
        recentEvents: [],
        children: [],
      });
      existingChildIds.add(syntheticId);
    }

    for (const worker of tx.swarmWorkers.values()) {
      const workerId = `${id}::swarm::${worker.name}`;
      if (existingChildIds.has(workerId) || existingChildNames.has(worker.name.toLowerCase())) continue;
      const effectiveStatus = parentNode.status === "done" && worker.status !== "done" ? "done" : worker.status;
      parentNode.children.push({
        id: workerId,
        parentId: id,
        source: "antigravity",
        name: worker.name,
        shortName: shortenName(worker.name, 24),
        emoji: pickEmoji(worker.name, "swarm", workerId),
        status: effectiveStatus,
        currentAction: effectiveStatus === "pending" ? "waiting" : effectiveStatus === "working" ? "working" : "done",
        prompt: worker.brief,
        updatedAt: worker.updatedAt,
        cwd: normCwd,
        recentEvents: [],
        children: [],
      });
    }
  }

  const root = nodeMap.get(String(rootId));
  return root ? [root] : [];
}

function matchAntigravityTargets(dbPath, brainDir, agyTargets, agyOtherTargets, fallbackCwd, cutoffMs, now) {
  if (!fs.existsSync(dbPath) || agyTargets.length === 0) return [];

  const allTargets = [...agyTargets, ...agyOtherTargets];
  const candidatesByCwd = new Map();
  for (const t of allTargets) {
    const c = normalizePath(t.cwd || fallbackCwd);
    if (c && !candidatesByCwd.has(c)) {
      candidatesByCwd.set(c, fetchAntigravityCandidateRows(dbPath, c));
    }
  }

  const claimedConvIds = new Set();
  const assignedRowByAddr = new Map();

  // Phase 1: Exact claims (explicit --conversation UUID or exact reportMsg match)
  for (const target of allTargets) {
    if (assignedRowByAddr.has(target.address)) continue;

    if (target.convId) {
      const row = fetchAntigravityRowById(dbPath, target.convId);
      if (row && !claimedConvIds.has(row.conversation_id)) {
        claimedConvIds.add(row.conversation_id);
        assignedRowByAddr.set(target.address, row);
        continue;
      }
    }

    const msgNorm = String(target.reportMsg || "").trim().toLowerCase();
    if (msgNorm) {
      const c = normalizePath(target.cwd || fallbackCwd);
      const rows = candidatesByCwd.get(c) || [];
      const hit = rows.find((r) => {
        if (claimedConvIds.has(r.conversation_id)) return false;
        const rTitle = String(r.title || "").trim().toLowerCase();
        const rAgent = String(r.agent_name || "").trim().toLowerCase();
        return rTitle === msgNorm || rAgent === msgNorm;
      });
      if (hit) {
        claimedConvIds.add(hit.conversation_id);
        assignedRowByAddr.set(target.address, hit);
      }
    }
  }

  // Phase 2: Fallback for unmatched current-tab targets only
  for (const target of agyTargets) {
    if (assignedRowByAddr.has(target.address)) continue;
    const c = normalizePath(target.cwd || fallbackCwd);
    const rows = (candidatesByCwd.get(c) || []).filter((r) => {
      if (claimedConvIds.has(r.conversation_id)) return false;
      const modMs = Date.parse(String(r.last_modified_time || "").replace(" ", "T")) || now;
      const st = mapDbStatus(r);
      return !(st === "done" && modMs < cutoffMs);
    });
    if (rows.length === 0) continue;

    const hintTokens = tokenizeHint([target.tabName, target.paneName].filter(Boolean).join(" "));
    const tWorking = target.status === "working";

    const scored = rows.map((r) => {
      let score = 0;
      const modMs = Date.parse(String(r.last_modified_time || "").replace(" ", "T")) || now;
      const rWorking = mapDbStatus(r) === "working" || Number(r.not_fully_idle) === 1;
      if (tWorking && rWorking) score += 40;
      else if (!tWorking && rWorking) score -= 60;

      if (typeof target.statusMs === "number") {
        const diff = Math.abs(modMs - target.statusMs);
        if (diff <= 30_000) score += 35;
        else if (diff <= 180_000) score += 15;
      }

      if (hintTokens.length > 0) {
        const hay = `${r.title || ""} ${r.agent_name || ""}`.toLowerCase();
        score += countTokenHits(hintTokens, hay) * 10;
      }
      return { row: r, score, modMs };
    });

    scored.sort((a, b) => {
      if (a.score !== b.score) return b.score - a.score;
      return b.modMs - a.modMs;
    });

    const best = scored[0];
    if (best && best.score > -30) {
      claimedConvIds.add(best.row.conversation_id);
      assignedRowByAddr.set(target.address, best.row);
    }
  }

  const results = [];
  for (const target of agyTargets) {
    const row = assignedRowByAddr.get(target.address);
    if (!row) continue;
    const c = normalizePath(target.cwd || fallbackCwd);
    const trees = buildAntigravityTreeForRootId(dbPath, brainDir, row.conversation_id, c, now);
    if (Array.isArray(trees) && trees.length > 0) {
      trees[0].targetAddress = target.address;
      results.push(trees[0]);
    }
  }
  return results;
}

function parseAntigravityFromDb(dbPath, brainDir, normCwd, cutoffMs, now) {
  if (!fs.existsSync(dbPath)) return null;
  const candidates = fetchAntigravityCandidateRows(dbPath, normCwd);
  if (candidates.length === 0) return [];
  const rootRow = candidates[0];

  const rootModifiedMs = Date.parse(String(rootRow.last_modified_time || "").replace(" ", "T")) || now;
  const rootDbStatus = mapDbStatus(rootRow);
  if (rootDbStatus === "done" && rootModifiedMs < cutoffMs) {
    return [];
  }

  return buildAntigravityTreeForRootId(dbPath, brainDir, rootRow.conversation_id, normCwd, now);
}

function parseAntigravityFallback(brainDir, cutoffMs, now) {
  if (!fs.existsSync(brainDir)) return [];
  let entries;
  try {
    entries = fs.readdirSync(brainDir, { withFileTypes: true });
  } catch {
    return [];
  }

  const sessions = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const tx = readAntigravityTranscript(brainDir, entry.name);
    if (tx && tx.mtimeMs >= cutoffMs) sessions.push(tx);
  }
  sessions.sort((a, b) => b.updatedAt - a.updatedAt);
  const top = sessions[0];
  if (!top) return [];

  let status = "done";
  if (top.lastStepStatus && top.lastStepStatus !== "DONE") status = "working";
  else if (now - top.mtimeMs < AGY_WORKING_IDLE_MS && top.lastStepType && top.lastStepType !== "PLANNER_RESPONSE") status = "working";
  const displayName = top.swarmTitle || top.name || `agy-${top.id.slice(0, 6)}`;
  return [
    {
      id: top.id,
      source: "antigravity",
      name: displayName,
      shortName: shortenName(displayName, 18),
      emoji: pickEmoji(displayName, undefined, top.id),
      status,
      currentAction: top.currentAction,
      prompt: top.prompt,
      startedAt: top.startedAt,
      updatedAt: top.updatedAt,
      filePath: top.filePath,
      model: top.model,
      recentEvents: top.recentEvents,
      children: [],
    },
  ];
}

const ROLE_TRANSLATIONS = [
  [/\bcode\s*reviewer\b/i, "代码审查"],
  [/\bui\s*layout\s*auditor\b/i, "界面布局审计"],
  [/\blog\s*parser\s*verifier\b/i, "日志解析验证"],
  [/\bdesign[-_\s]*researcher\b/i, "设计调研"],
  [/\bappstore[-_\s]*researcher\b/i, "AppStore调研"],
  [/\bgplay[-_\s]*researcher\b/i, "Play商店调研"],
  [/\boss[-_\s]*(?:quality[-_\s]*)?researcher\b/i, "开源质量调研"],
  [/\bpaper[-_\s]*researcher\b/i, "论文调研"],
  [/\bproduct[-_\s]*researcher\b/i, "产品调研"],
  [/\btemplate[-_\s]*builder\b/i, "模板构建"],
  [/\brepo[-_\s]*init\b/i, "仓库初始化"],
  [/\bprovider[-_\s]*editor\b/i, "接口编辑"],
  [/\bharness[-_\s]*core\b/i, "核心框架"],
  [/\bverifier[-_\s]*builder\b/i, "验证器构建"],
  [/\bimage[-_\s]*generator\b/i, "图像生成"],
  [/\bmonitor\b/i, "状态监控"],
  [/\bverifier\b/i, "结果验证"],
];

const DOMAIN_WORDS = [
  [/\b(didi)\b/i, "滴滴"],
  [/\b(dongchedi)\b/i, "懂车帝"],
  [/\b(mermaid)\b/i, "图表"],
  [/\b(subagent|agent)\b/i, "智能体"],
  [/\b(panel|mod)\b/i, "面板"],
  [/\b(mock-app|mocker)\b/i, "模拟应用"],
  [/\b(replay)\b/i, "回放"],
  [/\b(parser)\b/i, "解析"],
  [/\b(layout|ui)\b/i, "界面"],
];

const ACTION_WORDS = [
  [/\b(annotation\w*)\b/i, "标注"],
  [/\b(repair|fix\w*|unfixed)\b/i, "修复"],
  [/\b(review\w*)\b/i, "审查"],
  [/\b(audit\w*)\b/i, "审计"],
  [/\b(verif\w*|test\w*|check\w*)\b/i, "验证"],
  [/\b(build\w*|impl\w*|creat\w*)\b/i, "构建"],
  [/\b(research\w*|explor\w*)\b/i, "调研"],
  [/\b(visualiz\w*)\b/i, "可视化"],
  [/\b(optimiz\w*|speedup)\b/i, "优化"],
];

function loadNameCache() {
  const cachePath = path.join(os.homedir(), ".config", "herdr-app", "data", "subagent-tree", "names.json");
  try {
    const parsed = JSON.parse(fs.readFileSync(cachePath, "utf8"));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function hasCjk(s) {
  return /[\u4e00-\u9fff]/.test(String(s || ""));
}

function toChineseFallbackName(node, isRoot) {
  const rawName = String(node.name || "").trim();
  const shortRaw = String(node.shortName || "").trim();
  const prompt = String(node.prompt || "").trim();
  const cwdName = node.cwd ? path.basename(String(node.cwd)) : "";
  const combined = `${rawName} ${shortRaw} ${prompt.slice(0, 180)} ${cwdName}`;

  for (const [re, zh] of ROLE_TRANSLATIONS) {
    if (re.test(rawName) || re.test(shortRaw)) return zh;
  }

  if (node.source === "codex_bg" || /\bexplore\.py\b/i.test(rawName)) {
    if (/wuba/i.test(combined)) return "五八后台探索";
    if (/toutiao/i.test(combined)) return "头条后台探索";
    if (/kwai/i.test(combined)) return "快手后台探索";
    if (/didi/i.test(combined)) return "滴滴后台探索";
    if (/dongchedi/i.test(combined)) return "懂车帝后台探索";
    return /\bexplore\.py\b/i.test(rawName) ? "后台探索任务" : "后台终端任务";
  }

  const agentSlotMatch = rawName.match(/^agent[-_]?0*(\d+)\b/i);
  if (agentSlotMatch) {
    return `探索子代理 ${agentSlotMatch[1]}`;
  }

  let domain = "";
  for (const [re, zh] of DOMAIN_WORDS) {
    if (re.test(combined)) {
      domain = zh;
      break;
    }
  }
  let action = "";
  for (const [re, zh] of ACTION_WORDS) {
    if (re.test(combined)) {
      action = zh;
      break;
    }
  }

  const numMatch = `${rawName} ${shortRaw}`.match(/#?(\d+)\b/);
  const numSuffix = numMatch ? ` ${numMatch[1]}` : "";

  if (domain && action) {
    return shortenName(`${domain}${action}${numSuffix}`, 14);
  }
  if (domain) {
    return shortenName(`${domain}${isRoot ? "任务" : "处理"}${numSuffix}`, 14);
  }
  if (action) {
    return shortenName(`${action}${isRoot ? "任务" : "子任务"}${numSuffix}`, 14);
  }

  if (hasCjk(shortRaw) && !isConversationalPrompt(shortRaw)) {
    return shortenName(shortRaw, 14);
  }
  if (numSuffix) {
    return `子任务${numSuffix}`;
  }
  return isRoot ? "主任务" : "子任务";
}

function applyChineseNames(nodes, nameCache, isRoot = true) {
  for (const node of nodes) {
    const cached = nameCache[node.id]?.name;
    if (cached && String(cached).trim()) {
      node.shortName = shortenName(String(cached).trim(), 16);
      node.aiNamed = true;
    } else {
      node.shortName = toChineseFallbackName(node, isRoot);
      node.aiNamed = false;
    }
    if (Array.isArray(node.children) && node.children.length > 0) {
      applyChineseNames(node.children, nameCache, false);
    }
  }
}

function main() {
  let hours = 24;
  let cwd = "";
  let source = "auto";
  let tabHint = "";
  let targetsPayload = null;
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--hours" && argv[i + 1]) {
      const parsed = Number(argv[++i]);
      if (Number.isFinite(parsed) && parsed > 0) hours = parsed;
    } else if (argv[i] === "--cwd" && argv[i + 1]) {
      cwd = normalizePath(argv[++i]);
    } else if (argv[i] === "--source" && argv[i + 1]) {
      source = String(argv[++i]).toLowerCase();
    } else if (argv[i] === "--tab-hint" && argv[i + 1]) {
      tabHint = String(argv[++i]).trim();
    } else if (argv[i] === "--targets-json" && argv[i + 1]) {
      try {
        const parsed = JSON.parse(argv[++i]);
        if (parsed && typeof parsed === "object") targetsPayload = parsed;
      } catch {
        targetsPayload = null;
      }
    }
  }

  const now = Date.now();
  const cutoffMs = now - hours * 3_600_000;
  const agyBase = path.join(os.homedir(), ".gemini", "antigravity-cli");
  const agyDb = path.join(agyBase, "conversation_summaries.db");
  const agyBrain = path.join(agyBase, "brain");
  const codexDir = path.join(os.homedir(), ".codex", "sessions");

  if (targetsPayload && Array.isArray(targetsPayload.targets)) {
    const targets = targetsPayload.targets;
    const otherTargets = Array.isArray(targetsPayload.otherTargets) ? targetsPayload.otherTargets : [];
    const roots = [];

    const agyTargets = targets.filter((t) => t?.source === "antigravity");
    const agyOther = otherTargets.filter((t) => t?.source === "antigravity");
    if (agyTargets.length > 0) {
      roots.push(...matchAntigravityTargets(agyDb, agyBrain, agyTargets, agyOther, cwd, cutoffMs, now));
    }

    const codexTargets = targets.filter((t) => t?.source === "codex");
    const codexOther = otherTargets.filter((t) => t?.source === "codex");
    if (codexTargets.length > 0) {
      const sessionIndex = loadCodexSessionIndex();
      const psData = scanLiveCodexProcesses();
      const codexByCwd = new Map();
      for (const t of codexTargets) {
        const c = normalizePath(t.cwd || cwd);
        if (!c) continue;
        if (!codexByCwd.has(c)) codexByCwd.set(c, { cur: [], other: [] });
        codexByCwd.get(c).cur.push(t);
      }
      for (const t of codexOther) {
        const c = normalizePath(t.cwd || cwd);
        if (c && codexByCwd.has(c)) {
          codexByCwd.get(c).other.push(t);
        }
      }
      for (const [normCwd, group] of codexByCwd.entries()) {
        const cwdData = loadCodexCwdData(codexDir, normCwd, cutoffMs, now, sessionIndex);
        roots.push(...matchCodexTargets(group.cur, group.other, cwdData, psData, sessionIndex, normCwd, now));
      }
    }

    sortNodes(roots);
    const nameCache = loadNameCache();
    applyChineseNames(roots, nameCache, true);
    process.stdout.write(JSON.stringify({ generatedAt: now, roots }));
    return;
  }

  if (!cwd) {
    process.stdout.write(JSON.stringify({ generatedAt: now, roots: [] }));
    return;
  }

  let agyRoots = [];
  if (source === "antigravity" || source === "both" || source === "auto") {
    const fromDb = parseAntigravityFromDb(agyDb, agyBrain, cwd, cutoffMs, now);
    agyRoots = fromDb !== null ? fromDb : parseAntigravityFallback(agyBrain, cutoffMs, now);
  }

  let codexRoots = [];
  if (source === "codex" || source === "both" || source === "auto") {
    codexRoots = parseCodexScoped(codexDir, cwd, cutoffMs, now, tabHint);
  }

  let roots;
  if (source === "antigravity") roots = agyRoots;
  else if (source === "codex") roots = codexRoots;
  else if (source === "both") roots = sortNodes([...agyRoots, ...codexRoots]);
  else {
    const combined = sortNodes([...agyRoots, ...codexRoots]);
    roots = combined.slice(0, 1);
  }

  const nameCache = loadNameCache();
  applyChineseNames(roots, nameCache, true);

  process.stdout.write(JSON.stringify({ generatedAt: now, roots }));
}

main();
