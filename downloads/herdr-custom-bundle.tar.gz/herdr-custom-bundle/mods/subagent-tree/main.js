import { View, div, image, svg } from "gpui-kit";
import { v_flex, h_flex } from "gpui-base";
import {
  agents,
  terminals,
  panes,
  spaces,
  focused,
  exec,
  layout,
  theme,
  window,
  checking,
  appHome,
  run,
  shared,
  setShared,
} from "herdr";

const NODE_BIN = "/opt/homebrew/bin/node";
const STATUS_ORDER = ["working", "pending", "done"];
const STATUS_RANK = { working: 0, pending: 1, done: 2 };
const STATUS_LABEL = { working: "Working", pending: "Pending", done: "Done" };
const EMOJI_PALETTE = ["🦊", "🐙", "🐝", "🦉", "⚡", "🧩", "🚀", "🔮", "🐬", "🦋", "🎯", "🌟", "🐼", "🦄"];

function findNode(node, id) {
  if (node?.id === id) return node;
  for (const child of node?.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

function isSubagentsPanelVisible() {
  const root = layout();
  const panel = findNode(root, "panel");
  const body = findNode(root, "panel-body");
  return Boolean(panel && !panel.hidden && body?.active === "subagents");
}

function formatDuration(ms) {
  const sec = Math.max(0, Math.floor(ms / 1000));
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m`;
  const hrs = Math.floor(min / 60);
  return hrs < 24 ? `${hrs}h` : `${Math.floor(hrs / 24)}d`;
}

function shortenLabel(raw, maxLen = 24) {
  const s = String(raw || "agent").replace(/\s+/g, " ").trim();
  if (s.length <= maxLen) return s || "agent";
  return s.slice(0, Math.max(1, maxLen - 1)).trimEnd() + "…";
}

function hashEmoji(seed) {
  let hash = 0;
  const s = String(seed || "agent");
  for (let i = 0; i < s.length; i++) hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  return EMOJI_PALETTE[hash % EMOJI_PALETTE.length];
}

function mapHerdrStatus(st) {
  if (st === "working") return "working";
  if (st === "blocked" || st === "pending") return "pending";
  return "done";
}

function sortTree(nodes) {
  const sorted = [...nodes].sort((a, b) => {
    const d = (STATUS_RANK[a.status] ?? 2) - (STATUS_RANK[b.status] ?? 2);
    if (d !== 0) return d;
    return (b.updatedAt ?? 0) - (a.updatedAt ?? 0);
  });
  for (const n of sorted) {
    if (n.children?.length) n.children = sortTree(n.children);
  }
  return sorted;
}

function buildLiveTabAgents(tabPanes, tabAgents, space, tabObj) {
  const result = [...tabAgents];
  const seenAddrs = new Set(result.map((a) => a.address));
  for (const p of tabPanes) {
    if (!p || !p.terminal || seenAddrs.has(p.terminal)) continue;
    if (p.program?.shell || !p.program?.agent) continue;
    seenAddrs.add(p.terminal);
    result.push({
      address: p.terminal,
      pane: p.pane,
      space: space?.id || "",
      space_name: space?.name || "",
      tab: p.tab,
      tab_index: tabObj?.index || 1,
      tab_name: tabObj?.name || "",
      status: p.status || "idle",
      app: p.app || null,
      program: p.program,
      title: p.title || "",
      pane_name: p.name || null,
      seq: 0,
      pinned: false,
      focused: Boolean(p.focused),
      cwd: p.cwd || null,
    });
  }
  return result;
}

const UUID_ARG_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

function normalizeCwd(p) {
  if (!p || typeof p !== "string") return "";
  const s = p.trim().replace(/\/+$/, "");
  return s || (p.trim().startsWith("/") ? "/" : "");
}

function detectAgentSource(agent) {
  const s = `${agent?.app || ""} ${agent?.program?.key || ""} ${agent?.program?.name || ""} ${agent?.title || ""}`.toLowerCase();
  if (s.includes("antigravity") || s.includes("agy")) return "antigravity";
  if (s.includes("codex")) return "codex";
  return "other";
}

function extractConversationUuid(argv, title) {
  const args = Array.isArray(argv) ? argv : [];
  for (let i = 0; i < args.length; i++) {
    const a = String(args[i] || "");
    const convEq = a.match(/^--conversation=([0-9a-f-]{36})$/i);
    if (convEq) return convEq[1];
    if (a === "--conversation" && args[i + 1]) {
      const m = String(args[i + 1]).match(UUID_ARG_RE);
      if (m) return m[0];
    }
    if (a === "resume" && args[i + 1]) {
      const m = String(args[i + 1]).match(UUID_ARG_RE);
      if (m) return m[0];
    }
  }
  const titleStr = String(title || "");
  const tm = titleStr.match(/--conversation(?:=|\s+)([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
  if (tm) return tm[1];
  return "";
}

function buildTargetDescriptor(agent, termByAddr, paneByAddr, fallbackCwd, tabName) {
  const term = termByAddr.get(agent.address);
  const pane = paneByAddr.get(agent.address);
  const reportObj =
    term?.report && typeof term.report === "object"
      ? term.report
      : term?.status && typeof term.status === "object"
        ? term.status
        : null;
  const statusStr = agent.status || (typeof term?.status === "string" ? term.status : reportObj?.state) || "idle";
  const argv = Array.isArray(term?.foreground?.argv) ? term.foreground.argv.map((x) => String(x)) : [];
  const title = String(term?.title || agent.title || "");
  return {
    address: agent.address,
    source: detectAgentSource(agent),
    cwd: term?.foreground?.cwd || pane?.cwd || term?.cwd || agent.cwd || fallbackCwd || "",
    title,
    paneName: String(agent.pane_name || pane?.name || ""),
    tabName: String(tabName || agent.tab_name || ""),
    reportMsg: String(reportObj?.msg || ""),
    argv,
    convId: extractConversationUuid(argv, title),
    pid: typeof term?.foreground?.pid === "number" ? term.foreground.pid : null,
    status: String(statusStr),
    statusMs: typeof term?.status_ms === "number" ? term.status_ms : null,
    createdMs: typeof term?.created_ms === "number" ? term.created_ms : null,
  };
}

function detectSourceHint(liveAgents) {
  if (!Array.isArray(liveAgents) || liveAgents.length === 0) return "none";
  let hasAgy = false;
  let hasCodex = false;
  let hasOtherExplicit = false;

  for (const a of liveAgents) {
    const src = detectAgentSource(a);
    if (src === "antigravity") {
      hasAgy = true;
    } else if (src === "codex") {
      hasCodex = true;
    } else {
      const s = `${a.app || ""} ${a.program?.key || ""} ${a.program?.name || ""} ${a.title || ""}`.toLowerCase();
      if (/\b(claude|opencode|pi|gemini)\b/.test(s)) {
        hasOtherExplicit = true;
      }
    }
  }

  if (hasAgy && hasCodex) return "both";
  if (hasAgy) return "antigravity";
  if (hasCodex) return "codex";
  if (hasOtherExplicit) return "none";
  return "auto";
}

function currentTabContext() {
  const allSpaces = spaces();
  const space = allSpaces.find((s) => s.active) ?? null;
  const tabMetaById = new Map();
  for (const sp of allSpaces) {
    for (const tb of sp.tabs ?? []) {
      tabMetaById.set(tb.id, { spaceId: sp.id, spaceName: sp.name || "", tab: tb });
    }
  }

  const f = focused();
  const activeTab = f?.tab || space?.tabs?.find((t) => t.active)?.id || null;
  const tabObj = activeTab ? space?.tabs?.find((t) => t.id === activeTab) ?? null : null;
  const allPanes = panes();
  const allAgents = agents();
  const allLiveTerms = terminals().filter((t) => t.state === "live");
  const termByAddr = new Map(allLiveTerms.map((t) => [t.address, t]));
  const paneByAddr = new Map();
  for (const p of allPanes) {
    if (p?.terminal) paneByAddr.set(p.terminal, p);
  }

  const tabPanes = activeTab ? allPanes.filter((p) => p.tab === activeTab && p.terminal) : [];
  const tabAgents = activeTab ? allAgents.filter((a) => a.tab === activeTab) : [];
  const liveAgents = buildLiveTabAgents(tabPanes, tabAgents, space, tabObj);
  const hasLiveAgent = liveAgents.length > 0;
  const liveAddrs = new Set(liveAgents.map((a) => a.address));
  const liveAgentPanes = tabPanes.filter((p) => liveAddrs.has(p.terminal));
  const focusedLivePane = liveAgentPanes.find((p) => p.focused) || liveAgentPanes[0] || null;
  const focusedPane = tabPanes.find((p) => p.focused) || tabPanes[0] || null;
  const cwd = focusedLivePane?.cwd || focusedPane?.cwd || f?.cwd || space?.folder || null;
  const source = detectSourceHint(liveAgents);
  const tabName = tabObj?.named ? tabObj.name : "";
  const tabHint = [tabName, focusedLivePane?.name || ""].filter(Boolean).join(" ").trim();
  const label = tabObj?.named ? tabObj.name : cwd ? cwd.split(/[\\/]/).filter(Boolean).pop() : tabObj?.name || "";

  const targets = liveAgents.map((a) => buildTargetDescriptor(a, termByAddr, paneByAddr, cwd, tabName));
  const targetCwds = new Set(targets.map((t) => normalizeCwd(t.cwd)).filter(Boolean));
  if (cwd) targetCwds.add(normalizeCwd(cwd));

  const otherRaw = [];
  const seenOtherAddrs = new Set();
  for (const a of allAgents) {
    if (a.tab === activeTab || seenOtherAddrs.has(a.address)) continue;
    seenOtherAddrs.add(a.address);
    otherRaw.push(a);
  }
  for (const p of allPanes) {
    if (!p?.terminal || p.tab === activeTab || seenOtherAddrs.has(p.terminal)) continue;
    if (p.program?.shell || !p.program?.agent) continue;
    seenOtherAddrs.add(p.terminal);
    const tm = tabMetaById.get(p.tab);
    otherRaw.push({
      address: p.terminal,
      pane: p.pane,
      space: tm?.spaceId || "",
      space_name: tm?.spaceName || "",
      tab: p.tab,
      tab_index: tm?.tab?.index || 1,
      tab_name: tm?.tab?.named ? tm.tab.name : tm?.tab?.name || "",
      status: p.status || "idle",
      app: p.app || null,
      program: p.program,
      title: p.title || "",
      pane_name: p.name || null,
      cwd: p.cwd || null,
    });
  }

  const otherTargets = [];
  for (const a of otherRaw) {
    const meta = tabMetaById.get(a.tab);
    const otherTabName = meta?.tab?.named ? meta.tab.name : "";
    const desc = buildTargetDescriptor(a, termByAddr, paneByAddr, "", otherTabName);
    const normOtherCwd = normalizeCwd(desc.cwd);
    const sameCwd = Boolean(normOtherCwd && targetCwds.has(normOtherCwd));
    const sameSpaceSupported =
      Boolean(space?.id && (a.space === space.id || meta?.spaceId === space.id)) &&
      (desc.source === "codex" || desc.source === "antigravity");
    if (sameCwd || sameSpaceSupported) {
      otherTargets.push(desc);
    }
  }

  const contextKey = JSON.stringify([
    activeTab,
    cwd,
    source,
    tabHint,
    hasLiveAgent,
    targets.map((t) => [t.address, t.source, t.cwd, t.title, t.paneName, t.reportMsg, t.pid, t.convId]),
  ]);

  return {
    space,
    activeTab,
    tabObj,
    tabPanes,
    focusedPane,
    cwd,
    tabAgents,
    liveAgents,
    targets,
    otherTargets,
    hasLiveAgent,
    source,
    tabHint,
    label,
    contextKey,
  };
}

function isRawCliTitle(raw) {
  const s = String(raw || "").trim();
  if (!s) return true;
  if (/^[~/]|^[A-Za-z]:\\/.test(s)) return true;
  if (/\s--?[a-z0-9]/i.test(s)) return true;
  if (/^(agy|antigravity|codex|claude|opencode|gemini|zsh|bash|fish)\b/i.test(s) && s.includes(" ")) return true;
  return false;
}

function isConversationalTitle(raw) {
  const s = String(raw || "").trim();
  if (!s) return false;
  if (/^(我们现在|我有一个|请帮我|帮我|你试试|给我的|我想|能否)/.test(s)) return true;
  if (s.length > 16 && /[，。？！]/.test(s)) return true;
  return false;
}

function pickCleanAgentName(agent, scanned) {
  if (agent?.pane_name && String(agent.pane_name).trim()) {
    const pn = String(agent.pane_name).trim();
    return { name: pn, shortName: shortenLabel(pn, 24) };
  }
  const scName = scanned?.name ? String(scanned.name).trim() : "";
  const scShort = scanned?.shortName ? String(scanned.shortName).trim() : "";
  if (
    scShort &&
    (scanned?.aiNamed || /[\u4e00-\u9fff]/.test(scShort))
  ) {
    return { name: scName || scShort, shortName: shortenLabel(scShort, 24) };
  }
  if (
    scShort &&
    !/^agy-[0-9a-f]{4,}$/i.test(scShort) &&
    !/^codex-[0-9a-f]{4,}$/i.test(scShort) &&
    !isConversationalTitle(scName || scShort)
  ) {
    return { name: scName || scShort, shortName: shortenLabel(scShort, 24) };
  }
  if (agent?.title && !isRawCliTitle(agent.title) && !isConversationalTitle(agent.title)) {
    const t = String(agent.title).trim();
    return { name: t, shortName: shortenLabel(t, 24) };
  }
  const progName = agent?.program?.name || agent?.tab_name || agent?.address || "Agent";
  return { name: progName, shortName: shortenLabel(progName, 24) };
}

function buildHerdrTabNodes(tabAgents) {
  const now = Date.now();
  const allTerms = terminals();
  const listedSet = new Set(tabAgents.map((a) => a.address));

  const buildSubKids = (parentAddr) => {
    const kids = allTerms.filter((k) => k.parent === parentAddr && k.state === "live");
    return kids.map((k) => {
      const rawName = k.name || k.template || k.program?.name || k.address;
      return {
        id: `herdr:${k.address}`,
        parentId: `herdr:${parentAddr}`,
        source: k.program?.key || "herdr",
        name: rawName,
        shortName: shortenLabel(rawName, 18),
        emoji: hashEmoji(k.address),
        status: mapHerdrStatus(k.status),
        currentAction: k.status || "live",
        updatedAt: now,
        herdrAddress: k.address,
        inPane: listedSet.has(k.address),
        program: k.program || null,
        recentEvents: [],
        children: buildSubKids(k.address),
      };
    });
  };

  const nestedAddrs = new Set();
  for (const a of tabAgents) {
    const walk = (addr) => {
      for (const k of allTerms) {
        if (k.parent === addr && k.state === "live") {
          nestedAddrs.add(k.address);
          walk(k.address);
        }
      }
    };
    walk(a.address);
  }

  return tabAgents
    .filter((a) => !nestedAddrs.has(a.address))
    .map((a) => {
      const { name, shortName } = pickCleanAgentName(a, null);
      return {
        id: `herdr:${a.address}`,
        source: a.app || a.program?.key || "herdr",
        name,
        shortName,
        rawTitle: a.title || "",
        agentMeta: a,
        emoji: hashEmoji(a.address),
        status: mapHerdrStatus(a.status),
        currentAction: a.status === "working" ? a.program?.name || "working" : a.status,
        prompt: `${a.space_name || ""} / ${a.tab_name || ""}`.trim(),
        updatedAt: now,
        herdrAddress: a.address,
        inPane: true,
        program: a.program || null,
        recentEvents: [],
        children: buildSubKids(a.address),
      };
    });
}

function mergeChildren(existing, incoming) {
  const merged = [...existing];
  const seenIds = new Set(merged.map((c) => c.id));
  const seenNames = new Set(merged.map((c) => String(c.shortName || c.name).toLowerCase()));
  for (const child of incoming) {
    const keyName = String(child.shortName || child.name).toLowerCase();
    if (!seenIds.has(child.id) && !seenNames.has(keyName)) {
      merged.push(child);
      seenIds.add(child.id);
      seenNames.add(keyName);
    }
  }
  return merged;
}

function buildDemoRoots() {
  const now = Date.now();
  return [
    {
      id: "demo-agy-1",
      source: "antigravity",
      name: "架构总控",
      shortName: "架构总控",
      aiNamed: true,
      emoji: "🧭",
      status: "working",
      currentAction: "write_file",
      prompt: "构建位于 Mermaid 左侧的 Subagents 树形监控面板。",
      startedAt: now - 125_000,
      updatedAt: now - 2_000,
      model: "gemini-4-neon",
      recentEvents: [
        { tool: "invoke_subagent", summary: "界面构建" },
        { tool: "write_file", summary: "subagent-tree/main.js" },
      ],
      children: [
        {
          id: "demo-agy-sub-1",
          parentId: "demo-agy-1",
          source: "antigravity",
          name: "界面构建",
          shortName: "界面构建",
          aiNamed: true,
          emoji: "🎨",
          status: "working",
          currentAction: "gpui-kit",
          prompt: "渲染 Explorer 风格的树形列表与状态分组。",
          startedAt: now - 45_000,
          updatedAt: now - 1_000,
          recentEvents: [{ tool: "edit_file", summary: "main.js" }],
          children: [
            {
              id: "demo-agy-sub-1a",
              parentId: "demo-agy-sub-1",
              source: "antigravity",
              name: "图标生成",
              shortName: "图标生成",
              aiNamed: true,
              emoji: "✨",
              status: "done",
              currentAction: "done",
              startedAt: now - 40_000,
              updatedAt: now - 15_000,
              recentEvents: [],
              children: [],
            },
          ],
        },
        {
          id: "demo-agy-sub-2",
          parentId: "demo-agy-1",
          source: "antigravity",
          name: "单元测试",
          shortName: "单元测试",
          aiNamed: true,
          emoji: "🧪",
          status: "pending",
          currentAction: "queued",
          startedAt: now - 10_000,
          updatedAt: now - 10_000,
          recentEvents: [],
          children: [],
        },
        {
          id: "demo-agy-sub-3",
          parentId: "demo-agy-1",
          source: "antigravity",
          name: "日志探查",
          shortName: "日志探查",
          aiNamed: true,
          emoji: "🔍",
          status: "done",
          currentAction: "done",
          startedAt: now - 110_000,
          updatedAt: now - 60_000,
          recentEvents: [],
          children: [],
        },
      ],
    },
  ];
}

function pillBtn(t, id, label, active, onClick) {
  return div()
    .id(id)
    .px(7)
    .h(22)
    .flex_none()
    .flex()
    .items_center()
    .rounded(6)
    .cursor_pointer()
    .text_size(11)
    .bg(active ? t.selected : t.surface)
    .border_1()
    .border_color(active ? t.accent : t.border)
    .text_color(active ? t.foreground : t.muted)
    .hover((s) => s.bg(t.hover).text_color(t.foreground))
    .on_click(onClick)
    .child(label);
}

export default class SubagentTree extends View {
  init(_props, cx) {
    this.scannedRoots = [];
    this.scanning = false;
    this.error = null;
    this.demoMode = Boolean(shared("subagents.demo"));
    this.iconStyle = shared("subagents.iconStyle") || "agent";
    this.nodeOpen = new Map();
    this.groupOpen = new Map();
    this.namingInFlight = new Set();
    this.namingAttempted = new Set();
    this.selectedId = null;
    this.lastContextKey = "";
    this.lastActiveTab = null;
    this.cacheByContext = new Map();
    this.pendingScanCtx = null;

    if (checking()) return;

    const ctx = currentTabContext();
    this.lastContextKey = ctx.contextKey;
    this.lastActiveTab = ctx.activeTab;
    if (isSubagentsPanelVisible()) {
      this.scanLogs(cx, true, ctx);
    }

    cx.timer.every(2500, (cx) => {
      if (!isSubagentsPanelVisible()) return;
      const w = window();
      if (w && w.visible === false) return;
      this.scanLogs(cx, false, currentTabContext());
    });
  }

  scanLogs(cx, force, ctx = currentTabContext()) {
    if (this.demoMode) return;
    const hasSupportedTarget = Boolean(
      ctx.targets?.some((t) => t.source === "codex" || t.source === "antigravity")
    );
    const effectiveCwd = ctx.cwd || ctx.targets?.find((t) => t.cwd)?.cwd || "";
    if (!ctx.hasLiveAgent || !hasSupportedTarget || (!effectiveCwd && !ctx.targets?.some((t) => t.convId)) || ctx.source === "none") {
      this.scannedRoots = [];
      this.error = null;
      this.pendingScanCtx = null;
      return;
    }
    if (this.scanning) {
      if (force || ctx.contextKey !== this.lastContextKey || this.pendingScanCtx?.contextKey !== ctx.contextKey) {
        this.pendingScanCtx = ctx;
      }
      return;
    }

    const callKey = ctx.contextKey;
    this.scanning = true;
    const script = `${appHome()}/mods/subagent-tree/scan.mjs`;
    const args = [script, "--hours", "24", "--source", ctx.source];
    if (effectiveCwd) {
      args.push("--cwd", effectiveCwd);
    }
    if (ctx.tabHint) {
      args.push("--tab-hint", ctx.tabHint);
    }
    args.push("--targets-json", JSON.stringify({ targets: ctx.targets || [], otherTargets: ctx.otherTargets || [] }));

    cx.spawn(async (cx) => {
      try {
        const res = await exec(NODE_BIN, args, { timeout: 15000 });
        if (res.code === 0 && res.stdout) {
          const parsed = JSON.parse(res.stdout);
          const roots = Array.isArray(parsed?.roots) ? parsed.roots : [];
          this.cacheByContext.delete(callKey);
          this.cacheByContext.set(callKey, { roots, updatedAt: Date.now() });
          if (this.cacheByContext.size > 24) {
            const oldestKey = this.cacheByContext.keys().next().value;
            if (oldestKey !== undefined) this.cacheByContext.delete(oldestKey);
          }
          if (this.lastContextKey === callKey) {
            this.scannedRoots = roots;
            this.error = null;
            this.queueAutoNames(cx, this.scannedRoots);
          }
        } else if (res.stderr && this.lastContextKey === callKey) {
          this.error = res.stderr.trim();
        }
      } catch (e) {
        if (this.lastContextKey === callKey) this.error = String(e);
      } finally {
        this.scanning = false;
        const nextCtx = this.pendingScanCtx;
        this.pendingScanCtx = null;
        cx.notify();
        if (nextCtx && isSubagentsPanelVisible() && nextCtx.contextKey === this.lastContextKey) {
          this.scanLogs(cx, false, nextCtx);
        }
      }
    });
  }

  queueAutoNames(cx, roots) {
    if (this.demoMode || !Array.isArray(roots) || roots.length === 0) return;
    const pending = [];
    const walk = (nodes, isRoot) => {
      for (const n of nodes) {
        if (n && n.id && !n.aiNamed && !this.namingInFlight.has(n.id) && !this.namingAttempted.has(n.id)) {
          pending.push({
            id: n.id,
            isRoot,
            source: n.source || "",
            rawName: n.name || n.shortName || "",
            cwd: n.cwd || "",
            prompt: n.prompt || "",
          });
        }
        if (Array.isArray(n.children) && n.children.length > 0) {
          walk(n.children, false);
        }
      }
    };
    walk(roots, true);
    if (pending.length === 0) return;

    const batch = pending.slice(0, 12);
    for (const item of batch) {
      this.namingInFlight.add(item.id);
      this.namingAttempted.add(item.id);
    }

    const script = `${appHome()}/mods/subagent-tree/name.mjs`;
    cx.spawn(async (cx) => {
      try {
        const res = await exec(NODE_BIN, [script, JSON.stringify(batch)], { timeout: 35000 });
        if (res.code === 0 && res.stdout) {
          const parsed = JSON.parse(res.stdout);
          const names = parsed?.names && typeof parsed.names === "object" ? parsed.names : null;
          if (names) {
            const applyMap = (nodes) => {
              for (const n of nodes) {
                if (names[n.id]) {
                  n.shortName = shortenLabel(names[n.id], 16);
                  n.aiNamed = true;
                }
                if (Array.isArray(n.children) && n.children.length > 0) applyMap(n.children);
              }
            };
            applyMap(this.scannedRoots);
          }
        }
      } catch {
        // Keep Tier-1 Chinese fallback on failure
      } finally {
        for (const item of batch) this.namingInFlight.delete(item.id);
        cx.notify();
      }
    });
  }

  hasActiveDescendant(node) {
    for (const c of node.children ?? []) {
      if (c.status === "working" || c.status === "pending" || this.hasActiveDescendant(c)) return true;
    }
    return false;
  }

  isNodeOpen(node) {
    if (this.nodeOpen.has(node.id)) return this.nodeOpen.get(node.id);
    return node.status !== "done" || this.hasActiveDescendant(node);
  }

  isGroupOpen(parentId, status) {
    const key = `${parentId}::${status}`;
    if (this.groupOpen.has(key)) return this.groupOpen.get(key);
    return status !== "done";
  }

  buildCurrentTabRoots(ctx) {
    if (this.demoMode) return sortTree(buildDemoRoots());
    if (!ctx.hasLiveAgent) return [];

    const liveNodes = buildHerdrTabNodes(ctx.liveAgents);
    const result = [...liveNodes];

    for (const scanned of this.scannedRoots) {
      let match = scanned.targetAddress
        ? result.find((n) => n.herdrAddress === scanned.targetAddress)
        : null;
      if (!match && !scanned.targetAddress) {
        const scanSrc = String(scanned.source || "").toLowerCase();
        match = result.find((n) => {
          const hay = `${n.source || ""} ${n.program?.key || ""} ${n.program?.name || ""} ${n.rawTitle || ""}`.toLowerCase();
          if (scanSrc === "antigravity") return hay.includes("antigravity") || hay.includes("agy");
          if (scanSrc === "codex") return hay.includes("codex");
          return false;
        });
        if (!match && result.length === 1 && this.scannedRoots.length === 1) {
          match = result[0];
        }
      }

      if (match) {
        const clean = pickCleanAgentName(match.agentMeta, scanned);
        match.name = clean.name;
        match.shortName = clean.shortName;
        const liveStatus = match.agentMeta?.status;
        if (match.status === "working" || (!liveStatus && scanned.status === "working")) {
          match.status = "working";
        }
        match.children = mergeChildren(match.children || [], scanned.children || []);
        if (scanned.prompt) match.prompt = scanned.prompt;
        if (scanned.model) match.model = scanned.model;
        if (scanned.recentEvents?.length) match.recentEvents = scanned.recentEvents;
        if (scanned.currentAction && match.status === "working") match.currentAction = scanned.currentAction;
        if (scanned.startedAt) match.startedAt = scanned.startedAt;
        if (scanned.updatedAt) {
          match.updatedAt = match.status === "working" ? Math.max(match.updatedAt || 0, scanned.updatedAt) : scanned.updatedAt;
        }
        if (scanned.filePath) match.filePath = scanned.filePath;
        if (scanned.cwd) match.cwd = scanned.cwd;
      }
    }

    return sortTree(result);
  }

  findById(nodes, id) {
    for (const n of nodes) {
      if (n.id === id) return n;
      if (n.children?.length) {
        const hit = this.findById(n.children, id);
        if (hit) return hit;
      }
    }
    return null;
  }

  renderAgentIcon(node, isRoot, t) {
    if (isRoot && this.iconStyle === "agent") {
      if (node.program?.icon) {
        return node.program.tint
          ? svg(node.program.icon).size(14).flex_none().text_color(t.foreground)
          : image(node.program.icon).size(14).flex_none();
      }
      const key = String(node.source || "").toLowerCase();
      if (key.includes("codex")) return image("icons/codex.svg").size(14).flex_none();
      if (key.includes("antigravity") || key.includes("agy")) return image("icons/antigravity.svg").size(14).flex_none();
      if (key.includes("claude")) return image("icons/claude.svg").size(14).flex_none();
    }
    return div().w(16).flex_none().text_center().text_size(12.5).child(node.emoji || "🤖");
  }

  renderStatusDot(status, t) {
    if (status === "working") {
      return svg("mods/workspace-chrome/spinner.svg").size(11).flex_none().text_color(t.working).spin(900);
    }
    if (status === "pending") {
      return div().size(7).mx(2).flex_none().rounded(4).bg(t.ansi3 || "#d97706");
    }
    return div().size(7).mx(2).flex_none().rounded(4).bg(t.ansi2 || "#16a34a");
  }

  collectRows(nodes, depth, isRootLevel, out, t) {
    for (const node of nodes) {
      const hasKids = Boolean(node.children && node.children.length > 0);
      const open = hasKids && this.isNodeOpen(node);
      const refTime = node.status === "working"
        ? (node.startedAt ?? node.updatedAt ?? Date.now())
        : (node.updatedAt ?? node.startedAt ?? Date.now());
      const elapsed = formatDuration(Date.now() - refTime);

      out.push(
        h_flex()
          .id(`ag-${node.id}`)
          .h(28)
          .flex_none()
          .pl(8 + depth * 14)
          .pr(8)
          .gap(6)
          .items_center()
          .rounded(7)
          .cursor_pointer()
          .hover((s) => s.bg(t.hover))
          .on_click((_e, cx) => {
            this.selectedId = node.id;
            cx.notify();
          })
          .child(
            hasKids
              ? div()
                  .id(`chev-${node.id}`)
                  .w(14)
                  .h(20)
                  .flex()
                  .items_center()
                  .justify_center()
                  .flex_none()
                  .on_click((_e, cx) => {
                    cx.stop_propagation();
                    this.nodeOpen.set(node.id, !open);
                    cx.notify();
                  })
                  .child(svg(`mods/files/chevron-${open ? "down" : "right"}.svg`).size(12).text_color(t.dim))
              : div().w(14).flex_none()
          )
          .child(this.renderAgentIcon(node, isRootLevel, t))
          .child(div().flex_1().min_w(0).truncate().text_color(t.foreground).child(node.shortName || "agent"))
          .child(div().flex_none().text_size(10.5).text_color(t.dim).child(elapsed))
          .child(this.renderStatusDot(node.status, t))
      );

      if (hasKids && open) {
        for (const st of STATUS_ORDER) {
          const groupKids = node.children.filter((c) => c.status === st);
          if (groupKids.length === 0) continue;
          const gOpen = this.isGroupOpen(node.id, st);
          const gKey = `${node.id}::${st}`;

          out.push(
            h_flex()
              .id(`grp-${gKey}`)
              .h(25)
              .flex_none()
              .pl(8 + (depth + 1) * 14)
              .pr(8)
              .gap(6)
              .items_center()
              .rounded(6)
              .cursor_pointer()
              .hover((s) => s.bg(t.hover))
              .on_click((_e, cx) => {
                this.groupOpen.set(gKey, !gOpen);
                cx.notify();
              })
              .child(svg(`mods/files/chevron-${gOpen ? "down" : "right"}.svg`).size(11).flex_none().text_color(t.dim))
              .child(this.renderStatusDot(st, t))
              .child(
                div()
                  .flex_1()
                  .min_w(0)
                  .truncate()
                  .text_size(11.5)
                  .text_color(t.muted)
                  .child(`${STATUS_LABEL[st]} (${groupKids.length})`)
              )
          );

          if (gOpen) {
            this.collectRows(groupKids, depth + 2, false, out, t);
          }
        }
      }
    }
  }

  renderDetail(node, t) {
    const elapsed = formatDuration(Date.now() - (node.startedAt ?? node.updatedAt ?? Date.now()));
    const kids = node.children ?? [];
    const w = kids.filter((c) => c.status === "working").length;
    const p = kids.filter((c) => c.status === "pending").length;
    const d = kids.filter((c) => c.status === "done").length;

    return v_flex()
      .id("subagent-detail")
      .flex_1()
      .min_h(0)
      .overflow_y_scrollbar()
      .p(12)
      .gap(10)
      .child(
        h_flex()
          .gap(8)
          .items_center()
          .child(div().text_size(16).child(node.emoji || "🤖"))
          .child(div().flex_1().min_w(0).font_semibold().text_size(14).truncate().child(node.name || "agent"))
          .child(this.renderStatusDot(node.status, t))
      )
      .child(
        h_flex()
          .gap(8)
          .flex_wrap()
          .text_size(11.5)
          .text_color(t.muted)
          .child(`Source: ${node.source}`)
          .when(Boolean(node.model), (el) => el.child(`· ${node.model}`))
          .child(`· ${elapsed}`)
      )
      .when(Boolean(node.herdrAddress), (el) =>
        el.child(
          pillBtn(t, "focus-term", node.inPane ? "Focus Terminal Pane" : "Peek Subagent Terminal", true, () => {
            if (node.inPane) run("pane.focus", { terminal: node.herdrAddress });
            else run("terminal.peek", { terminal: node.herdrAddress });
          })
        )
      )
      .when(Boolean(node.cwd), (el) =>
        el.child(div().text_size(11).text_color(t.dim).truncate().child(`CWD: ${node.cwd}`))
      )
      .child(
        v_flex()
          .gap(4)
          .child(div().text_size(11).font_semibold().text_color(t.muted).child("TASK / PROMPT"))
          .child(
            div()
              .p(8)
              .rounded(6)
              .bg(t.surface)
              .border_1()
              .border_color(t.border)
              .text_size(12)
              .text_color(node.prompt ? t.foreground : t.dim)
              .child(node.prompt || "No prompt recorded.")
          )
      )
      .child(
        v_flex()
          .gap(4)
          .child(
            div()
              .text_size(11)
              .font_semibold()
              .text_color(t.muted)
              .child(`SUBAGENTS (${kids.length}) · ${w} working · ${p} pending · ${d} done`)
          )
          .when(kids.length > 0, (el) =>
            el.child(
              v_flex()
                .rounded(6)
                .border_1()
                .border_color(t.border)
                .children(
                  kids.map((kid) =>
                    h_flex()
                      .id(`detail-kid-${kid.id}`)
                      .h(28)
                      .px(8)
                      .gap(6)
                      .items_center()
                      .cursor_pointer()
                      .hover((s) => s.bg(t.hover))
                      .on_click((_e, cx) => {
                        this.selectedId = kid.id;
                        cx.notify();
                      })
                      .child(div().text_size(12).child(kid.emoji || "🤖"))
                      .child(div().flex_1().min_w(0).truncate().child(kid.shortName || "subagent"))
                      .child(div().text_size(11).text_color(t.dim).child(kid.status || "done"))
                      .child(this.renderStatusDot(kid.status, t))
                  )
                )
            )
          )
      )
      .when(Boolean(node.recentEvents?.length), (el) =>
        el.child(
          v_flex()
            .gap(4)
            .child(div().text_size(11).font_semibold().text_color(t.muted).child("RECENT TOOL CALLS"))
            .child(
              v_flex()
                .rounded(6)
                .border_1()
                .border_color(t.border)
                .children(
                  [...node.recentEvents]
                    .reverse()
                    .slice(0, 10)
                    .map((ev, i) =>
                      h_flex()
                        .id(`ev-${i}`)
                        .px(8)
                        .py(5)
                        .gap(8)
                        .items_center()
                        .text_size(11.5)
                        .child(div().font_semibold().text_color(t.foreground).child(ev.tool || "tool"))
                        .child(div().flex_1().min_w(0).truncate().text_color(t.muted).child(ev.summary || ""))
                    )
                )
            )
        )
      );
  }

  render(cx) {
    const t = theme();
    const ctx = currentTabContext();

    if (!this.demoMode && ctx.contextKey !== this.lastContextKey) {
      const tabChanged = ctx.activeTab !== this.lastActiveTab;
      this.lastContextKey = ctx.contextKey;
      this.lastActiveTab = ctx.activeTab;
      const cached = this.cacheByContext.get(ctx.contextKey);
      this.scannedRoots = cached ? cached.roots : [];
      if (tabChanged) {
        this.selectedId = null;
      }
      this.error = null;
      if (isSubagentsPanelVisible() && (!cached || Date.now() - cached.updatedAt > 2000)) {
        this.scanLogs(cx, true, ctx);
      }
    }

    const roots = this.buildCurrentTabRoots(ctx);
    const selectedNode = this.selectedId ? this.findById(roots, this.selectedId) : null;
    if (this.selectedId && !selectedNode) this.selectedId = null;

    const rows = [];
    if (!selectedNode) {
      this.collectRows(roots, 0, true, rows, t);
    }

    return v_flex()
      .id("subagent-tree")
      .size_full()
      .min_h(0)
      .rounded(10)
      .overflow_hidden()
      .bg(t.background)
      .border_1()
      .border_color(t.border)
      .text_color(t.foreground)
      .text_size(13)
      .child(
        h_flex()
          .h(42)
          .flex_none()
          .px(12)
          .gap(6)
          .items_center()
          .border_b(1)
          .border_color(t.border)
          .when(Boolean(selectedNode), (el) =>
            el
              .child(
                pillBtn(t, "subagent-back", "← 返回", false, (_e, cx) => {
                  this.selectedId = null;
                  cx.notify();
                })
              )
              .child(div().flex_1().min_w(0).font_semibold().truncate().child(selectedNode.shortName || "agent"))
          )
          .when(!selectedNode, (el) =>
            el
              .child(div().font_semibold().child("Subagents"))
              .child(div().flex_1().min_w(0).truncate().text_size(11.5).text_color(t.dim).child(ctx.label ? `· ${ctx.label}` : ""))
              .child(
                pillBtn(t, "toggle-demo", this.demoMode ? "Demo" : "Live", this.demoMode, (_e, cx) => {
                  this.demoMode = !this.demoMode;
                  setShared("subagents.demo", this.demoMode);
                  if (!this.demoMode) {
                    this.scannedRoots = [];
                    this.scanLogs(cx, true, ctx);
                  }
                  cx.notify();
                })
              )
              .child(
                pillBtn(t, "toggle-icon", this.iconStyle === "emoji" ? "Emoji" : "Icon", this.iconStyle === "emoji", (_e, cx) => {
                  this.iconStyle = this.iconStyle === "emoji" ? "agent" : "emoji";
                  setShared("subagents.iconStyle", this.iconStyle);
                  cx.notify();
                })
              )
              .child(
                pillBtn(t, "refresh-subagents", "↻", false, (_e, cx) => {
                  this.scanLogs(cx, true, ctx);
                })
              )
          )
      )
      .when(Boolean(selectedNode), (el) => el.child(this.renderDetail(selectedNode, t)))
      .when(!selectedNode, (el) =>
        el.child(
          v_flex()
            .id("subagents-list")
            .flex_1()
            .min_h(0)
            .overflow_y_scrollbar()
            .p(6)
            .children(rows)
            .when(rows.length === 0, (empty) =>
              empty.child(
                div()
                  .p(10)
                  .text_size(12)
                  .text_color(t.dim)
                  .child(
                    this.error ||
                      (!ctx.hasLiveAgent
                        ? "当前 Tab 暂无运行中的 Agent（仅在 Live 会话中展示，可点右上角 Demo 预览）"
                        : this.scanning
                          ? "正在扫描当前 Tab…"
                          : "当前 Tab 暂无活跃 Agent / Subagent（可点右上角 Demo 预览）")
                  )
              )
            )
        )
      );
  }
}
