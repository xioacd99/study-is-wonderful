#!/usr/bin/env node
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const CODEX_BIN = "/opt/homebrew/bin/codex";
const DATA_DIR = path.join(os.homedir(), ".config", "herdr-app", "data", "subagent-tree");
const CACHE_PATH = path.join(DATA_DIR, "names.json");
const SCHEMA_PATH = path.join(DATA_DIR, "name-schema.json");
const MAX_BATCH = 12;
const PRUNE_DAYS = 14;

const SCHEMA_JSON = JSON.stringify({
  type: "object",
  additionalProperties: false,
  required: ["items"],
  properties: {
    items: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["id", "name"],
        properties: {
          id: { type: "string" },
          name: { type: "string" },
        },
      },
    },
  },
});

function ensureDataDir() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(SCHEMA_PATH)) {
    fs.writeFileSync(SCHEMA_PATH, SCHEMA_JSON, "utf8");
  }
}

function loadCache() {
  try {
    const raw = fs.readFileSync(CACHE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return parsed;
    }
  } catch {
    // ignore missing/corrupt cache
  }
  return {};
}

function saveCache(cache) {
  ensureDataDir();
  const keys = Object.keys(cache);
  if (keys.length > 500) {
    const cutoff = Date.now() - PRUNE_DAYS * 86_400_000;
    for (const k of keys) {
      if ((cache[k]?.updatedAt ?? 0) < cutoff) {
        delete cache[k];
      }
    }
  }
  const tmpPath = `${CACHE_PATH}.tmp.${process.pid}`;
  fs.writeFileSync(tmpPath, JSON.stringify(cache, null, 2), "utf8");
  fs.renameSync(tmpPath, CACHE_PATH);
}

function sanitizeName(raw) {
  let s = String(raw || "")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/^["'「『【《（(]+|["'」』】》）)]+$/g, "")
    .replace(/[。，、；：！？!?.,:;·]+$/g, "")
    .trim();
  if (s.length > 14) {
    s = s.slice(0, 14).trim();
  }
  return s;
}

async function readInputItems() {
  let raw = process.argv[2] || "";
  if (!raw && !process.stdin.isTTY) {
    try {
      const chunks = [];
      for await (const chunk of process.stdin) {
        chunks.push(chunk);
      }
      raw = Buffer.concat(chunks).toString("utf8");
    } catch {
      raw = "";
    }
  }
  if (!raw.trim()) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function main() {
  ensureDataDir();
  const items = await readInputItems();
  if (items.length === 0) {
    process.stdout.write(JSON.stringify({ names: {} }));
    return;
  }

  const cache = loadCache();
  const resolved = {};
  const toGenerate = [];

  for (const item of items) {
    if (!item || typeof item.id !== "string" || !item.id) continue;
    if (cache[item.id]?.name) {
      resolved[item.id] = cache[item.id].name;
      continue;
    }
    if (toGenerate.length < MAX_BATCH) {
      toGenerate.push({
        id: item.id,
        isRoot: Boolean(item.isRoot),
        source: String(item.source || ""),
        rawName: String(item.rawName || "").slice(0, 80),
        cwd: item.cwd ? path.basename(String(item.cwd)) : "",
        prompt: String(item.prompt || "").replace(/\s+/g, " ").trim().slice(0, 260),
      });
    }
  }

  if (toGenerate.length === 0) {
    process.stdout.write(JSON.stringify({ names: resolved }));
    return;
  }

  if (!fs.existsSync(CODEX_BIN)) {
    process.stdout.write(JSON.stringify({ names: resolved }));
    return;
  }

  const prompt = [
    "你是一个代码助手可视化面板的命名器。请为下面这批 coding agent / subagent 各自生成一个极简、易读、一眼看懂在干什么的中文名称。",
    "要求：",
    "1. 每个名称控制在 4 到 10 个汉字（可附带简短数字编号或英文专有名词如 UI、API、Didi），禁止任何标点符号或引号。",
    "2. 禁止出现 'Worker #5'、'Codex ·'、'Antigravity ·'、'主任务'、'子任务' 这类机械占位词。",
    "3. 例如：'面板树形改造'、'代码审查'、'界面布局审计'、'日志解析验证'、'滴滴标注修复 1'、'懂车帝回放排查'。",
    "4. 如果同一批中有多个职责相似的子任务，请在末尾加简短编号区分（如 1、2 或 5、6）。",
    "5. 严格按 JSON Schema 返回 { items: [{ id, name }] }，保留原始 id。",
    "",
    "待命名列表：",
    JSON.stringify(toGenerate, null, 2),
  ].join("\n");

  try {
    const out = execFileSync(
      CODEX_BIN,
      [
        "exec",
        "--ephemeral",
        "--skip-git-repo-check",
        "-s",
        "read-only",
        "-c",
        'model_reasoning_effort="low"',
        "--output-schema",
        SCHEMA_PATH,
        prompt,
      ],
      {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "pipe"],
        timeout: 30000,
      }
    );

    const trimmedOut = String(out || "").trim();
    let parsedObj = null;

    // 1. Try full stdout directly (codex exec prints final message to stdout)
    if (trimmedOut.startsWith("{")) {
      try {
        const c = JSON.parse(trimmedOut);
        if (c && Array.isArray(c.items)) parsedObj = c;
      } catch {
        // try block extraction below
      }
    }

    // 2. Try single-line JSON or multi-line JSON block starting at a line with '{'
    if (!parsedObj) {
      const lines = trimmedOut.split(/\r?\n/);
      for (let i = lines.length - 1; i >= 0; i--) {
        if (!lines[i].trim().startsWith("{")) continue;
        try {
          const single = JSON.parse(lines[i].trim());
          if (single && Array.isArray(single.items)) {
            parsedObj = single;
            break;
          }
        } catch {
          try {
            const block = JSON.parse(lines.slice(i).join("\n"));
            if (block && Array.isArray(block.items)) {
              parsedObj = block;
              break;
            }
          } catch {
            // keep searching upwards
          }
        }
      }
    }

    if (parsedObj) {
      const now = Date.now();
      let dirty = false;
      for (const entry of parsedObj.items) {
        if (!entry || typeof entry.id !== "string") continue;
        const clean = sanitizeName(entry.name);
        if (!clean) continue;
        cache[entry.id] = { name: clean, updatedAt: now };
        resolved[entry.id] = clean;
        dirty = true;
      }
      if (dirty) {
        saveCache(cache);
      }
    }
  } catch {
    // Graceful fallback: return whatever was already cached
  }

  process.stdout.write(JSON.stringify({ names: resolved }));
}

main();
