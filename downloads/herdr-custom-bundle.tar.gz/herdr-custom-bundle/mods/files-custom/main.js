// A lazy file browser for the focused pane's folder, with bounded read-only previews.
// HTML and Markdown files open with the macOS default application on click.
import { View, div, svg } from "gpui-kit";
import { v_flex, h_flex, Editor, EditorState, TextView } from "gpui-base";
import { spaces, panes, focused, exec, readTextFile, watchFolder, theme, settings, window, notify, openOverlay, nextCommand, layout, checking } from "herdr";

function findNode(node, id) {
  if (node?.id === id) return node;
  for (const child of node?.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

function isFilesPanelVisible() {
  const root = layout();
  const panel = findNode(root, "panel");
  const body = findNode(root, "panel-body");
  return Boolean(panel && !panel.hidden && body?.active === "files");
}

// The panels share data in one VM, but their host tasks belong to separate copies.
const scans = globalThis[Symbol.for("herdr.repoStatus.v2")] ??= new Map();
const pendingActions = globalThis[Symbol.for("herdr.filesCustom.actions.v1")] ??= [];

const EXTERNAL_OPEN_EXTS = new Set(["html", "htm", "md", "markdown"]);

function isExternalOpen(path) {
  if (!path || !path.includes(".")) return false;
  const ext = path.split(".").pop().toLowerCase();
  return EXTERNAL_OPEN_EXTS.has(ext);
}

async function repoStatus(root, on, { after, visiting, urgent, allowInactive }, cx, current) {
  const repo = JSON.stringify([on, root]), now = Date.now();
  for (const [key, scan] of scans) {
    if (scan.pollAt <= now || (!scan.pollAt && scan.task.is_done())) scans.delete(key);
  }
  while (current()) {
    let scan = scans.get(repo);
    const pending = scan && !scan.pollAt && !scan.task.is_done();
    const reusable = scan?.status?.code === 0 && Date.now() < scan.pollAt
      && (scan.started >= after || (!urgent && Date.now() < scan.watchAt));
    if (!reusable && (!pending || (visiting && scan.started !== undefined && scan.started < after))) {
      if (!allowInactive && window()?.active === false) return null;
      const next = {};
      next.task = cx.spawn(async cx => {
        await cx.sleep(25); // Let both listeners for a watch batch join before starting Git.
        if (!allowInactive && window()?.active === false) return;
        next.started = Date.now();
        try {
          next.status = await exec("git", ["--no-optional-locks", "-c", "core.fsmonitor=false", "status", "--porcelain=v1", "-z", "--no-renames", "--untracked-files=all"], { cwd: root, on });
        } catch (error) {
          next.error = error;
        } finally {
          const finished = Date.now(), duration = finished - next.started;
          const delay = duration < 500 ? 0 : Math.min(60000, 5 * duration);
          next.watchAt = finished + delay;
          next.pollAt = finished + Math.max(10000, delay);
          if (next.status?.code !== 0 && scans.get(repo) === next) scans.delete(repo);
        }
      });
      scans.set(repo, next);
      scan = next;
    }
    // Resume through our own host task, so another copy's close cannot cancel our follow-up work.
    while (current() && !scan.pollAt && !scan.task.is_done()) await cx.sleep(50);
    if (!current()) return null;
    if (!scan.pollAt) continue; // The scanning copy closed or reloaded.
    return scan;
  }
  return null;
}

function location() {
  const space = spaces().find(s => s.active), f = focused();
  const pane = f?.pane ? panes().find(p => p.pane === f.pane) : null;
  const on = f?.pane === null ? (f.terminal?.includes("/") ? f.terminal.split("/")[0] : null) : space?.machine ?? null;
  return { cwd: pane?.cwd || f?.cwd || space?.folder, on, space: space?.id };
}
const key = () => JSON.stringify(location());
const LANG = {
  ts: "js", tsx: "js", mts: "js", cts: "js", jsx: "js", mjs: "js", cjs: "js",
  htm: "html", xml: "html", svg: "html", svelte: "html", vue: "html",
  md: "markdown", mdx: "markdown",
  toml: "yaml", yml: "yaml",
  jsonc: "json", json5: "json",
  scss: "css", less: "css",
  sh: "bash", zsh: "bash",
  py: "python", pyw: "python", pyi: "python",
  rs: "rust",
  cc: "cpp", cxx: "cpp", hpp: "cpp",
};
const PER_FOLDER = 500, TOTAL = 5000;

function previewKind(path) {
  if (!path || !path.includes(".")) return null;
  const ext = path.split(".").pop().toLowerCase();
  if (ext === "html" || ext === "htm") return "html";
  if (ext === "md" || ext === "markdown" || ext === "mdx") return "markdown";
  return null;
}

function hasRichHtmlAssets(html) {
  return /<(style|script)\b/i.test(html ?? "");
}

function sanitizeHtmlForTextView(html) {
  if (!html) return "";
  const bodyMatch = /<body[^>]*>([\s\S]*?)<\/body>/i.exec(html);
  const inner = bodyMatch ? bodyMatch[1] : html;
  return inner
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, "")
    .trim() || "(无可渲染的 HTML 正文内容，可切换「源码」或点击「浏览器」查看)";
}

function buildSyntax(t) {
  return {
    keyword: t.ansi5,
    string: t.ansi2,
    comment: t.dim,
    function: t.ansi4,
    type: t.ansi3,
    number: t.ansi1,
    constant: t.ansi6,
    boolean: t.ansi6,
    operator: t.muted,
    punctuation: t.dim,
    "string.escape": t.ansi3,
    heading: t.ansi5,
    strong: t.ansi3,
    emphasis: t.foreground,
    code: t.ansi2,
    quote: t.dim,
    list: t.ansi4,
    link: t.ansi4,
  };
}

async function directory(path, on) {
  const windowsDirectory = async () => {
    const r = await exec("powershell", ["-NoProfile", "-Command", "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); & { param($p) @(Get-ChildItem -LiteralPath $p -Force -ErrorAction Stop | Where-Object Name -ne '.git' | Select-Object -First 501 | ForEach-Object { @{ name=$_.Name; dir=($_.PSIsContainer -and (-not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -or -not $_.LinkType -or ($_.Target -and [IO.Directory]::Exists(([IO.Path]::Combine([IO.Path]::GetDirectoryName($_.FullName), $_.Target[0])))))) } }) | ConvertTo-Json -Compress } '" + path.replace(/['‘’‚‛]/g, "$&$&") + "'"], { on });
    if (r.code !== 0) throw new Error(r.stderr || "Cannot list this folder");
    const result = JSON.parse(r.stdout || "[]");
    return Array.isArray(result) ? result : [result];
  };
  if (!on && window()?.platform === "windows") return windowsDirectory();
  const script = 'n=0; for p in "$1"/* "$1"/.[!.]* "$1"/..?*; do [ -e "$p" ] || [ -L "$p" ] || continue; name=${p##*/}; [ "$name" = .git ] && continue; if [ -d "$p" ]; then kind=d; else kind=f; fi; printf "%s\\0%s\\0" "$kind" "$name"; n=$((n+1)); [ "$n" -gt 500 ] && break; done; test -d "$1"';
  let r;
  try { r = await exec("sh", ["-c", script, "files", path], { on }); }
  catch (e) {
    if (on && String(e).includes("cannot start sh: program not found")) return windowsDirectory();
    throw e;
  }
  if (r.code !== 0) throw new Error(r.stderr || "Cannot list this folder");
  const fields = r.stdout.split("\0"), out = [];
  for (let i = 0; i + 1 < fields.length; i += 2) out.push({ name: fields[i + 1], dir: fields[i] === "d" });
  return out;
}

export default class FilesCustom extends View {
  init(_props, cx) {
    this.saved = new Map();
    this.entries = new Map(); this.folders = new Set(); this.pending = new Set(); this.marks = {};
    this.rawText = null; this.previewMode = "rendered"; this.softWrap = false; this.handle = cx.focus_handle();
    this.wasVisible = isFilesPanelVisible();
    if (this.wasVisible && !checking()) this.refresh(cx);
    cx.timer.every(500, cx => this.refreshIfDue(cx));
    cx.spawn(async cx => {
      for (;;) {
        const cmd = await nextCommand();
        if (cmd === "action") this.drainActions(cx);
        else if (cmd === "refresh") this.forceRefresh(cx);
      }
    });
  }

  forceRefresh(cx) {
    if (!this.context) return;
    this.context.dirtyAt = Date.now() + 1;
    this.context.catchUp = true;
    this.refreshIfDue(cx);
  }

  drainActions(cx) {
    while (pendingActions.length) {
      const action = pendingActions.shift();
      if (!action?.path) continue;
      if (action.type === "open") {
        if (!action.on) this.openExternal(action.path, cx);
        else if (action.dir) this.toggle(action.path, cx);
        else this.show(action.path, cx);
      } else if (action.type === "preview") {
        this.show(action.path, cx);
      } else if (action.type === "renamed") {
        const { oldPath, newPath } = action;
        if (this.folders.has(oldPath)) {
          const updated = new Set();
          for (const folder of this.folders) {
            if (folder === oldPath) updated.add(newPath);
            else if (folder.startsWith(oldPath + "/")) updated.add(newPath + folder.slice(oldPath.length));
            else updated.add(folder);
          }
          this.folders = updated;
        }
        if (this.file === oldPath) {
          this.file = newPath;
        } else if (this.file?.startsWith(oldPath + "/")) {
          this.file = newPath + this.file.slice(oldPath.length);
        }
        this.forceRefresh(cx);
      }
    }
    cx.notify();
  }

  openContextMenu(path, entry) {
    openOverlay({
      mod: "files-custom-menu",
      kind: "popup",
      width: 210,
      height: 240,
      at: "pointer",
      props: {
        root: this.root ?? "",
        path,
        name: entry.name,
        dir: Boolean(entry.dir),
        on: this.on ?? null,
      },
    });
  }

  refreshIfDue(cx) {
    const visible = isFilesPanelVisible();
    const reopened = visible && !this.wasVisible;
    this.wasVisible = visible;
    const context = this.context;
    if (!visible) {
      if (context?.dirtyAt) context.catchUp = true;
      return;
    }
    if (reopened) {
      if (!context || key() !== context.key) {
        this.refresh(cx);
        return;
      }
      context.catchUp = true;
    }
    const active = window()?.active !== false;
    const refocused = active && this.windowActive === false;
    this.windowActive = active;
    if (!context) return;
    if (refocused && (context.dirtyAt || !context.watch)) context.catchUp = true;
    if (!active || this.loading) return;
    const now = Date.now();
    if (context.catchUp || (context.dirtyAt && now >= context.watchAt) || now >= context.pollAt) this.refresh(cx);
  }

  watch(root, context, cx) {
    if (context.on || context.watch?.root === root) return;
    context.watch?.pending?.cancel();
    const watch = { root };
    context.watch = watch;
    cx.spawn(async cx => {
      try {
        while (this.context === context && context.watch === watch) {
          watch.pending = watchFolder(root);
          const paths = await watch.pending;
          if (paths.length && context.watch === watch && this.current(context)) {
            context.dirtyAt = Date.now() + 1;
            this.refreshIfDue(cx);
          }
        }
      } catch {
        if (context.watch === watch) context.watch = null;
      }
    });
  }

  current(context) {
    return this.context === context && key() === context.key;
  }

  async loadFolder(path, context) {
    const { on, cwd: root } = context;
    const entries = await directory(path ? `${root}/${path}` : root, on);
    if (!this.current(context) || (path && !this.folders.has(path))) return;
    const used = [...this.entries.entries()].filter(([p]) => p !== path).reduce((n, [, e]) => n + e.length, 0);
    this.entries.set(path, entries.slice(0, Math.max(0, Math.min(PER_FOLDER, TOTAL - used))).sort((a, b) => Number(b.dir) - Number(a.dir) || a.name.localeCompare(b.name)));
    if (entries.length > PER_FOLDER || used + entries.length > TOTAL) this.limited = true;
  }

  refresh(cx) {
    const { cwd, on } = location(), next = key();
    const visiting = next !== this.context?.key;
    if (visiting) {
      if (this.context) {
        this.saved.set(this.context.key, { folders: this.folders, file: this.file });
        this.context.watch?.pending?.cancel();
      }
      const saved = this.saved.get(next);
      this.context = { key: next, cwd, on, dirtyAt: 0 }; this.root = cwd; this.on = on; this.entries = new Map(); this.folders = new Set(saved?.folders);
      this.pending = new Set(); this.marks = {}; this.show(null); this.error = null; this.limited = false;
      this.loading = false;
      if (saved?.file && (on || !isExternalOpen(saved.file))) this.show(saved.file, cx);
    }
    const context = this.context;
    const now = Date.now();
    if (!cwd) {
      context.catchUp = false;
      context.dirtyAt = 0;
      context.pollAt = now + 10000;
      return;
    }
    if (this.loading) return;
    if (context.catchUp && !context.dirtyAt) context.dirtyAt = now + 1;
    const request = {
      after: visiting ? now + 1 : context.dirtyAt || (context.lastStatus ?? -1) + 1,
      visiting,
      urgent: visiting || context.catchUp,
      allowInactive: visiting,
    };
    context.catchUp = false;
    context.pollAt = context.watchAt = now + 10000;
    this.loading = true;
    this.limited = false;
    cx.spawn(async cx => {
      try {
        this.watch(cwd, context, cx);
        const dirtyAtListing = context.dirtyAt;
        for (const path of ["", ...this.folders]) {
          if (!this.current(context)) return;
          await this.loadFolder(path, context);
        }
        const top = await exec("git", ["rev-parse", "--show-toplevel"], { cwd, on }).catch(() => null);
        if (!this.current(context)) return;
        const marks = {};
        let covered = dirtyAtListing;
        if (top?.code === 0) {
          const root = top.stdout.trim();
          const scan = await repoStatus(root, on, request, cx, () => this.context === context);
          if (!scan || !this.current(context)) return;
          const { status, started, pollAt, watchAt } = scan;
          context.lastStatus = started;
          context.pollAt = pollAt;
          context.watchAt = watchAt;
          covered = Math.min(dirtyAtListing, started);
          if (request.urgent && request.after > started) context.catchUp = true;
          if (status?.code === 0) for (const entry of status.stdout.split("\0").filter(Boolean).slice(0, TOTAL)) {
            const xy = entry.slice(0, 2);
            marks[`${root}/${entry.slice(3)}`] = xy === "??" || xy.includes("A") ? "A" : xy.includes("U") ? "U" : xy.includes("D") ? "D" : "M";
          }
        } else {
          context.watchAt = Date.now();
        }
        if (!this.current(context)) return;
        if (context.dirtyAt <= covered) context.dirtyAt = 0;
        this.marks = marks; this.error = null;
      } catch (e) { if (this.current(context)) this.error = String(e); }
      finally {
        if (this.context === context) this.loading = false;
        cx.notify();
      }
    });
  }

  toggle(path, cx) {
    if (this.folders.has(path)) {
      for (const folder of [...this.folders]) if (folder === path || folder.startsWith(path + "/")) {
        this.folders.delete(folder);
        this.entries.delete(folder);
      }
    } else {
      this.folders.add(path);
      if (!this.entries.has(path) && !this.pending.has(path)) {
        const context = this.context;
        this.pending.add(path);
        cx.spawn(async cx => {
          try { await this.loadFolder(path, context); }
          catch (e) { if (this.current(context)) this.error = String(e); }
          finally { if (this.context === context) this.pending.delete(path); cx.notify(); }
        });
      }
    }
    cx.notify();
  }

  openExternal(path, cx) {
    const fullPath = `${this.root}/${path}`;
    cx.spawn(async () => {
      try {
        const r = await exec("open", [fullPath]);
        if (r.code !== 0) {
          notify({ title: "Could not open file", body: r.stderr?.trim() || path, level: "error" });
        }
      } catch (e) {
        notify({ title: "Could not open file", body: String(e), level: "error" });
      }
    });
  }

  toggleWrap(cx) {
    this.softWrap = !this.softWrap;
    this.code?.set_soft_wrap(this.softWrap);
    cx.notify();
  }

  setPreviewMode(mode, cx) {
    this.previewMode = mode;
    cx.notify();
  }

  show(path, cx) {
    this.code?.release(); this.code = null; this.file = path; this.fileError = null;
    this.rawText = null;
    this.previewMode = previewKind(path) ? "rendered" : "source";
    if (!path || !cx) return;
    const context = this.context, root = this.root, on = this.on;
    cx.spawn(async cx => {
      try {
        const text = await readTextFile(`${root}/${path}`, { on });
        if (this.file !== path || !this.current(context)) return;
        if (text === null) { this.fileError = "This file is no longer available"; return; }
        if (text.includes("\0")) { this.fileError = "Binary file · no text preview"; return; }
        const t = theme(), font = settings(), ext = path.includes(".") ? path.split(".").pop().toLowerCase() : "txt";
        const value = text.length > 400000 ? text.slice(0, 400000) + "\n… (file truncated)" : text;
        this.rawText = value;
        this.code = EditorState.new({
          language: LANG[ext] ?? ext,
          readonly: true,
          value,
          font_family: font.font_family,
          font_size: font.font_size,
          soft_wrap: this.softWrap,
          syntax: buildSyntax(t),
        });
      } catch { if (this.file === path && this.current(context)) this.fileError = "Cannot preview this file (binary, too large, or unreadable)"; }
      finally { cx.notify(); }
    });
  }

  rows(prefix, depth, out, t) {
    if (out.length >= TOTAL || depth > 40) return out;
    for (const entry of this.entries.get(prefix) ?? []) {
      if (out.length >= TOTAL) break;
      const path = prefix ? `${prefix}/${entry.name}` : entry.name, open = this.folders.has(path), mark = this.marks[`${this.root}/${path}`];
      const external = !entry.dir && !this.on && isExternalOpen(path);
      out.push(h_flex().id(`file-${path}`).h(28).flex_none().pl(8 + depth * 18).pr(8).gap(7).items_center().rounded(7).cursor_pointer().hover(s => s.bg(t.hover))
        .on_click((_e, cx) => entry.dir ? this.toggle(path, cx) : (external ? this.openExternal(path, cx) : this.show(path, cx)))
        .on_mouse_down("right", (_e, cx) => { cx.stop_propagation(); this.openContextMenu(path, entry); })
        .child(entry.dir ? svg(`mods/files-custom/chevron-${open ? "down" : "right"}.svg`).size(12).flex_none().text_color(t.dim) : div().w(12).flex_none())
        .child(svg(`mods/files-custom/${entry.dir ? "folder" : "file"}.svg`).size(14).flex_none().text_color(t.muted))
        .child(div().flex_1().min_w(0).truncate().child(entry.name))
        .when(Boolean(mark), el => el.child(div().text_size(11).text_color(mark === "A" ? t.ansi2 : mark === "D" || mark === "U" ? t.ansi1 : t.blocked).child(mark))));
      if (entry.dir && open) this.rows(path, depth + 1, out, t);
    }
    return out;
  }

  render(cx) {
    if (!checking() && !isFilesPanelVisible()) {
      this.wasVisible = false;
      return div();
    }
    this.wasVisible = true;
    if (key() !== this.context?.key) this.refresh(cx);
    else this.refreshIfDue(cx);
    const t = theme();
    const font = this.code ? settings() : null;
    const kind = this.file ? previewKind(this.file) : null;
    const showRendered = Boolean(kind && this.previewMode === "rendered");
    const headerBtn = (id, label, active, tip, onClick) =>
      h_flex()
        .id(id)
        .h(22)
        .px(7)
        .flex_none()
        .items_center()
        .rounded(5)
        .border_1()
        .border_color(active ? t.accent : t.border)
        .bg(active ? t.selected : t.raised)
        .text_size(10.5)
        .text_color(active ? t.foreground : t.muted)
        .cursor_pointer()
        .tooltip(tip)
        .hover((s) => s.bg(t.hover).text_color(t.foreground))
        .on_click(onClick)
        .child(label);
    const modeBtn = (id, label, mode) => {
      const active = this.previewMode === mode;
      return h_flex()
        .id(id)
        .h(20)
        .px(7)
        .items_center()
        .rounded(4)
        .when(active, (el) => el.bg(t.selected))
        .text_size(10.5)
        .text_color(active ? t.foreground : t.muted)
        .cursor_pointer()
        .hover((s) => s.text_color(t.foreground))
        .on_click((_e, cx) => this.setPreviewMode(mode, cx))
        .child(label);
    };
    return v_flex().id("files").size_full().min_h(0).rounded(10).overflow_hidden().bg(t.background).border_1().border_color(t.border).text_color(t.foreground).text_size(13)
      .track_focus(this.handle)
      .on_key_down((e, cx) => {
        const isAltZ = e.keystroke === "alt-z"
          || (e.modifiers?.alt && !e.modifiers?.platform && !e.modifiers?.control && (e.key === "z" || e.key === "Z"));
        if (isAltZ && this.code && !showRendered) {
          this.toggleWrap(cx);
          cx.stop_propagation();
        }
      })
      .child(h_flex().h(42).flex_none().px(14).gap(8).items_center().border_b(1).border_color(t.border)
        .when(Boolean(this.file), el => el.child(div().id("files-back").w(20).cursor_pointer().text_color(t.muted).on_click((_e, cx) => { this.show(null); cx.notify(); }).child("←")))
        .child(div().font_semibold().child("Files"))
        .child(div().flex_1().min_w(0).truncate().text_right().text_size(12).text_color(t.dim).child(this.file ?? this.root?.split(/[\\/]/).pop() ?? ""))
        .when(Boolean(this.code && kind), (el) => el
          .child(h_flex().flex_none().p(2).gap(2).rounded(6).bg(t.raised).border_1().border_color(t.border)
            .child(modeBtn("files-mode-rendered", "效果", "rendered"))
            .child(modeBtn("files-mode-source", "源码", "source"))))
        .when(Boolean(this.code && kind === "html" && !this.on), (el) => el
          .child(headerBtn("files-open-ext", "浏览器", false, "用系统默认浏览器打开查看完整 CSS/JS 效果", (_e, cx) => this.openExternal(this.file, cx))))
        .when(Boolean(this.code && !showRendered), (el) => el
          .child(headerBtn("files-wrap", "换行", this.softWrap, "自动换行 (Alt+Z)", (_e, cx) => this.toggleWrap(cx)))))
      .when(!this.file, el => el.child(v_flex().id("files-tree").flex_1().min_h(0).overflow_y_scrollbar().p(6).children(this.rows("", 0, [], t))
        .when(Boolean(this.error) || !this.entries.get("")?.length, el => el.child(div().p(8).text_size(12).text_color(t.dim).child(this.error || (this.loading ? "Loading files…" : this.root ? "No files" : "No folder"))))
        .when(this.limited, el => el.child(div().p(8).text_size(11).text_color(t.dim).child("File list limited to 500 entries per folder and 5,000 total")))))
      .when(Boolean(this.file), el => el.child(this.code
        ? (showRendered
          ? v_flex().flex_1().min_h(0)
            .when(kind === "html" && hasRichHtmlAssets(this.rawText), (e2) => e2.child(
              h_flex().flex_none().px(12).py(5).gap(8).items_center().bg(t.raised).border_b(1).border_color(t.border)
                .child(div().flex_1().min_w(0).truncate().text_size(11).text_color(t.dim).child("内联 HTML 视图不执行 CSS/JS；复杂页面可点右上角「浏览器」查看完整效果"))))
            .child(v_flex().id("files-rendered-view").flex_1().min_h(0).overflow_y_scrollbar().p(14)
              .child(kind === "html"
                ? TextView.html("files-tv-html", sanitizeHtmlForTextView(this.rawText)).selectable(true)
                : TextView.markdown("files-tv-md", this.rawText ?? "").selectable(true)))
          : div().flex_1().min_h(0).on_mouse_down("left", () => this.handle.focus())
            .child(Editor.new(this.code).font_family(font.font_family).text_size(font.font_size).size_full()))
        : div().p(12).text_color(t.dim).child(this.fileError || "Loading file…")));
  }
}
