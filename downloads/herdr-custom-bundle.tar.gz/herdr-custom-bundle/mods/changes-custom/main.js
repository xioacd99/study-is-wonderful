import { View, div, svg, list } from "gpui-kit";
import { v_flex, h_flex, InputState, Input, Scrollbar, v_virtual_list } from "gpui-base";
import { spaces, panes, focused, exec, readTextFile, watchFolder, theme, settings, window, openOverlay, shared, setShared, layout, checking } from "herdr";
import { detectLang, tokenizeLine, syntaxPalette } from "./highlight.js";

function findNode(node, id) {
  if (node?.id === id) return node;
  for (const child of node?.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

function isChangesPanelVisible() {
  const root = layout();
  const panel = findNode(root, "panel");
  const body = findNode(root, "panel-body");
  return Boolean(panel && !panel.hidden && body?.active === "changes");
}

// The panels share data in one VM, but their host tasks belong to separate copies.
const scans = globalThis[Symbol.for("herdr.repoStatus.v2")] ??= new Map();

async function repoStatus(root, on, { after, visiting, urgent, allowInactive }, cx, current) {
  const repo = JSON.stringify([on, root]), now = Date.now();
  for (const [key, scan] of scans) {
    if (scan.pollAt <= now || (!scan.pollAt && scan.task.is_done())) scans.delete(key);
  }
  while (current()) {
    let scan = scans.get(repo);
    const pending = scan && !scan.pollAt && !scan.task.is_done();
    const reusable = scan?.status?.code === 0 && Date.now() < scan.pollAt
      && (scan.started >= after || (!urgent && Date.now() < scan.watchAt));
    if (!reusable && (!pending || (visiting && scan.started !== undefined && scan.started < after))) {
      if (!allowInactive && window()?.active === false) return null;
      const next = {};
      next.task = cx.spawn(async cx => {
        await cx.sleep(25); // Let both listeners for a watch batch join before starting Git.
        if (!allowInactive && window()?.active === false) return;
        next.started = Date.now();
        try {
          next.status = await exec("git", ["--no-optional-locks", "-c", "core.fsmonitor=false", "status", "--porcelain=v1", "-z", "--no-renames", "--untracked-files=all"], { cwd: root, on });
        } catch (error) {
          next.error = error;
        } finally {
          const finished = Date.now(), duration = finished - next.started;
          const delay = duration < 500 ? 0 : Math.min(60000, 5 * duration);
          next.watchAt = finished + delay;
          next.pollAt = finished + Math.max(10000, delay);
          if (next.status?.code !== 0 && scans.get(repo) === next) scans.delete(repo);
        }
      });
      scans.set(repo, next);
      scan = next;
    }
    // Resume through our own host task, so another copy's close cannot cancel our follow-up work.
    while (current() && !scan.pollAt && !scan.task.is_done()) await cx.sleep(50);
    if (!current()) return null;
    if (!scan.pollAt) continue; // The scanning copy closed or reloaded.
    return scan;
  }
  return null;
}

function location() {
  const space = spaces().find((s) => s.active), f = focused();
  const pane = f?.pane ? panes().find(p => p.pane === f.pane) : null;
  const on = f?.pane === null ? (f.terminal?.includes("/") ? f.terminal.split("/")[0] : null) : space?.machine ?? null;
  return { cwd: pane?.cwd || f?.cwd || space?.folder, on };
}
const key = () => JSON.stringify(location());
// Reads write nothing under .git (no index refresh or lock, no fsmonitor cookie):
// the folder watch would see it, and every refresh would start the next one.
const READ = ["--no-optional-locks", "-c", "core.fsmonitor=false", "-c", "diff.autoRefreshIndex=false"];
const countLines = (text) => text ? text.split("\n").length - Number(text.endsWith("\n")) : 0;
const wideGlyph = /[\p{Ideographic}\p{Emoji_Presentation}\p{Extended_Pictographic}\u1100-\u115f\u2e80-\ua4cf\uac00-\ud7a3\ufe10-\ufe19\ufe30-\ufe6f\uff01-\uff60\uffe0-\uffe6]/gu;

// Keep room for spacing marks and give wide glyphs at least two columns.
function displayColumns(text) {
  let columns = text.length;
  for (const glyph of text.match(wideGlyph) ?? []) {
    if (glyph.length === 1) columns++;
  }
  return columns;
}

// The diff was laid out for 11px text: 20px rows, 7px characters.
const rowHeight = size => Math.ceil(size * 1.8), charWidth = size => size * 0.64;

// Text draws a tab as nothing: pad each to the next 4-column stop.
const untab = (text) => text.replace(/[^\t]*\t/g, (s) => s.slice(0, -1).padEnd((s.length - 1) - (s.length - 1) % 4 + 4));

// Numbers each diff line once, so a frame only draws the rows on screen.
function diffRows(lines) {
  let old = 0, next = 0;
  return lines.map((line) => {
    const match = /^@@ -(\d+)(?:,\d+)? \+(\d+)/.exec(line);
    if (match) { old = +match[1]; next = +match[2]; return { kind: "@", text: line }; }
    const kind = line[0];
    if (kind === "-") return { kind, number: old++, text: untab(line.slice(1)) || " " };
    if (kind === "+") return { kind, number: next++, text: untab(line.slice(1)) || " " };
    if (kind === " ") { old++; return { kind, number: next++, text: untab(line.slice(1)) || " " }; }
    return { kind: "", text: line };
  });
}

function buildFileTree(files) {
  const root = { name: "", path: "", dirs: new Map(), files: [], count: 0 };
  for (const f of files) {
    const parts = f.path.split("/");
    const name = parts.pop();
    let cur = root;
    let curPath = "";
    cur.count++;
    for (const part of parts) {
      curPath = curPath ? `${curPath}/${part}` : part;
      let child = cur.dirs.get(part);
      if (!child) {
        child = { name: part, path: curPath, dirs: new Map(), files: [], count: 0 };
        cur.dirs.set(part, child);
      }
      cur = child;
      cur.count++;
    }
    cur.files.push({ name, file: f });
  }
  const compact = (node) => {
    const compactedDirs = new Map();
    for (const [, d] of node.dirs) {
      let cur = d;
      let label = cur.name;
      while (cur.dirs.size === 1 && cur.files.length === 0) {
        const next = cur.dirs.values().next().value;
        label = `${label}/${next.name}`;
        cur = next;
      }
      const nextNode = compact(cur);
      nextNode.name = label;
      compactedDirs.set(nextNode.path, nextNode);
    }
    return { ...node, dirs: compactedDirs };
  };
  return compact(root);
}

function flattenTree(node, collapsed, depth = 0, out = []) {
  const dirs = [...node.dirs.values()].sort((a, b) => a.name.localeCompare(b.name));
  for (const dir of dirs) {
    const isOpen = !collapsed.has(dir.path);
    out.push({ kind: "dir", depth, path: dir.path, name: dir.name, count: dir.count, open: isOpen });
    if (isOpen) flattenTree(dir, collapsed, depth + 1, out);
  }
  const files = [...node.files].sort((a, b) => a.name.localeCompare(b.name));
  for (const item of files) {
    out.push({ kind: "file", depth, name: item.name, file: item.file });
  }
  return out;
}

function collectDirPaths(node, out = []) {
  for (const dir of node.dirs.values()) {
    out.push(dir.path);
    collectDirPaths(dir, out);
  }
  return out;
}

export default class ChangesCustom extends View {
  init(_props, cx) {
    this.files = []; this.rows = []; this.lang = null; this.longest = 0; this.gutterChars = 4; this.message = ""; this.handle = cx.focus_handle();
    this.query = ""; this.searchFocused = false; this.diffMode = "normal"; this.collapsedDirs = new Set();
    this.searchInput = InputState.new({ placeholder: "Search changed files…" });
    this.searchInput.on("change", (_e, cx) => {
      this.query = this.searchInput.value();
      cx.notify();
    });
    this.searchInput.on("submit", (_e, cx) => {
      const first = this.filteredFiles()[0];
      if (first) {
        if (this.diffMode === "collapsed") this.diffMode = "normal";
        this.pick(first.path, cx, true);
      }
    });
    this.searchInput.on("focus", (_e, cx) => { this.searchFocused = true; cx.notify(); });
    this.searchInput.on("blur", (_e, cx) => { this.searchFocused = false; cx.notify(); });

    this.input = InputState.new({ placeholder: "Commit message" });
    this.input.on("change", (_e, cx) => {
      const hadMessage = Boolean(this.message.trim());
      this.message = this.input.value();
      if (hadMessage !== Boolean(this.message.trim())) cx.notify();
    });
    this.input.on("submit", (_e, cx) => this.commit(cx));
    this.input.on("focus", (_e, cx) => { this.typing = true; cx.notify(); });
    this.input.on("blur", (_e, cx) => { this.typing = false; cx.notify(); });
    this.wasVisible = isChangesPanelVisible();
    if (this.wasVisible && !checking()) this.refresh(cx);
    cx.timer.every(500, cx => this.refreshIfDue(cx));
  }

  refreshIfDue(cx) {
    const visible = isChangesPanelVisible();
    const reopened = visible && !this.wasVisible;
    this.wasVisible = visible;
    const context = this.context;
    if (!visible) {
      if (context?.dirtyAt) context.catchUp = true;
      return;
    }
    if (reopened) {
      if (!context || key() !== context.key) {
        this.refresh(cx);
        return;
      }
      context.catchUp = true;
    }
    const active = window()?.active !== false;
    const refocused = active && this.windowActive === false;
    this.windowActive = active;
    if (!context) return;
    if (refocused && (context.dirtyAt || !context.watch)) context.catchUp = true;
    if (!active || this.loading || this.busy) return;
    const now = Date.now();
    if (context.catchUp || (context.dirtyAt && now >= context.watchAt) || now >= context.pollAt) this.refresh(cx);
  }

  watch(root, context, cx) {
    if (context.on || context.watch?.root === root) return;
    context.watch?.pending?.cancel();
    const watch = { root };
    context.watch = watch;
    cx.spawn(async cx => {
      try {
        while (this.context === context && context.watch === watch) {
          watch.pending = watchFolder(root);
          const paths = await watch.pending;
          if (paths.length && context.watch === watch && this.current(context)) {
            context.dirtyAt = Date.now() + 1;
            this.refreshIfDue(cx);
          }
        }
      } catch {
        if (context.watch === watch) context.watch = null;
      }
    });
  }

  // One visit to a folder: results from an earlier visit to the same folder are stale too.
  current(context) {
    return this.context === context && key() === context.key;
  }

  filteredFiles() {
    const tokens = this.query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    if (!tokens.length) return this.files;
    return this.files.filter((f) => {
      const lower = f.path.toLowerCase();
      return tokens.every((tok) => lower.includes(tok));
    });
  }

  clearSearch(cx) {
    if (!this.query) return;
    this.query = "";
    this.searchInput.set_value("");
    cx.notify();
  }

  setViewMode(mode, cx) {
    setShared("changes.viewMode", mode);
    cx.notify();
  }

  toggleDir(path, cx) {
    if (this.collapsedDirs.has(path)) this.collapsedDirs.delete(path);
    else this.collapsedDirs.add(path);
    cx.notify();
  }

  expandAllDirs(cx) {
    this.collapsedDirs.clear();
    cx.notify();
  }

  collapseAllDirs(dirPaths, cx) {
    this.collapsedDirs = new Set(dirPaths);
    cx.notify();
  }

  toggleCollapse(cx) {
    this.diffMode = this.diffMode === "collapsed" ? "normal" : "collapsed";
    cx.notify();
  }

  toggleMaximize(cx) {
    this.diffMode = this.diffMode === "maximized" ? "normal" : "maximized";
    cx.notify();
  }

  toggleWrap(cx) {
    setShared("changes.wordWrap", !Boolean(shared("changes.wordWrap")));
    cx.notify();
  }

  openFullscreen() {
    if (!this.root) return;
    openOverlay({
      mod: "changes-diff-fullscreen",
      kind: "dialog",
      width: 0.92,
      height: 0.9,
      props: {
        root: this.root,
        on: this.on ?? null,
        hasHead: Boolean(this.hasHead),
        files: this.files,
        open: this.open,
      },
    });
  }

  refresh(cx, force = false) {
    const { cwd, on } = location(), next = key();
    const visiting = next !== this.context?.key;
    if (visiting) {
      this.context?.watch?.pending?.cancel();
      this.context = { key: next, on, dirtyAt: 0 }; this.root = null; this.files = []; this.open = null;
      this.setLines([]); this.message = ""; this.input.set_value(""); this.error = null; this.note = null; this.closed = false; this.limited = false;
      this.query = ""; this.searchInput.set_value(""); this.diffMode = "normal"; this.collapsedDirs.clear();
      this.loading = false;
    }
    // A load left behind in another folder (a slow git, a read that never ends) must not hold this one.
    const context = this.context;
    const now = Date.now();
    if (!cwd) {
      context.catchUp = false;
      context.dirtyAt = 0;
      context.pollAt = now + 10000;
      return;
    }
    if (this.loading || this.busy) return;
    if (force || (context.catchUp && !context.dirtyAt)) context.dirtyAt = now + 1;
    const request = {
      after: visiting ? now + 1 : context.dirtyAt || (context.lastStatus ?? -1) + 1,
      visiting,
      urgent: force || visiting || context.catchUp,
      allowInactive: force || visiting,
    };
    context.catchUp = false;
    context.pollAt = context.watchAt = now + 10000;
    this.loading = true;
    cx.spawn(async (cx) => {
      try {
        const top = await exec("git", ["rev-parse", "--show-toplevel"], { cwd, on });
        if (!this.current(context)) return;
        if (top.code !== 0) { this.root = null; this.files = []; this.setLines([]); this.open = null; this.error = "Not a git repository"; return; }
        const root = top.stdout.trim(), git = (args) => exec("git", [...READ, ...args], { cwd: root, on });
        this.watch(root, context, cx);
        const scan = await repoStatus(root, on, request, cx, () => this.context === context);
        if (!scan || !this.current(context)) return;
        const { status, started, pollAt, watchAt } = scan;
        context.lastStatus = started;
        context.pollAt = pollAt;
        context.watchAt = watchAt;
        // A failed scan still answers the edit that asked for it: retrying at once would spin.
        if (context.dirtyAt <= started) context.dirtyAt = 0;
        if (scan.error) throw scan.error;
        if (status.code !== 0) throw new Error(status.stderr);
        if (request.urgent && request.after > started) context.catchUp = true;
        const entries = status.stdout.split("\0").filter(Boolean), shown = entries.slice(0, 1000);
        const tracked = shown.some(entry => !entry.startsWith("??"));
        const hasHead = tracked && (await git(["rev-parse", "--verify", "HEAD"])).code === 0;
        const stats = {};
        const results = !tracked ? [] : hasHead ? [await git(["diff", "HEAD", "--numstat", "-z", "--no-renames"])] : [await git(["diff", "--cached", "--numstat", "-z", "--no-renames"]), await git(["diff", "--numstat", "-z", "--no-renames"])];
        for (const result of results) {
          if (result.code !== 0) throw new Error(result.stderr);
          for (const entry of result.stdout.split("\0")) {
            const [a, d, ...parts] = entry.split("\t");
            if (!parts.length) continue;
            const path = parts.join("\t"), old = stats[path] ?? { add: 0, del: 0 };
            stats[path] = { add: old.add + (Number(a) || 0), del: old.del + (Number(d) || 0), binary: a === "-" };
          }
        }
        const files = [];
        for (const entry of shown) {
          const xy = entry.slice(0, 2), path = entry.slice(3), fresh = xy === "??";
          const conflict = xy.includes("U") || xy === "AA" || xy === "DD";
          const s = conflict ? "U" : xy.includes("D") ? "D" : fresh || xy.includes("A") ? "A" : "M";
          const stat = stats[path] ?? { add: 0, del: 0 };
          files.push({ path, status: s, fresh, ...stat });
        }
        if (!this.current(context)) return;
        this.root = root; this.on = on; this.hasHead = hasHead; this.files = files; this.limited = entries.length > 1000; this.error = null;
        if (this.open && !files.some((f) => f.path === this.open)) { this.open = null; this.setLines([]); }
        // The first file's diff shows until you pick another.
        if (!this.open && !this.closed && files.length) this.open = files[0].path;
        if (this.open) {
          try { await this.load(this.open, context); }
          catch { if (this.current(context)) this.setLines(["Cannot preview this diff (too large or unreadable)"]); }
        }
      } catch (e) { if (this.current(context)) this.error = String(e); }
      finally {
        if (this.context === context) this.loading = false;
        cx.notify();
      }
    });
  }

  async load(path, context) {
    const file = this.files.find((f) => f.path === path), root = this.root, on = this.on;
    if (!file) return;
    let lines;
    if (file.fresh || (!this.hasHead && file.status === "A")) {
      const text = await readTextFile(`${root}/${path}`, { on }).catch(() => null);
      if (text === null) lines = ["Cannot preview this file (binary, too large, or unreadable)"];
      else if (text.includes("\0")) lines = ["Binary file · no text diff"];
      else {
        file.add = countLines(text);
        lines = [`@@ -0,0 +1,${file.add} @@`, ...text.slice(0, 400000).replace(/\n$/, "").split("\n").slice(0, 1500).map(l => `+${l}`)];
      }
    } else {
      const r = await exec("git", [...READ, "diff", ...(this.hasHead ? ["HEAD"] : []), "--no-ext-diff", "--no-textconv", "--no-color", "--", path], { cwd: root, on });
      if (r.code !== 0) throw new Error(r.stderr);
      const all = r.stdout.replace(/\n$/, "").split("\n"), first = all.findIndex((l) => l.startsWith("@@"));
      lines = first < 0 ? [file.binary ? "Binary file changed" : "No text diff available"] : all.slice(first);
    }
    if (this.current(context) && this.open === path) this.setLines(lines.slice(0, 1500).map(line => line.length > 4000 ? line.slice(0, 4000) + "… (line truncated)" : line));
  }

  setLines(lines) {
    this.lang = detectLang(this.open);
    this.rows = diffRows(lines);
    this.longest = Math.max(0, ...this.rows.map(row => displayColumns(row.text)));
    this.gutterChars = Math.max(4, String(Math.max(0, ...this.rows.map(row => row.number ?? 0))).length);
  }

  pick(path, cx, forceOpen = false) {
    if (!forceOpen && this.diffMode === "collapsed") {
      this.diffMode = "normal";
      forceOpen = true;
    }
    this.open = !forceOpen && this.open === path ? null : path;
    this.setLines([]);
    this.note = null;
    this.closed = !this.open;
    const context = this.context;
    if (this.open) cx.spawn(async (cx) => {
      try { await this.load(path, context); }
      catch (e) { if (this.current(context) && this.open === path) this.note = `Cannot preview this diff (too large or unreadable): ${e}`; }
      cx.notify();
    });
    cx.notify();
  }

  commit(cx) {
    if (!this.message.trim() || !this.root || this.busy || this.loading || this.context?.key !== key()) return;
    const root = this.root, on = this.on, context = this.context, message = this.message.trim();
    this.busy = true; this.note = null;
    cx.spawn(async (cx) => {
      try {
        for (const args of [["add", "-A"], ["commit", "-m", message]]) {
          const r = await exec("git", args, { cwd: root, on });
          if (r.code !== 0) throw new Error((r.stderr || r.stdout).trim());
        }
        if (this.current(context)) { this.message = ""; this.input.set_value(""); }
      } catch (e) { if (this.current(context)) this.note = `Commit failed: ${e}`; }
      finally { this.busy = false; this.refresh(cx, true); cx.notify(); }
    });
    cx.notify();
  }

  gutter(size) { return Math.ceil(this.gutterChars * charWidth(size)) + 2; }

  diffRow(row, t, size, wrap) {
    const { kind, number, text } = row;
    const height = rowHeight(size);
    if (kind === "@") {
      if (wrap) return div().w_full().px(12).py(3).bg(t.raised).text_color(t.dim).whitespace_normal().child(text);
      return div().w_full().px(12).h(height).flex_none().truncate().bg(t.raised).text_color(t.dim).child(text);
    }
    const tokens = (row.tokens ??= tokenizeLine(text, this.lang));
    const pal = syntaxPalette(t);
    let content;
    if (tokens.length <= 1) {
      const tok = tokens[0];
      const base = div().flex_1().min_w(0);
      const styled = wrap ? base.whitespace_normal() : base.truncate();
      content = (tok?.c ? styled.text_color(pal[tok.c]) : styled).child(tok ? tok.t : text);
    } else if (wrap) {
      content = h_flex().flex_1().min_w(0).flex_wrap().items_start().children(
        tokens.map((tok) => {
          const el = div().max_w_full().whitespace_normal().child(tok.t);
          return tok.c ? el.text_color(pal[tok.c]) : el;
        }),
      );
    } else {
      content = h_flex().flex_1().min_w(0).overflow_hidden().items_center().children(
        tokens.map((tok) => {
          const el = div().flex_none().whitespace_nowrap().child(tok.t);
          return tok.c ? el.text_color(pal[tok.c]) : el;
        }),
      );
    }
    const baseRow = wrap
      ? h_flex().w_full().min_h(height).items_start().py(1).pr(10).gap(10)
      : h_flex().w_full().h(height).flex_none().gap(10);
    return baseRow
      .when(kind === "+", (e) => e.bg(t.ansi2 + "18"))
      .when(kind === "-", (e) => e.bg(t.ansi1 + "18"))
      .child(div().w(this.gutter(size)).flex_none().text_right().text_color(t.dim).child(number === undefined ? "" : String(number)))
      .child(content);
  }

  renderFlatRow(f, t) {
    const parts = f.path.split("/"), name = parts.pop();
    return h_flex().id(`change-${f.path}`).h(28).flex_none().px(8).gap(8).items_center().rounded(7).cursor_pointer()
      .when(this.open === f.path, (e) => e.bg(t.selected))
      .hover((s) => s.bg(t.hover))
      .on_click((_e, cx) => this.pick(f.path, cx))
      .child(div().w(14).text_size(11).text_color(f.status === "A" ? t.ansi2 : f.status === "D" ? t.ansi1 : f.status === "U" ? t.ansi1 : t.blocked).child(f.status))
      .child(h_flex().flex_1().min_w(0).child(div().text_color(t.dim).truncate().child(parts.length ? parts.join("/") + "/" : "")).child(div().max_w(260).min_w(0).truncate().child(name)))
      .when(f.add > 0, (e) => e.child(div().text_size(11).text_color(t.ansi2).child(`+${f.add}`)))
      .when(f.del > 0, (e) => e.child(div().text_size(11).text_color(t.ansi1).child(`−${f.del}`)));
  }

  renderTreeRow(row, t) {
    if (row.kind === "dir") {
      return h_flex().id(`change-dir-${row.path}`).h(28).flex_none().pl(8 + row.depth * 14).pr(8).gap(5).items_center().rounded(7).cursor_pointer()
        .hover((s) => s.bg(t.hover))
        .on_click((_e, cx) => this.toggleDir(row.path, cx))
        .child(svg(`mods/files-custom/chevron-${row.open ? "down" : "right"}.svg`).size(11).flex_none().text_color(t.dim))
        .child(svg("mods/files-custom/folder.svg").size(13).flex_none().text_color(t.muted))
        .child(div().flex_1().min_w(0).truncate().text_size(12).text_color(t.muted).child(row.name))
        .child(div().text_size(10).text_color(t.dim).child(String(row.count)));
    }
    const f = row.file;
    return h_flex().id(`change-tfile-${f.path}`).h(28).flex_none().pl(8 + row.depth * 14 + 16).pr(8).gap(6).items_center().rounded(7).cursor_pointer()
      .when(this.open === f.path, (e) => e.bg(t.selected))
      .hover((s) => s.bg(t.hover))
      .on_click((_e, cx) => this.pick(f.path, cx))
      .child(div().w(12).flex_none().text_size(11).text_color(f.status === "A" ? t.ansi2 : f.status === "D" ? t.ansi1 : f.status === "U" ? t.ansi1 : t.blocked).child(f.status))
      .child(div().flex_1().min_w(0).truncate().child(row.name))
      .when(f.add > 0, (e) => e.child(div().text_size(11).text_color(t.ansi2).child(`+${f.add}`)))
      .when(f.del > 0, (e) => e.child(div().text_size(11).text_color(t.ansi1).child(`−${f.del}`)));
  }

  render(cx) {
    if (!checking() && !isChangesPanelVisible()) {
      this.wasVisible = false;
      return div();
    }
    this.wasVisible = true;
    if (key() !== this.context?.key) this.refresh(cx);
    else this.refreshIfDue(cx);
    const t = theme(), size = settings().font_size, add = this.files.reduce((n, f) => n + f.add, 0), del = this.files.reduce((n, f) => n + f.del, 0);
    const enabled = Boolean(this.message.trim() && this.root && !this.busy && !this.loading);
    const filtered = this.filteredFiles();
    const wrap = Boolean(shared("changes.wordWrap"));
    const viewMode = shared("changes.viewMode") === "tree" ? "tree" : "flat";
    const tree = viewMode === "tree" ? buildFileTree(filtered) : null;
    const treeRows = tree ? flattenTree(tree, this.collapsedDirs) : [];
    const dirPaths = tree ? collectDirPaths(tree) : [];
    const listRowCount = viewMode === "tree" ? treeRows.length : filtered.length;
    const openFile = this.files.find((f) => f.path === this.open);

    const actionBtn = (id, label, active, tip, onClick) =>
      h_flex()
        .id(id)
        .h(20)
        .px(7)
        .flex_none()
        .items_center()
        .rounded(5)
        .border_1()
        .border_color(active ? t.accent : t.border)
        .bg(active ? t.selected : t.background)
        .text_size(10.5)
        .text_color(active ? t.foreground : t.muted)
        .cursor_pointer()
        .tooltip(tip)
        .hover((s) => s.bg(t.hover).text_color(t.foreground))
        .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
        .on_click((e, cx) => { cx.stop_propagation(); onClick(e, cx); })
        .child(label);

    const modeBtn = (id, label, mode, tip) => {
      const active = viewMode === mode;
      return h_flex()
        .id(id)
        .h(22)
        .px(7)
        .items_center()
        .rounded(5)
        .when(active, (el) => el.bg(t.selected))
        .text_size(10.5)
        .text_color(active ? t.foreground : t.muted)
        .cursor_pointer()
        .tooltip(tip)
        .hover((s) => s.text_color(t.foreground))
        .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
        .on_click((_e, cx) => { cx.stop_propagation(); this.setViewMode(mode, cx); })
        .child(label);
    };

    return v_flex().id("changes").size_full().min_h(0).rounded(10).overflow_hidden().bg(t.background).border_1().border_color(t.border).text_color(t.foreground).text_size(13).track_focus(this.handle)
      .on_key_down((e, cx) => {
        const isAltZ = e.keystroke === "alt-z"
          || (e.modifiers?.alt && !e.modifiers?.platform && !e.modifiers?.control && (e.key === "z" || e.key === "Z"));
        if (isAltZ) {
          this.toggleWrap(cx);
          cx.stop_propagation();
          return;
        }
        if (e.key === "escape") {
          if (this.searchFocused) {
            if (this.query) { this.query = ""; this.searchInput.set_value(""); }
            else { this.searchFocused = false; this.handle.focus(); }
            cx.stop_propagation();
            cx.notify();
          } else if (this.typing) {
            this.typing = false;
            this.handle.focus();
            cx.stop_propagation();
            cx.notify();
          }
        }
      })
      .child(h_flex().h(42).flex_none().px(14).gap(8).items_center().border_b(1).border_color(t.border)
        .child(div().font_semibold().child("Changes"))
        .child(div().px(5).py(1).rounded(4).border_1().border_color(t.border).text_size(10).text_color(t.muted).child(`${this.files.length} files`))
        .child(div().flex_1()).child(div().text_size(11).text_color(t.ansi2).child(`+${add}`)).child(div().text_size(11).text_color(t.ansi1).child(`−${del}`)))
      .when(this.diffMode !== "maximized", (el) => el
        .child(h_flex().id("changes-search-bar").flex_none().px(10).py(6).gap(6).items_center().border_b(1).border_color(t.border)
          .child(h_flex().id("changes-search").flex_1().min_w(0).h(28).px(8).gap(6).items_center().rounded(7).bg(t.input).border_1().border_color(this.searchFocused ? t.accent : t.border).cursor_text()
            .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
            .child(svg("mods/workspace-chrome/search.svg").size(13).flex_none().text_color(t.dim))
            .child(Input.new(this.searchInput).flex_1().min_w(0).h_full().text_size(12).text_color(t.foreground))
            .when(Boolean(this.query), (e2) => e2
              .child(div().text_size(10).text_color(t.dim).child(`${filtered.length}/${this.files.length}`))
              .child(div().id("changes-search-clear").w(18).h(18).flex().items_center().justify_center().rounded(4).cursor_pointer().hover((s) => s.bg(t.hover))
                .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
                .on_click((_e, cx) => { cx.stop_propagation(); this.clearSearch(cx); })
                .child(svg("mods/workspace-chrome/x.svg").size(11).text_color(t.muted)))))
          .child(h_flex().flex_none().p(2).gap(2).rounded(7).bg(t.raised).border_1().border_color(t.border)
            .child(modeBtn("changes-mode-flat", "列表", "flat", "平铺列表展示"))
            .child(modeBtn("changes-mode-tree", "树形", "tree", "树形项目结构展示"))))
        .when(viewMode === "tree" && dirPaths.length > 0, (e2) => e2
          .child(h_flex().id("changes-tree-actions").h(26).flex_none().px(10).gap(6).items_center().bg(t.raised).border_b(1).border_color(t.border)
            .child(div().flex_1().text_size(10.5).text_color(t.dim).child(`${dirPaths.length} 个文件夹`))
            .child(actionBtn("changes-tree-expand-all", "全部展开", false, "一键展开所有文件夹", (_e, cx) => this.expandAllDirs(cx)))
            .child(actionBtn("changes-tree-collapse-all", "全部折叠", false, "一键折叠所有文件夹", (_e, cx) => this.collapseAllDirs(dirPaths, cx)))))
        // overflow_y_scrollbar() wraps the list, so its flex sizing never reached the panel's layout.
        .child(div().flex_1().min_h(44)
          .when(this.diffMode !== "collapsed", (e2) => e2.max_h(Math.max(44, listRowCount * 28 + 12)).border_b(1).border_color(t.border))
          .relative()
          .child(v_flex().id("changes-list").absolute().inset_0().overflow_y_scroll().p(6)
            .children(
              viewMode === "tree"
                ? treeRows.map((row) => this.renderTreeRow(row, t))
                : filtered.map((f) => this.renderFlatRow(f, t)),
            )
            .when(!filtered.length, (e) => e.child(div().p(8).text_color(t.dim).child(
              this.files.length
                ? "No matching files"
                : (this.error || (this.loading ? "Loading changes…" : this.root ? "No uncommitted changes" : "No folder")),
            ))))
          .child(Scrollbar.vertical("changes-list").absolute().inset_0()))
        .when(this.limited, el => el.child(div().px(12).py(4).text_size(11).text_color(t.dim).child("Showing the first 1,000 changed files"))))
      .child(h_flex().id("changes-diff-bar").h(30).flex_none().px(10).gap(6).items_center().bg(t.raised)
        .when(this.diffMode === "collapsed", (el) => el.border_t(1).border_color(t.border))
        .when(this.diffMode !== "collapsed", (el) => el.border_b(1).border_color(t.border))
        .child(h_flex().id("changes-diff-toggle").flex_1().min_w(0).gap(6).items_center().cursor_pointer()
          .on_click((_e, cx) => this.toggleCollapse(cx))
          .child(svg(this.diffMode === "collapsed" ? "mods/files-custom/chevron-right.svg" : "mods/files-custom/chevron-down.svg").size(12).flex_none().text_color(t.dim))
          .child(div().flex_1().min_w(0).truncate().text_size(11.5).font_medium().text_color(openFile ? t.foreground : t.dim).child(openFile ? openFile.path : "Diff"))
          .when(Boolean(openFile && openFile.add > 0), (el) => el.child(div().text_size(10.5).text_color(t.ansi2).child(`+${openFile.add}`)))
          .when(Boolean(openFile && openFile.del > 0), (el) => el.child(div().text_size(10.5).text_color(t.ansi1).child(`−${openFile.del}`))))
        .child(actionBtn("changes-diff-wrap", "换行", wrap, "自动换行 (Alt+Z)", (_e, cx) => this.toggleWrap(cx)))
        .child(actionBtn("changes-diff-collapse", this.diffMode === "collapsed" ? "展开" : "收起", this.diffMode === "collapsed", this.diffMode === "collapsed" ? "展开 Diff 区域" : "折叠 Diff 区域", (_e, cx) => this.toggleCollapse(cx)))
        .child(actionBtn("changes-diff-maximize", this.diffMode === "maximized" ? "还原" : "放大", this.diffMode === "maximized", this.diffMode === "maximized" ? "恢复列表显示" : "在面板内全高展示 Diff", (_e, cx) => this.toggleMaximize(cx)))
        .when(this.files.length > 0, (el) => el.child(actionBtn("changes-diff-fullscreen", "全屏", false, "在全屏弹窗中查看 Diff", () => this.openFullscreen()))))
      .when(this.diffMode !== "collapsed", (el) => el
        .child(div().flex_1().min_h(0).relative().font_family(settings().font_family ?? "JetBrains Mono").text_size(size)
          .on_mouse_down("left", () => this.handle.focus())
          .when(!wrap, (e2) => e2
            .child(div().id("changes-diff-x").size_full().overflow_x_scrollbar()
              .child(div().w_full().min_w(Math.max(300, this.longest * charWidth(size) + this.gutter(size) + 20)).h_full().child(v_virtual_list("changes-diff", this.rows.length, rowHeight(size), (i) => String(i),
                (range) => this.rows.slice(range.start, range.end).map((row) => this.diffRow(row, t, size, false))).size_full())))
            .child(Scrollbar.vertical("changes-diff").viewport_from_layout().absolute().inset_0()))
          .when(wrap, (e2) => e2
            .child(list("changes-diff-wrap", this.rows.length, (i) => `${this.open ?? ""}:${i}`, (i) =>
              this.diffRow(this.rows[i], t, size, true)).size_full())
            .child(Scrollbar.vertical("changes-diff-wrap").absolute().inset_0()))
          .when(!this.open && this.files.length > 0, (e) => e.child(div().absolute().top(6).px(12).text_size(11).text_color(t.dim).child("Select a file to view its changes")))))
      .when(Boolean(this.note), (e) => e.child(div().px(10).pb(8).text_size(11).text_color(t.ansi1).child(this.note)))
      .child(h_flex().flex_none().p(10).gap(8).border_t(1).border_color(t.border)
        .child(div().id("commit-message").flex_1().min_w(0).h(32).px(10).flex().items_center().rounded(8).border_1().border_color(this.typing ? t.accent : t.border).cursor_text().on_mouse_down("left", (_e, cx) => cx.stop_propagation()).child(Input.new(this.input).h_full().text_size(12).text_color(t.foreground)))
        .child(div().id("commit").h(32).px(14).flex().items_center().rounded(8).bg(enabled ? t.solid : t.raised).text_color(enabled ? t.solid_foreground : t.dim).text_size(12).when(enabled, (e) => e.cursor_pointer()).on_click((_e, cx) => this.commit(cx)).child(this.busy ? "Committing…" : "Commit")));
  }
}
