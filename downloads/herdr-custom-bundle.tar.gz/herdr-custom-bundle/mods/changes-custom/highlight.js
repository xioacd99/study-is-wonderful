// Fast single-pass O(n) line tokenizer for diff syntax highlighting.
// Designed to be called lazily per visible row and memoized on the row object.

const EXT_LANG = {
  js: "js", mjs: "js", cjs: "js", jsx: "js",
  ts: "js", mts: "js", cts: "js", tsx: "js",
  py: "py", pyw: "py", pyi: "py",
  rs: "rs",
  go: "go",
  c: "c", h: "c", cc: "c", cpp: "c", cxx: "c", hpp: "c", java: "c", kt: "c", swift: "c", cs: "c",
  sh: "sh", bash: "sh", zsh: "sh", fish: "sh",
  json: "json", jsonc: "json", json5: "json",
  yml: "yaml", yaml: "yaml", toml: "yaml",
  css: "css", scss: "css", less: "css",
  html: "html", htm: "html", xml: "html", svg: "html", vue: "html", svelte: "html",
  md: "md", markdown: "md", mdx: "md",
  sql: "sql",
};

const KEYWORDS = {
  js: new Set([
    "as", "async", "await", "break", "case", "catch", "class", "const", "continue",
    "debugger", "default", "delete", "do", "else", "enum", "export", "extends",
    "finally", "for", "from", "function", "if", "implements", "import", "in",
    "instanceof", "interface", "let", "new", "of", "package", "private",
    "protected", "public", "return", "static", "super", "switch", "throw", "try",
    "type", "typeof", "var", "void", "while", "with", "yield",
  ]),
  py: new Set([
    "and", "as", "assert", "async", "await", "break", "class", "continue", "def",
    "del", "elif", "else", "except", "finally", "for", "from", "global", "if",
    "import", "in", "is", "lambda", "match", "nonlocal", "not", "or", "pass",
    "raise", "return", "try", "while", "with", "yield",
  ]),
  rs: new Set([
    "as", "async", "await", "break", "const", "continue", "crate", "dyn", "else",
    "enum", "extern", "fn", "for", "if", "impl", "in", "let", "loop", "match",
    "mod", "move", "mut", "pub", "ref", "return", "self", "Self", "static",
    "struct", "super", "trait", "type", "unsafe", "use", "where", "while",
  ]),
  go: new Set([
    "break", "case", "chan", "const", "continue", "default", "defer", "else",
    "fallthrough", "for", "func", "go", "goto", "if", "import", "interface",
    "map", "package", "range", "return", "select", "struct", "switch", "type", "var",
  ]),
  c: new Set([
    "auto", "break", "case", "class", "const", "continue", "default", "do", "else",
    "enum", "export", "extends", "extern", "final", "for", "fun", "goto", "if",
    "implements", "import", "inline", "interface", "namespace", "new", "override",
    "package", "private", "protected", "public", "return", "sizeof", "static",
    "struct", "switch", "template", "throw", "throws", "try", "typedef", "typename",
    "union", "using", "val", "var", "virtual", "void", "volatile", "while",
  ]),
  sh: new Set([
    "case", "do", "done", "elif", "else", "esac", "export", "fi", "for", "function",
    "if", "in", "local", "readonly", "return", "select", "then", "until", "while",
  ]),
  sql: new Set([
    "AND", "AS", "ASC", "BY", "CASE", "CREATE", "DELETE", "DESC", "DISTINCT",
    "DROP", "ELSE", "END", "FROM", "GROUP", "HAVING", "IN", "INDEX", "INNER",
    "INSERT", "INTO", "IS", "JOIN", "LEFT", "LIMIT", "NOT", "NULL", "ON", "OR",
    "ORDER", "OUTER", "RIGHT", "SELECT", "SET", "TABLE", "THEN", "UPDATE", "VALUES",
    "WHEN", "WHERE",
    "and", "as", "asc", "by", "case", "create", "delete", "desc", "distinct",
    "drop", "else", "end", "from", "group", "having", "in", "index", "inner",
    "insert", "into", "is", "join", "left", "limit", "not", "null", "on", "or",
    "order", "outer", "right", "select", "set", "table", "then", "update", "values",
    "when", "where",
  ]),
};

const CONSTANTS = new Set([
  "true", "false", "null", "undefined", "NaN", "Infinity", "this", "super",
  "True", "False", "None", "self", "nil", "iota",
]);

const BUILTIN_TYPES = new Set([
  "string", "number", "boolean", "object", "symbol", "bigint", "any", "unknown", "never",
  "int", "int8", "int16", "int32", "int64", "uint", "uint8", "uint16", "uint32", "uint64",
  "float", "float32", "float64", "double", "char", "bool", "byte", "rune",
  "i8", "i16", "i32", "i64", "i128", "isize", "u8", "u16", "u32", "u64", "u128", "usize",
  "f32", "f64", "str", "String", "Vec", "Option", "Result", "Map", "Set", "Array", "Promise",
]);

const MAX_HIGHLIGHT_CHARS = 600;
const MAX_SPANS = 60;

export function detectLang(path) {
  if (!path) return null;
  const base = path.split("/").pop() ?? "";
  if (base === "Dockerfile" || base.startsWith("Dockerfile.")) return "sh";
  if (base === "Makefile" || base === "justfile") return "sh";
  const dot = base.lastIndexOf(".");
  if (dot < 0) return null;
  return EXT_LANG[base.slice(dot + 1).toLowerCase()] ?? null;
}

export function syntaxPalette(t) {
  return {
    keyword: t.ansi5,
    string: t.ansi2,
    comment: t.dim,
    function: t.ansi4,
    type: t.ansi3,
    number: t.ansi1,
    constant: t.ansi6,
  };
}

function pushToken(out, text, color) {
  if (!text) return;
  const prev = out[out.length - 1];
  if (prev && prev.c === color) {
    prev.t += text;
    return;
  }
  out.push({ t: text, c: color });
}

const isIdentStart = (ch) =>
  (ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z") || ch === "_" || ch === "$";

const isIdentChar = (ch) =>
  isIdentStart(ch) || (ch >= "0" && ch <= "9");

const isDigit = (ch) => ch >= "0" && ch <= "9";

const isHexDigit = (ch) =>
  isDigit(ch) || (ch >= "a" && ch <= "f") || (ch >= "A" && ch <= "F");

function scanString(line, start, quote) {
  let i = start + 1;
  while (i < line.length) {
    const ch = line[i];
    if (ch === "\\" && i + 1 < line.length) {
      i += 2;
      continue;
    }
    if (ch === quote) {
      i++;
      break;
    }
    i++;
  }
  return i;
}

function tokenizeMarkdown(line) {
  const out = [];
  const trimmed = line.trimStart();
  if (trimmed.startsWith("#") && /^#{1,6}\s/.test(trimmed)) {
    return [{ t: line, c: "keyword" }];
  }
  if (trimmed.startsWith(">")) {
    return [{ t: line, c: "comment" }];
  }
  if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
    return [{ t: line, c: "comment" }];
  }
  const limit = Math.min(line.length, MAX_HIGHLIGHT_CHARS);
  let i = 0;
  while (i < limit && out.length < MAX_SPANS) {
    if (line[i] === "`") {
      const end = line.indexOf("`", i + 1);
      if (end > i) {
        pushToken(out, line.slice(i, end + 1), "string");
        i = end + 1;
        continue;
      }
    }
    if (line[i] === "[" && line.indexOf("](", i + 1) > i) {
      const closeBracket = line.indexOf("]", i + 1);
      if (closeBracket > i && line[closeBracket + 1] === "(") {
        const closeParen = line.indexOf(")", closeBracket + 2);
        if (closeParen > closeBracket) {
          pushToken(out, line.slice(i, closeBracket + 1), "type");
          pushToken(out, line.slice(closeBracket + 1, closeParen + 1), "function");
          i = closeParen + 1;
          continue;
        }
      }
    }
    let next = i + 1;
    while (next < limit && line[next] !== "`" && line[next] !== "[") next++;
    pushToken(out, line.slice(i, next), null);
    i = next;
  }
  if (i < line.length) pushToken(out, line.slice(i), null);
  return out;
}

export function tokenizeLine(line, lang) {
  if (!line || !lang) return [{ t: line, c: null }];
  if (lang === "md") return tokenizeMarkdown(line);

  const kw = KEYWORDS[lang];
  const hashComment = lang === "py" || lang === "sh" || lang === "yaml";
  const slashComment = lang === "js" || lang === "rs" || lang === "go" || lang === "c" || lang === "css" || lang === "json";
  const dashComment = lang === "sql";
  const limit = Math.min(line.length, MAX_HIGHLIGHT_CHARS);
  const out = [];
  let i = 0;

  while (i < limit && out.length < MAX_SPANS) {
    const ch = line[i];

    // Comments
    if (slashComment && ch === "/" && line[i + 1] === "/") {
      pushToken(out, line.slice(i), "comment");
      return out;
    }
    if (slashComment && ch === "/" && line[i + 1] === "*") {
      const end = line.indexOf("*/", i + 2);
      if (end >= 0) {
        pushToken(out, line.slice(i, end + 2), "comment");
        i = end + 2;
        continue;
      }
      pushToken(out, line.slice(i), "comment");
      return out;
    }
    if (hashComment && ch === "#") {
      pushToken(out, line.slice(i), "comment");
      return out;
    }
    if (dashComment && ch === "-" && line[i + 1] === "-") {
      pushToken(out, line.slice(i), "comment");
      return out;
    }
    if (lang === "html" && line.startsWith("<!--", i)) {
      const end = line.indexOf("-->", i + 4);
      if (end >= 0) {
        pushToken(out, line.slice(i, end + 3), "comment");
        i = end + 3;
        continue;
      }
      pushToken(out, line.slice(i), "comment");
      return out;
    }

    // HTML tags
    if (lang === "html" && ch === "<" && (isIdentStart(line[i + 1] ?? "") || line[i + 1] === "/")) {
      let j = i + 1;
      if (line[j] === "/") j++;
      const nameStart = j;
      while (j < limit && (isIdentChar(line[j]) || line[j] === "-" || line[j] === ":")) j++;
      if (j > nameStart) {
        pushToken(out, line.slice(i, nameStart), null);
        pushToken(out, line.slice(nameStart, j), "keyword");
        i = j;
        continue;
      }
    }

    // Strings
    if (ch === '"' || ch === "'" || (ch === "`" && (lang === "js" || lang === "sh" || lang === "go"))) {
      const end = scanString(line, i, ch);
      let color = "string";
      if (lang === "json" && ch === '"') {
        let k = end;
        while (k < line.length && (line[k] === " " || line[k] === "\t")) k++;
        if (line[k] === ":") color = "function";
      }
      pushToken(out, line.slice(i, end), color);
      i = end;
      continue;
    }

    // Numbers
    if (isDigit(ch) || (ch === "." && isDigit(line[i + 1] ?? ""))) {
      let j = i;
      if (ch === "0" && (line[j + 1] === "x" || line[j + 1] === "X")) {
        j += 2;
        while (j < limit && (isHexDigit(line[j]) || line[j] === "_")) j++;
      } else {
        while (j < limit && (isDigit(line[j]) || line[j] === "." || line[j] === "_")) j++;
        if (j < limit && (line[j] === "e" || line[j] === "E")) {
          j++;
          if (line[j] === "+" || line[j] === "-") j++;
          while (j < limit && isDigit(line[j])) j++;
        }
      }
      pushToken(out, line.slice(i, j), "number");
      i = j;
      continue;
    }

    // Identifiers / keywords / types / functions
    if (isIdentStart(ch)) {
      let j = i + 1;
      while (j < limit && isIdentChar(line[j])) j++;
      const word = line.slice(i, j);
      let color = null;
      if (kw?.has(word)) color = "keyword";
      else if (CONSTANTS.has(word)) color = "constant";
      else if (BUILTIN_TYPES.has(word)) color = "type";
      else if (lang === "yaml") {
        let k = j;
        while (k < line.length && (line[k] === " " || line[k] === "\t")) k++;
        if (line[k] === ":") color = "function";
      } else {
        let k = j;
        while (k < line.length && (line[k] === " " || line[k] === "\t")) k++;
        if (line[k] === "(") color = "function";
        else if (word[0] >= "A" && word[0] <= "Z" && /[a-z]/.test(word)) color = "type";
      }
      pushToken(out, word, color);
      i = j;
      continue;
    }

    // Plain run (punctuation, operators, whitespace, CJK, etc.)
    let j = i + 1;
    while (j < limit) {
      const c = line[j];
      if (
        isIdentStart(c) || isDigit(c) ||
        c === '"' || c === "'" || c === "`" ||
        c === "/" || c === "#" || c === "-" || c === "<" || c === "."
      ) break;
      j++;
    }
    pushToken(out, line.slice(i, j), null);
    i = j;
  }

  if (i < line.length) pushToken(out, line.slice(i), null);
  return out;
}
