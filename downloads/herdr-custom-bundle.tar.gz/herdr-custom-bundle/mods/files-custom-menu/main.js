import { View, div, svg } from "gpui-kit";
import { v_flex, h_flex } from "gpui-base";
import { run, props, closeOverlay, openOverlay, theme, notify } from "herdr";

const pendingActions = (globalThis[Symbol.for("herdr.filesCustom.actions.v1")] ??= []);

function buildItems(p) {
  const items = [
    {
      id: "open",
      label: "打开",
      icon: p.dir ? "mods/files-custom/folder.svg" : "mods/files-custom/file.svg",
    },
  ];
  if (!p.dir && !p.on) {
    items.push({
      id: "preview",
      label: "预览",
      icon: "mods/workspace-chrome/file-text.svg",
    });
  }
  items.push(
    {
      id: "rename",
      label: "重命名",
      icon: "mods/workspace-chrome/square-pen.svg",
    },
    {
      id: "copy-abs",
      label: "复制绝对路径",
      icon: "mods/workspace-chrome/files.svg",
      sep: true,
    },
    {
      id: "copy-rel",
      label: "复制相对路径",
      icon: "mods/workspace-chrome/files.svg",
    },
  );
  return items;
}

function toAbsolutePath(root, rel) {
  if (!root) return rel ?? "";
  if (!rel) return root;
  return root === "/" ? `/${rel}` : `${root.replace(/\/+$/, "")}/${rel}`;
}

export default class FilesCustomMenu extends View {
  init(_props, cx) {
    this.at = 0;
    this.handle = cx.focus_handle();
    this.handle.focus();
  }

  choose(i, cx) {
    const p = props() ?? {};
    const list = buildItems(p);
    const it = list[i];
    if (!it) return;

    if (it.id === "open") {
      pendingActions.push({ type: "open", path: p.path, dir: Boolean(p.dir), on: p.on ?? null });
      run("files-custom.action");
      closeOverlay(p.overlay);
      return;
    }

    if (it.id === "preview") {
      pendingActions.push({ type: "preview", path: p.path, dir: Boolean(p.dir), on: p.on ?? null });
      run("files-custom.action");
      closeOverlay(p.overlay);
      return;
    }

    if (it.id === "rename") {
      closeOverlay(p.overlay);
      openOverlay({
        mod: "files-custom-rename",
        kind: "dialog",
        width: 420,
        height: 225,
        props: {
          root: p.root ?? "",
          path: p.path ?? "",
          name: p.name ?? "",
          dir: Boolean(p.dir),
          on: p.on ?? null,
        },
      });
      return;
    }

    if (it.id === "copy-abs") {
      const absPath = toAbsolutePath(p.root ?? "", p.path ?? "");
      cx.write_to_clipboard(absPath);
      notify({ title: "已复制绝对路径", body: absPath, level: "info", timeout: 2000 });
      closeOverlay(p.overlay);
      return;
    }

    if (it.id === "copy-rel") {
      const rel = p.path ?? "";
      cx.write_to_clipboard(rel);
      notify({ title: "已复制相对路径", body: rel, level: "info", timeout: 2000 });
      closeOverlay(p.overlay);
    }
  }

  render() {
    const t = theme();
    const p = props() ?? {};
    const list = buildItems(p);
    return v_flex()
      .id("files-custom-menu")
      .track_focus(this.handle)
      .w_full()
      .min_h(0)
      .p(5)
      .bg(t.popover)
      .text_size(12.8)
      .on_key_down((e, cx) => {
        if (e.key === "down") this.at = (this.at + 1) % list.length;
        else if (e.key === "up") this.at = (this.at + list.length - 1) % list.length;
        else if (e.key === "enter") {
          this.choose(this.at, cx);
          return;
        } else if (e.key === "escape") {
          closeOverlay(p.overlay);
          return;
        } else return;
        cx.notify();
      })
      .children(
        list.map((it, i) =>
          v_flex()
            .when(Boolean(it.sep), (el) => el.child(div().mx(7).my(4).h(1).bg(t.border)))
            .child(
              h_flex()
                .id(`fcm-${it.id}`)
                .h(31)
                .px(8)
                .gap(9)
                .rounded(7)
                .items_center()
                .cursor_pointer()
                .text_color(t.foreground)
                .when(i === this.at, (el) => el.bg(t.selected))
                .hover((s) => s.bg(t.hover))
                .on_click((_e, cx) => this.choose(i, cx))
                .child(svg(it.icon).size(14).flex_none().text_color(t.muted))
                .child(div().flex_1().truncate().child(it.label)),
            ),
        ),
      );
  }
}
