import { View, div } from "gpui-kit";
import { agents, panes, spaces, layout, run, exec, hc, home, appHome, nextCommand, checking, shared, setShared } from "herdr";
import { Engine as AsksEngine } from "./engine.js";
import { loadConfig as loadAsksConfig, update as updateAsks } from "./state.js";

const DEFAULT_PANELS = ["files", "changes", "subagents", "mermaid", "asks"];

function isAsksEnabled() {
  const saved = shared("mods.panels");
  if (!Array.isArray(saved)) return DEFAULT_PANELS.includes("asks");
  return saved.includes("asks");
}

const notifierBin = () => `${home()}/Applications/HerdrNotify.app/Contents/MacOS/HerdrNotify`;
const PRE_RENDERED_ICONS = new Set([
  "antigravity",
  "claude",
  "codex",
  "opencode",
  "qoder",
  "cursor",
  "gemini",
  "copilot",
  "pi",
  "agent",
]);

function findNode(node, id) {
  if (node?.id === id) return node;
  for (const child of node?.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

function seedDemoAsks() {
  const activeSpace = spaces().find((s) => s.active) ?? spaces()[0] ?? null;
  const spaceId = activeSpace?.id ?? null;
  const spaceName = activeSpace?.name ?? "herdr-app";
  const folder = activeSpace?.folder ?? appHome();
  const sampleAgent = agents().find((a) => a.focused) ?? agents()[0] ?? null;
  const prog = sampleAgent?.program
    ? { key: sampleAgent.program.key, name: sampleAgent.program.name, icon: sampleAgent.program.icon, tint: sampleAgent.program.tint }
    : { key: "claude", name: "Claude Code", icon: "icons/claude.svg", tint: false };
  const now = Date.now();
  const demos = [
    {
      id: "demo:approval:1",
      demo: true,
      address: sampleAgent?.address ?? "demo-1",
      pane: sampleAgent?.pane ?? null,
      space: spaceId,
      space_name: spaceName,
      agent: "后端重构 Agent",
      program: prog,
      app: "claude-code",
      cwd: folder,
      turn: 1,
      msg: "",
      detected_at: now - 45000,
      state: "pending",
      delivery: "keys",
      kind: "APPROVAL",
      question: "是否允许执行数据库迁移脚本 `npm run db:migrate -- --env=staging`？",
      options: [
        { n: 1, label: "Yes, allow once", detail: "仅本次允许执行" },
        { n: 2, label: "Allow for this session", detail: "本会话内不再询问同类命令" },
        { n: 3, label: "Deny", detail: "拒绝执行，让 Agent 换方案" },
      ],
      recommended: 0,
      context: "已完成 schema.prisma 修改并生成 migration SQL，需要执行一次迁移以验证测试。",
      raw: "",
      source: "demo",
      confidence: 1,
      enriched: true,
      answer: null,
      answered_at: null,
      error: null,
      note: null,
    },
    {
      id: "demo:decision:2",
      demo: true,
      address: sampleAgent?.address ?? "demo-2",
      pane: sampleAgent?.pane ?? null,
      space: spaceId,
      space_name: spaceName,
      agent: "前端登录页 Agent",
      program: { key: "codex", name: "Codex", icon: "icons/codex.svg", tint: false },
      app: "codex",
      cwd: folder,
      turn: 2,
      msg: "",
      detected_at: now - 20000,
      state: "pending",
      delivery: "send",
      kind: "DECISION",
      question: "Token 刷新策略想用哪种方案？",
      options: [
        { n: 1, label: "方案 A：Silent Refresh + HttpOnly Cookie", send: "用方案 A：Silent Refresh + HttpOnly Cookie", detail: "安全性最高，推荐生产环境" },
        { n: 2, label: "方案 B：AccessToken 存内存 + 手动重新登录", send: "用方案 B：AccessToken 存内存 + 手动重新登录", detail: "实现最简单，适合内部工具" },
      ],
      recommended: 0,
      context: "当前 API 网关已支持 `/auth/refresh`，但需要确认前端持久化策略。",
      raw: "",
      source: "demo",
      confidence: 1,
      enriched: true,
      answer: null,
      answered_at: null,
      error: null,
      note: null,
    },
    {
      id: "demo:question:3",
      demo: true,
      address: sampleAgent?.address ?? "demo-3",
      pane: sampleAgent?.pane ?? null,
      space: spaceId,
      space_name: spaceName,
      agent: "单测修复 Agent",
      program: prog,
      app: "antigravity",
      cwd: folder,
      turn: 3,
      msg: "",
      detected_at: now - 5000,
      state: "pending",
      delivery: "send",
      kind: "QUESTION",
      question: "旧版 `/v1/orders` 接口的兼容测试已经全部报错，是要修兼容层还是直接删掉旧测试？",
      options: [
        { n: 1, label: "保留兼容层并修复测试", send: "保留兼容层并修复测试", detail: "" },
        { n: 2, label: "直接移除旧 v1 测试", send: "直接移除旧 v1 测试", detail: "" },
      ],
      recommended: null,
      context: "可以直接点击选项，或者点右侧发送图标输入自定义回复。",
      raw: "",
      source: "demo",
      confidence: 1,
      enriched: true,
      answer: null,
      answered_at: null,
      error: null,
      note: null,
    },
  ];
  updateAsks((s) => {
    s.asks = [...demos, ...s.asks.filter((a) => !a.demo)];
  });
  run("layout.select", { stack: "panel-body", child: "asks" });
  run("layout.show", { id: "panel" });
}

function clearDemoAsks() {
  updateAsks((s) => {
    s.asks = s.asks.filter((a) => !a.demo);
  });
}

function togglePanel(target) {
  const root = layout();
  const panel = findNode(root, "panel");
  const body = findNode(root, "panel-body");
  if (!panel || !body) return;
  const isOn = !panel.hidden && body.active === target;
  if (isOn) {
    run("layout.hide", { id: "panel" });
  } else {
    run("layout.select", { stack: "panel-body", child: target });
    run("layout.show", { id: "panel" });
  }
}

const cleanTitle = (s) =>
  (s ?? "")
    .replace(/^[^\p{L}\p{N}\p{Ps}\p{Pi}]+/u, "")
    .replace(/^\[ [!.] \] /, "")
    .trim();

function leadPanes(allPanes) {
  const leads = new Map();
  for (const p of allPanes) {
    if (!p.terminal) continue;
    const current = leads.get(p.tab);
    if (!current || (!current.program?.agent && (p.program?.agent || (!current.focused && p.focused)))) {
      leads.set(p.tab, p);
    }
  }
  return leads;
}

function resolveTabLabel(agent, tabMap, leads) {
  const tab = tabMap.get(agent.tab);
  const lead = leads.get(agent.tab);
  const prog = lead?.program?.name ?? agent.program?.name;
  if (!tab) return agent.tab_name || prog || "Tab";
  const base = tab.named ? tab.name : (prog ?? tab.name ?? String(tab.index ?? "1"));
  if (!lead?.program?.agent && !agent.program?.agent) return base;
  const rawTitle = lead?.title ?? agent.title ?? "";
  const live = cleanTitle(rawTitle);
  const isPath = /^[~/]|^[A-Za-z]:\\/.test(rawTitle.replace(/^[^\p{L}\p{N}~/]+/u, ""));
  const telling =
    live &&
    live !== (lead?.terminal ?? agent.address) &&
    live !== prog &&
    !isPath &&
    !live.includes("@") &&
    live.toLowerCase() !== (lead?.program?.key ?? agent.program?.key ?? "");
  return (tab.name === prog || !tab.named) && telling ? live : (tab.name || base);
}

const DIVIDER_RE = /^[\s─━═\-_┄┈╌╍╭╮╰╯┌┐└┘┬┴┼├┤]{8,}$/;
const PROMPT_LINE_RE = /^\s*[>❯›$#%]\s*(.*)$/;
const FOOTER_CHROME_RE =
  /(auto\s*·|Orchestrator\b|Swarm\(|shift\+tab|\?\s*for shortcuts|bypass permissions|esc to interrupt|esc to cancel|\balt\+[a-z0-9]|\bctrl\+[a-z0-9]|%\s*context\b|%\s*left\b|tokens?\s*used|context\s*window)/i;
const SHELL_PROMPT_RE = /^[^\s@]+@[^\s:]+:[^\n]*[$#%]\s*$/;
const QUESTION_OR_APPROVAL_RE =
  /([?？]\s*$|\b(allow|approve|confirm|proceed|permission|waiting|accept|reject|deny|select|choose|y\/n)\b|是否|确认|允许|授权|批准|请选择|请输入|等待.*输入)/i;

function stripAnsi(text) {
  return String(text ?? "")
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, "")
    .replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "")
    .replace(/\r/g, "");
}

function isPureChromeLine(trimmed) {
  if (!trimmed) return true;
  if (DIVIDER_RE.test(trimmed)) return true;
  if (/^[╭╮╰╯┌┐└┘│┃┆┊]+$/.test(trimmed)) return true;
  if (/^[>❯›$#%]+$/.test(trimmed)) return true;
  if (FOOTER_CHROME_RE.test(trimmed)) return true;
  if (SHELL_PROMPT_RE.test(trimmed)) return true;
  return false;
}

function sliceAbovePromptBox(lines) {
  const minIdx = Math.max(0, lines.length - 26);
  let cutAt = lines.length;
  let cursor = lines.length;

  for (let i = lines.length - 1; i >= minIdx; i--) {
    const t = lines[i].trim();
    if (!DIVIDER_RE.test(t)) continue;
    const segment = lines.slice(i + 1, cursor).map((l) => l.trim()).filter(Boolean);
    const hasChromeMarker = segment.some(
      (s) => PROMPT_LINE_RE.test(s) || FOOTER_CHROME_RE.test(s) || /^[>❯›]$/.test(s),
    );
    const allShortOrEmpty = segment.length <= 4 && segment.every((s) => s.length <= 120);
    if (segment.length === 0 || hasChromeMarker || (cutAt < lines.length && allShortOrEmpty)) {
      cutAt = i;
      cursor = i;
    } else {
      break;
    }
  }
  return lines.slice(0, cutAt);
}

function smartJoinLines(parts) {
  let out = "";
  for (const raw of parts) {
    const part = raw.trim();
    if (!part) continue;
    if (!out) {
      out = part;
      continue;
    }
    const prevLast = out[out.length - 1];
    const nextFirst = part[0];
    const isCjk = (ch) => /[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]/.test(ch);
    out += isCjk(prevLast) || isCjk(nextFirst) ? part : ` ${part}`;
  }
  return out.replace(/\s+/g, " ").trim();
}

function truncateSummary(text, maxLen = 75) {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= maxLen) return clean;
  return `${clean.slice(0, maxLen - 1).trimEnd()}…`;
}

export function extractSummary(rawText, kind, fallbackTitle = "") {
  const rawLines = stripAnsi(rawText)
    .split("\n")
    .map((l) => l.replace(/\s+$/g, ""));

  while (rawLines.length > 0 && !rawLines[rawLines.length - 1].trim()) {
    rawLines.pop();
  }

  if (kind === "blocked") {
    const meaningful = rawLines
      .map((l) => l.trim().replace(/^[│┃]\s*|\s*[│┃]$/g, "").trim())
      .filter((l) => l && !isPureChromeLine(l));

    for (let i = meaningful.length - 1; i >= Math.max(0, meaningful.length - 12); i--) {
      const candidate = meaningful[i].replace(/^[>❯›]\s*/, "").trim();
      if (candidate && QUESTION_OR_APPROVAL_RE.test(candidate)) {
        return truncateSummary(candidate);
      }
    }
    if (meaningful.length > 0) {
      const tail = meaningful.slice(-2).map((l) => l.replace(/^[>❯›]\s*/, "").trim()).filter(Boolean);
      const joined = smartJoinLines(tail);
      if (joined) return truncateSummary(joined);
    }
  } else {
    const bodyLines = sliceAbovePromptBox(rawLines);
    const cleaned = bodyLines.map((l) => l.trim().replace(/^[│┃]\s*|\s*[│┃]$/g, "").trim());

    let end = cleaned.length - 1;
    while (end >= 0 && isPureChromeLine(cleaned[end])) {
      end--;
    }

    if (end >= 0) {
      const paragraph = [];
      for (let i = end; i >= Math.max(0, end - 5); i--) {
        const line = cleaned[i];
        if (!line || isPureChromeLine(line)) break;
        const mPrompt = PROMPT_LINE_RE.exec(line);
        if (mPrompt) {
          if (paragraph.length === 0 && mPrompt[1]) paragraph.unshift(mPrompt[1]);
          break;
        }
        paragraph.unshift(line);
        if (/^(#{1,4}\s+|[-*•●]\s+|\d+\.\s+)/.test(line)) break;
      }
      const joined = smartJoinLines(paragraph);
      if (joined) return truncateSummary(joined);
    }
  }

  const fb = cleanTitle(fallbackTitle);
  if (fb && !/^[~/]/.test(fb) && !fb.includes("@")) {
    return truncateSummary(fb);
  }
  return kind === "blocked" ? "正在等待你的确认或输入，点击切回查看" : "任务已完成，点击切回查看结果";
}

function iconPathFor(programKey) {
  const safeKey = String(programKey ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "");
  const base = `${appHome()}/data/workspace-helper/icons`;
  if (PRE_RENDERED_ICONS.has(safeKey)) {
    return `${base}/${safeKey}.png`;
  }
  return `${base}/agent.png`;
}

export default class WorkspaceHelper extends View {
  init(_props, cx) {
    this.prevStatus = new Map();
    this.wasWorking = new Set();
    this.lastNotifiedAt = new Map();
    if (checking()) return;

    if (!shared("subagents.panel_registered")) {
      const saved = shared("mods.panels");
      if (Array.isArray(saved) && !saved.includes("subagents")) {
        const next = [...saved];
        const mIdx = next.indexOf("mermaid");
        if (mIdx >= 0) next.splice(mIdx, 0, "subagents");
        else next.push("subagents");
        setShared("mods.panels", next);
      }
      setShared("subagents.panel_registered", true);
    }

    const current = agents();
    this.prevStatus = new Map(current.map((a) => [a.address, a.status]));
    this.wasWorking = new Set(current.filter((a) => a.status === "working").map((a) => a.address));

    this.asksEngine = new AsksEngine();
    this._lastAsksConfigJson = "";
    const refreshAsksConfig = (cx) => {
      if (!isAsksEnabled()) return;
      cx.spawn(async (cx) => {
        const cfg = await loadAsksConfig();
        const json = JSON.stringify(cfg);
        if (json === this._lastAsksConfigJson) return;
        this._lastAsksConfigJson = json;
        this.asksEngine.config = cfg;
        this.asksEngine._backend = undefined;
        this.asksEngine._codex = undefined;
        cx.notify();
      });
    };
    refreshAsksConfig(cx);
    cx.timer.every(30000, refreshAsksConfig);
    cx.timer.every(2000, (cx) => {
      if (isAsksEnabled()) this.asksEngine.tick(cx);
    });

    cx.spawn(async (cx) => {
      for (;;) {
        const cmd = await nextCommand();
        if (cmd === "toggle_files") {
          togglePanel("files");
        } else if (cmd === "toggle_changes") {
          togglePanel("changes");
        } else if (cmd === "toggle_subagents") {
          togglePanel("subagents");
        } else if (cmd === "toggle_mermaid") {
          togglePanel("mermaid");
        } else if (cmd === "toggle_asks") {
          togglePanel("asks");
        } else if (cmd === "toggle_mod_manager") {
          run("mod.open", { name: "mod-manager" });
        } else if (cmd === "seed_demo_asks") {
          seedDemoAsks();
        } else if (cmd === "clear_demo_asks") {
          clearDemoAsks();
        } else if (cmd === "test_done" || cmd === "test_blocked") {
          const kind = cmd === "test_blocked" ? "blocked" : "done";
          const list = agents();
          const target = list.find((a) => a.focused) ?? list[0] ?? {
            address: "",
            pane: "",
            space_name: "训练集成",
            tab_name: "示例标签页",
            program: { key: "agent", name: "Agent" },
            title: "",
          };
          const tabMap = new Map(spaces().flatMap((s) => s.tabs).map((tab) => [tab.id, tab]));
          const leads = leadPanes(panes());
          this.dispatchAlert(cx, target, kind, tabMap, leads, true);
        }
      }
    });
  }

  dispatchAlert(cx, agent, kind, tabMap, leads, bypassDebounce = false) {
    if (!bypassDebounce && shared("mods.notifications") === false) {
      return;
    }
    const addr = agent.address ?? "";
    const pane = agent.pane ?? "";
    const dedupeKey = `${addr || "test"}:${kind}`;
    const now = Date.now();
    if (!bypassDebounce && now - (this.lastNotifiedAt.get(dedupeKey) ?? 0) < 2000) {
      return;
    }
    this.lastNotifiedAt.set(dedupeKey, now);

    const agentName = agent.program?.name || agent.app || "Agent";
    const spaceName = agent.space_name || "Herdr";
    const tabLabel = resolveTabLabel(agent, tabMap, leads);
    const fallbackTitle = agent.title || "";
    const programKey = agent.program?.key || agent.app || "agent";
    const iconPath = iconPathFor(programKey);

    const title = kind === "blocked" ? `⚠️ ${agentName} 需要你的输入` : `✅ ${agentName} 已完成`;
    const subtitle = `${spaceName} / ${tabLabel}`;
    const group = addr ? `herdr-agent-${addr}` : `herdr-agent-test-${kind}`;

    cx.spawn(async () => {
      let rawText = "";
      if (addr) {
        try {
          const res = await hc(["read", addr, "--lines", "45"]);
          if (res?.code === 0 && res.stdout) rawText = res.stdout;
        } catch {
          // Ignore hc read failures; extractSummary falls back gracefully.
        }
      }
      const body = extractSummary(rawText, kind, fallbackTitle);
      const args = [
        "--title",
        title,
        "--subtitle",
        subtitle,
        "--body",
        body,
        "--group",
        group,
        "--terminal",
        addr,
        "--pane",
        pane,
        "--image",
        iconPath,
      ];
      try {
        const out = await exec(notifierBin(), args, { timeout: 15000 });
        if (out.code !== 0) {
          console.log("HerdrNotify failed:", out.code, out.stderr);
        }
      } catch (err) {
        console.log("HerdrNotify exec error:", String(err));
      }
    });
  }

  render(cx) {
    if (checking()) return div();
    if (isAsksEnabled() && this.asksEngine) {
      this.asksEngine.tick(cx);
    }

    const current = agents();
    const prev = this.prevStatus;
    const liveSet = new Set(current.map((a) => a.address));

    for (const addr of prev.keys()) {
      if (!liveSet.has(addr)) prev.delete(addr);
    }
    for (const addr of this.wasWorking) {
      if (!liveSet.has(addr)) this.wasWorking.delete(addr);
    }

    let tabMap = null;
    let leads = null;
    const ensureContext = () => {
      if (!tabMap) tabMap = new Map(spaces().flatMap((s) => s.tabs).map((tab) => [tab.id, tab]));
      if (!leads) leads = leadPanes(panes());
    };

    for (const agent of current) {
      const oldStatus = prev.get(agent.address);
      prev.set(agent.address, agent.status);

      if (agent.status === "working") {
        this.wasWorking.add(agent.address);
        continue;
      }

      if (agent.status === "blocked") {
        if (oldStatus !== "blocked") {
          ensureContext();
          this.dispatchAlert(cx, agent, "blocked", tabMap, leads);
        }
        continue;
      }

      if (agent.status === "done" || agent.status === "idle") {
        if (this.wasWorking.has(agent.address)) {
          this.wasWorking.delete(agent.address);
          ensureContext();
          this.dispatchAlert(cx, agent, "done", tabMap, leads);
        }
      }
    }

    return div();
  }
}
