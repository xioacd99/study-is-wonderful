import { View, div, svg, list } from "gpui-kit";
import { v_flex, h_flex, InputState, Input, Scrollbar, v_virtual_list } from "gpui-base";
import { props, closeOverlay, exec, readTextFile, theme, settings, checking, shared, setShared } from "herdr";
import { detectLang, tokenizeLine, syntaxPalette } from "./highlight.js";

const READ = ["--no-optional-locks", "-c", "core.fsmonitor=false", "-c", "diff.autoRefreshIndex=false"];
const countLines = (text) => (text ? text.split("\n").length - Number(text.endsWith("\n")) : 0);
const wideGlyph = /[\p{Ideographic}\p{Emoji_Presentation}\p{Extended_Pictographic}\u1100-\u115f\u2e80-\ua4cf\uac00-\ud7a3\ufe10-\ufe19\ufe30-\ufe6f\uff01-\uff60\uffe0-\uffe6]/gu;

function displayColumns(text) {
  let columns = text.length;
  for (const glyph of text.match(wideGlyph) ?? []) {
    if (glyph.length === 1) columns++;
  }
  return columns;
}

const rowHeight = (size) => Math.ceil(size * 1.8);
const charWidth = (size) => size * 0.64;
const untab = (text) => text.replace(/[^\t]*\t/g, (s) => s.slice(0, -1).padEnd((s.length - 1) - (s.length - 1) % 4 + 4));

function diffRows(lines) {
  let old = 0, next = 0;
  return lines.map((line) => {
    const match = /^@@ -(\d+)(?:,\d+)? \+(\d+)/.exec(line);
    if (match) { old = +match[1]; next = +match[2]; return { kind: "@", text: line }; }
    const kind = line[0];
    if (kind === "-") return { kind, number: old++, text: untab(line.slice(1)) || " " };
    if (kind === "+") return { kind, number: next++, text: untab(line.slice(1)) || " " };
    if (kind === " ") { old++; return { kind, number: next++, text: untab(line.slice(1)) || " " }; }
    return { kind: "", text: line };
  });
}

function buildFileTree(files) {
  const root = { name: "", path: "", dirs: new Map(), files: [], count: 0 };
  for (const f of files) {
    const parts = f.path.split("/");
    const name = parts.pop();
    let cur = root;
    let curPath = "";
    cur.count++;
    for (const part of parts) {
      curPath = curPath ? `${curPath}/${part}` : part;
      let child = cur.dirs.get(part);
      if (!child) {
        child = { name: part, path: curPath, dirs: new Map(), files: [], count: 0 };
        cur.dirs.set(part, child);
      }
      cur = child;
      cur.count++;
    }
    cur.files.push({ name, file: f });
  }
  const compact = (node) => {
    const compactedDirs = new Map();
    for (const [, d] of node.dirs) {
      let cur = d;
      let label = cur.name;
      while (cur.dirs.size === 1 && cur.files.length === 0) {
        const next = cur.dirs.values().next().value;
        label = `${label}/${next.name}`;
        cur = next;
      }
      const nextNode = compact(cur);
      nextNode.name = label;
      compactedDirs.set(nextNode.path, nextNode);
    }
    return { ...node, dirs: compactedDirs };
  };
  return compact(root);
}

function flattenTree(node, collapsed, depth = 0, out = []) {
  const dirs = [...node.dirs.values()].sort((a, b) => a.name.localeCompare(b.name));
  for (const dir of dirs) {
    const isOpen = !collapsed.has(dir.path);
    out.push({ kind: "dir", depth, path: dir.path, name: dir.name, count: dir.count, open: isOpen });
    if (isOpen) flattenTree(dir, collapsed, depth + 1, out);
  }
  const files = [...node.files].sort((a, b) => a.name.localeCompare(b.name));
  for (const item of files) {
    out.push({ kind: "file", depth, name: item.name, file: item.file });
  }
  return out;
}

function collectDirPaths(node, out = []) {
  for (const dir of node.dirs.values()) {
    out.push(dir.path);
    collectDirPaths(dir, out);
  }
  return out;
}

export default class ChangesDiffFullscreen extends View {
  init(_props, cx) {
    const p = props() ?? {};
    this.root = p.root ?? null;
    this.on = p.on ?? null;
    this.hasHead = Boolean(p.hasHead);
    this.files = Array.isArray(p.files) ? p.files : [];
    this.open = p.open && this.files.some((f) => f.path === p.open) ? p.open : (this.files[0]?.path ?? null);
    this.rows = [];
    this.lang = null;
    this.longest = 0;
    this.gutterChars = 4;
    this.loading = false;
    this.query = "";
    this.searchFocused = false;
    this.collapsedDirs = new Set();
    this.loadSeq = 0;
    this.handle = cx.focus_handle();
    this.handle.focus();

    this.searchInput = InputState.new({ placeholder: "Search changed files…" });
    this.searchInput.on("change", (_e, cx) => {
      this.query = this.searchInput.value();
      cx.notify();
    });
    this.searchInput.on("submit", (_e, cx) => {
      const first = this.filteredFiles()[0];
      if (first) this.selectFile(first.path, cx);
    });
    this.searchInput.on("focus", (_e, cx) => { this.searchFocused = true; cx.notify(); });
    this.searchInput.on("blur", (_e, cx) => { this.searchFocused = false; cx.notify(); });

    if (!checking() && this.root && this.open) {
      this.loadDiff(this.open, cx);
    }
  }

  filteredFiles() {
    const tokens = this.query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    if (!tokens.length) return this.files;
    return this.files.filter((f) => {
      const lower = f.path.toLowerCase();
      return tokens.every((tok) => lower.includes(tok));
    });
  }

  setViewMode(mode, cx) {
    setShared("changes.viewMode", mode);
    cx.notify();
  }

  toggleDir(path, cx) {
    if (this.collapsedDirs.has(path)) this.collapsedDirs.delete(path);
    else this.collapsedDirs.add(path);
    cx.notify();
  }

  expandAllDirs(cx) {
    this.collapsedDirs.clear();
    cx.notify();
  }

  collapseAllDirs(dirPaths, cx) {
    this.collapsedDirs = new Set(dirPaths);
    cx.notify();
  }

  toggleWrap(cx) {
    setShared("changes.wordWrap", !Boolean(shared("changes.wordWrap")));
    cx.notify();
  }

  setLines(lines) {
    this.lang = detectLang(this.open);
    this.rows = diffRows(lines);
    this.longest = Math.max(0, ...this.rows.map((row) => displayColumns(row.text)));
    this.gutterChars = Math.max(4, String(Math.max(0, ...this.rows.map((row) => row.number ?? 0))).length);
  }

  selectFile(path, cx) {
    this.open = path;
    this.setLines([]);
    this.loadDiff(path, cx);
  }

  stepFile(delta, cx) {
    const list = this.filteredFiles();
    if (!list.length) return;
    const idx = list.findIndex((f) => f.path === this.open);
    const nextIdx = idx < 0 ? 0 : (idx + delta + list.length) % list.length;
    this.selectFile(list[nextIdx].path, cx);
  }

  loadDiff(path, cx) {
    const file = this.files.find((f) => f.path === path);
    if (!file || !this.root) return;
    const seq = ++this.loadSeq;
    const root = this.root, on = this.on;
    this.loading = true;
    cx.notify();

    cx.spawn(async (cx) => {
      let lines;
      try {
        if (file.fresh || (!this.hasHead && file.status === "A")) {
          const text = await readTextFile(`${root}/${path}`, { on }).catch(() => null);
          if (text === null) lines = ["Cannot preview this file (binary, too large, or unreadable)"];
          else if (text.includes("\0")) lines = ["Binary file · no text diff"];
          else {
            const add = countLines(text);
            lines = [`@@ -0,0 +1,${add} @@`, ...text.slice(0, 400000).replace(/\n$/, "").split("\n").slice(0, 1500).map((l) => `+${l}`)];
          }
        } else {
          const r = await exec("git", [...READ, "diff", ...(this.hasHead ? ["HEAD"] : []), "--no-ext-diff", "--no-textconv", "--no-color", "--", path], { cwd: root, on });
          if (r.code !== 0) throw new Error(r.stderr);
          const all = r.stdout.replace(/\n$/, "").split("\n");
          const first = all.findIndex((l) => l.startsWith("@@"));
          lines = first < 0 ? [file.binary ? "Binary file changed" : "No text diff available"] : all.slice(first);
        }
      } catch (e) {
        lines = [`Cannot preview this diff: ${e}`];
      }
      if (seq !== this.loadSeq) return;
      this.loading = false;
      this.setLines(lines.slice(0, 1500).map((line) => (line.length > 4000 ? line.slice(0, 4000) + "… (line truncated)" : line)));
      cx.notify();
    });
  }

  gutter(size) {
    return Math.ceil(this.gutterChars * charWidth(size)) + 2;
  }

  diffRow(row, t, size, wrap) {
    const { kind, number, text } = row;
    const height = rowHeight(size);
    if (kind === "@") {
      if (wrap) return div().w_full().px(14).py(3).bg(t.raised).text_color(t.dim).whitespace_normal().child(text);
      return div().w_full().px(14).h(height).flex_none().truncate().bg(t.raised).text_color(t.dim).child(text);
    }
    const tokens = (row.tokens ??= tokenizeLine(text, this.lang));
    const pal = syntaxPalette(t);
    let content;
    if (tokens.length <= 1) {
      const tok = tokens[0];
      const base = div().flex_1().min_w(0);
      const styled = wrap ? base.whitespace_normal() : base.truncate();
      content = (tok?.c ? styled.text_color(pal[tok.c]) : styled).child(tok ? tok.t : text);
    } else if (wrap) {
      content = h_flex().flex_1().min_w(0).flex_wrap().items_start().children(
        tokens.map((tok) => {
          const el = div().max_w_full().whitespace_normal().child(tok.t);
          return tok.c ? el.text_color(pal[tok.c]) : el;
        }),
      );
    } else {
      content = h_flex().flex_1().min_w(0).overflow_hidden().items_center().children(
        tokens.map((tok) => {
          const el = div().flex_none().whitespace_nowrap().child(tok.t);
          return tok.c ? el.text_color(pal[tok.c]) : el;
        }),
      );
    }
    const baseRow = wrap
      ? h_flex().w_full().min_h(height).items_start().py(1).pr(14).gap(12)
      : h_flex().w_full().h(height).flex_none().gap(12);
    return baseRow
      .when(kind === "+", (e) => e.bg(t.ansi2 + "18"))
      .when(kind === "-", (e) => e.bg(t.ansi1 + "18"))
      .child(div().w(this.gutter(size)).flex_none().text_right().text_color(t.dim).child(number === undefined ? "" : String(number)))
      .child(content);
  }

  renderFileRow(f, t) {
    const parts = f.path.split("/"), name = parts.pop();
    return h_flex().id(`cfs-file-${f.path}`).h(28).flex_none().px(8).gap(8).items_center().rounded(7).cursor_pointer()
      .when(this.open === f.path, (e) => e.bg(t.selected))
      .hover((s) => s.bg(t.hover))
      .on_click((_e, cx) => this.selectFile(f.path, cx))
      .child(div().w(14).text_size(11).text_color(f.status === "A" ? t.ansi2 : f.status === "D" ? t.ansi1 : f.status === "U" ? t.ansi1 : t.blocked).child(f.status))
      .child(h_flex().flex_1().min_w(0).child(div().text_color(t.dim).truncate().child(parts.length ? parts.join("/") + "/" : "")).child(div().min_w(0).truncate().child(name)))
      .when(f.add > 0, (e) => e.child(div().text_size(11).text_color(t.ansi2).child(`+${f.add}`)))
      .when(f.del > 0, (e) => e.child(div().text_size(11).text_color(t.ansi1).child(`−${f.del}`)));
  }

  renderTreeRow(row, t) {
    if (row.kind === "dir") {
      return h_flex().id(`cfs-dir-${row.path}`).h(26).flex_none().pl(8 + row.depth * 14).pr(8).gap(5).items_center().rounded(7).cursor_pointer()
        .hover((s) => s.bg(t.hover))
        .on_click((_e, cx) => this.toggleDir(row.path, cx))
        .child(svg(`mods/files-custom/chevron-${row.open ? "down" : "right"}.svg`).size(11).flex_none().text_color(t.dim))
        .child(svg("mods/files-custom/folder.svg").size(13).flex_none().text_color(t.muted))
        .child(div().flex_1().min_w(0).truncate().text_size(12).text_color(t.muted).child(row.name))
        .child(div().text_size(10).text_color(t.dim).child(String(row.count)));
    }
    const f = row.file;
    return h_flex().id(`cfs-tfile-${f.path}`).h(26).flex_none().pl(8 + row.depth * 14 + 16).pr(8).gap(6).items_center().rounded(7).cursor_pointer()
      .when(this.open === f.path, (e) => e.bg(t.selected))
      .hover((s) => s.bg(t.hover))
      .on_click((_e, cx) => this.selectFile(f.path, cx))
      .child(div().w(12).flex_none().text_size(10.5).text_color(f.status === "A" ? t.ansi2 : f.status === "D" ? t.ansi1 : f.status === "U" ? t.ansi1 : t.blocked).child(f.status))
      .child(div().flex_1().min_w(0).truncate().text_size(12.5).child(row.name))
      .when(f.add > 0, (e) => e.child(div().text_size(10.5).text_color(t.ansi2).child(`+${f.add}`)))
      .when(f.del > 0, (e) => e.child(div().text_size(10.5).text_color(t.ansi1).child(`−${f.del}`)));
  }

  render() {
    const t = theme();
    const p = props() ?? {};
    const size = settings().font_size;
    const filtered = this.filteredFiles();
    const openFile = this.files.find((f) => f.path === this.open);
    const wrap = Boolean(shared("changes.wordWrap"));
    const viewMode = shared("changes.viewMode") === "tree" ? "tree" : "flat";
    const tree = viewMode === "tree" ? buildFileTree(filtered) : null;
    const treeRows = tree ? flattenTree(tree, this.collapsedDirs) : [];
    const dirPaths = tree ? collectDirPaths(tree) : [];

    const navBtn = (id, label, onClick) =>
      h_flex()
        .id(id)
        .h(24)
        .px(8)
        .items_center()
        .rounded(6)
        .border_1()
        .border_color(t.border)
        .bg(t.raised)
        .text_size(11.5)
        .text_color(t.foreground)
        .cursor_pointer()
        .hover((s) => s.bg(t.hover))
        .on_click(onClick)
        .child(label);

    const modeBtn = (id, label, mode) => {
      const active = viewMode === mode;
      return h_flex()
        .id(id)
        .flex_1()
        .h(22)
        .items_center()
        .justify_center()
        .rounded(5)
        .when(active, (el) => el.bg(t.selected))
        .text_size(11)
        .text_color(active ? t.foreground : t.muted)
        .cursor_pointer()
        .hover((s) => s.text_color(t.foreground))
        .on_click((_e, cx) => this.setViewMode(mode, cx))
        .child(label);
    };

    return v_flex()
      .id("changes-diff-fullscreen")
      .track_focus(this.handle)
      .size_full()
      .min_h(0)
      .bg(t.background)
      .text_color(t.foreground)
      .text_size(13)
      .on_key_down((e, cx) => {
        const isAltZ = e.keystroke === "alt-z"
          || (e.modifiers?.alt && !e.modifiers?.platform && !e.modifiers?.control && (e.key === "z" || e.key === "Z"));
        if (isAltZ) {
          this.toggleWrap(cx);
          cx.stop_propagation();
          return;
        }
        if (e.key === "escape") {
          if (this.searchFocused) {
            if (this.query) { this.query = ""; this.searchInput.set_value(""); }
            else { this.searchFocused = false; this.handle.focus(); }
            cx.stop_propagation();
            cx.notify();
            return;
          }
          closeOverlay(p.overlay);
          cx.stop_propagation();
        }
      })
      .child(
        h_flex().h(42).flex_none().px(14).gap(8).items_center().bg(t.chrome).border_b(1).border_color(t.border)
          .child(div().font_semibold().child("Diff 全屏视图"))
          .when(Boolean(openFile), (el) => el
            .child(div().px(5).py(1).rounded(4).border_1().border_color(t.border).text_size(10.5)
              .text_color(openFile.status === "A" ? t.ansi2 : openFile.status === "D" ? t.ansi1 : openFile.status === "U" ? t.ansi1 : t.blocked)
              .child(openFile.status))
            .child(div().flex_1().min_w(0).truncate().text_size(12.5).text_color(t.muted).child(openFile.path))
            .when(openFile.add > 0, (e2) => e2.child(div().text_size(11.5).text_color(t.ansi2).child(`+${openFile.add}`)))
            .when(openFile.del > 0, (e2) => e2.child(div().text_size(11.5).text_color(t.ansi1).child(`−${openFile.del}`))))
          .when(!openFile, (el) => el.child(div().flex_1()))
          .child(
            h_flex().id("cfs-wrap").h(24).px(8).items_center().rounded(6).border_1()
              .border_color(wrap ? t.accent : t.border)
              .bg(wrap ? t.selected : t.raised)
              .text_size(11.5)
              .text_color(wrap ? t.foreground : t.muted)
              .cursor_pointer()
              .tooltip("自动换行 (Alt+Z)")
              .hover((s) => s.bg(t.hover).text_color(t.foreground))
              .on_click((_e, cx) => this.toggleWrap(cx))
              .child("自动换行"),
          )
          .when(filtered.length > 1, (el) => el
            .child(navBtn("cfs-prev", "上一个", (_e, cx) => this.stepFile(-1, cx)))
            .child(navBtn("cfs-next", "下一个", (_e, cx) => this.stepFile(1, cx))))
          .child(
            h_flex().id("cfs-close").h(24).px(8).gap(4).items_center().rounded(6).border_1().border_color(t.border).bg(t.raised)
              .text_size(11.5).text_color(t.muted).cursor_pointer().hover((s) => s.bg(t.hover).text_color(t.foreground))
              .on_click(() => closeOverlay(p.overlay))
              .child(svg("mods/workspace-chrome/x.svg").size(12))
              .child("关闭"),
          ),
      )
      .child(
        h_flex().w_full().flex_1().min_h(0)
          .child(
            v_flex().w(280).flex_none().h_full().min_h(0).bg(t.chrome).border_r(1).border_color(t.border)
              .child(
                v_flex().px(8).py(8).gap(6).border_b(1).border_color(t.border)
                  .child(
                    h_flex().w_full().h(28).px(8).gap(6).items_center().rounded(7).bg(t.input).border_1()
                      .border_color(this.searchFocused ? t.accent : t.border).cursor_text()
                      .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
                      .child(svg("mods/workspace-chrome/search.svg").size(13).flex_none().text_color(t.dim))
                      .child(Input.new(this.searchInput).flex_1().min_w(0).h_full().text_size(12).text_color(t.foreground))
                      .when(Boolean(this.query), (e2) => e2
                        .child(div().text_size(10).text_color(t.dim).child(`${filtered.length}/${this.files.length}`))
                        .child(
                          div().id("cfs-search-clear").w(18).h(18).flex().items_center().justify_center().rounded(4).cursor_pointer()
                            .hover((s) => s.bg(t.hover))
                            .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
                            .on_click((_e, cx) => {
                              cx.stop_propagation();
                              this.query = "";
                              this.searchInput.set_value("");
                              cx.notify();
                            })
                            .child(svg("mods/workspace-chrome/x.svg").size(11).text_color(t.muted)),
                        )),
                  )
                  .child(
                    h_flex().w_full().p(2).gap(2).rounded(7).bg(t.background).border_1().border_color(t.border)
                      .child(modeBtn("cfs-mode-flat", "平铺列表", "flat"))
                      .child(modeBtn("cfs-mode-tree", "树形结构", "tree")),
                  )
                  .when(viewMode === "tree" && dirPaths.length > 0, (el) => el
                    .child(
                      h_flex().w_full().gap(6).items_center()
                        .child(div().flex_1().text_size(10.5).text_color(t.dim).child(`${dirPaths.length} 个文件夹`))
                        .child(
                          h_flex().id("cfs-tree-expand-all").h(20).px(7).items_center().rounded(5).border_1().border_color(t.border)
                            .bg(t.background).text_size(10.5).text_color(t.muted).cursor_pointer()
                            .hover((s) => s.bg(t.hover).text_color(t.foreground))
                            .on_click((_e, cx) => this.expandAllDirs(cx))
                            .child("全部展开"),
                        )
                        .child(
                          h_flex().id("cfs-tree-collapse-all").h(20).px(7).items_center().rounded(5).border_1().border_color(t.border)
                            .bg(t.background).text_size(10.5).text_color(t.muted).cursor_pointer()
                            .hover((s) => s.bg(t.hover).text_color(t.foreground))
                            .on_click((_e, cx) => this.collapseAllDirs(dirPaths, cx))
                            .child("全部折叠"),
                        ),
                    )),
              )
              .child(
                div().flex_1().min_h(0).relative()
                  .child(
                    v_flex().id("cfs-list").absolute().inset_0().overflow_y_scroll().p(6)
                      .children(
                        viewMode === "tree"
                          ? treeRows.map((row) => this.renderTreeRow(row, t))
                          : filtered.map((f) => this.renderFileRow(f, t)),
                      )
                      .when(!filtered.length, (e) => e.child(div().p(10).text_size(12).text_color(t.dim).child(this.files.length ? "No matching files" : "No uncommitted changes"))),
                  )
                  .child(Scrollbar.vertical("cfs-list").absolute().inset_0()),
              ),
          )
          .child(
            div().flex_1().min_w(0).h_full().min_h(0).relative().font_family(settings().font_family ?? "JetBrains Mono").text_size(size)
              .on_mouse_down("left", () => this.handle.focus())
              .when(!wrap, (el) => el
                .child(
                  div().id("cfs-diff-x").size_full().overflow_x_scrollbar()
                    .child(
                      div().w_full().min_w(Math.max(400, this.longest * charWidth(size) + this.gutter(size) + 24)).h_full()
                        .child(
                          v_virtual_list("cfs-diff", this.rows.length, rowHeight(size), (i) => String(i), (range) =>
                            this.rows.slice(range.start, range.end).map((row) => this.diffRow(row, t, size, false)),
                          ).size_full(),
                        ),
                    ),
                )
                .child(Scrollbar.vertical("cfs-diff").viewport_from_layout().absolute().inset_0()))
              .when(wrap, (el) => el
                .child(
                  list("cfs-diff-wrap", this.rows.length, (i) => `${this.open ?? ""}:${i}`, (i) =>
                    this.diffRow(this.rows[i], t, size, true),
                  ).size_full(),
                )
                .child(Scrollbar.vertical("cfs-diff-wrap").absolute().inset_0()))
              .when(this.loading, (e) => e.child(div().absolute().top(10).left(14).text_size(12).text_color(t.dim).child("Loading diff…")))
              .when(!this.loading && !this.open, (e) => e.child(div().absolute().top(10).left(14).text_size(12).text_color(t.dim).child("Select a file to view its diff")))
              .when(!this.loading && Boolean(this.open) && this.rows.length === 0, (e) => e.child(div().absolute().top(10).left(14).text_size(12).text_color(t.dim).child("No diff content"))),
          ),
      );
  }
}
