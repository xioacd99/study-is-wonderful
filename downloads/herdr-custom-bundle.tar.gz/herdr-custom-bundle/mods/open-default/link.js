import { exec, notify, shared } from "herdr";
import { resolveTargetPath } from "./path.js";

export async function handleLink(click) {
  if (shared("mods.open_default") === false) {
    return "pass";
  }
  const targetPath = resolveTargetPath(click);
  if (!targetPath) {
    return "pass";
  }
  try {
    const res = await exec("open", [targetPath]);
    if (res.code !== 0) {
      notify({
        title: "Could not open file",
        body: res.stderr?.trim() || targetPath,
        level: "error",
      });
    }
  } catch (err) {
    notify({
      title: "Could not open file",
      body: String(err),
      level: "error",
    });
  }
  return "handled";
}
