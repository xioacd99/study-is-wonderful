const EDITOR_FILE_URL_RE =
  /^(vscode|vscode-insiders|cursor|windsurf):\/\/file(\/.*)$/i;
const TRAILING_COORD_RE = /:\d+(?::\d+)?$/;
const TARGET_EXT_RE = /\.(html?|md|markdown)$/i;

export function resolveTargetPath(click) {
  if (!click || click.source?.machine) return null;
  const link = click.link;
  if (!link) return null;

  if (link.kind === "file") {
    return link.path || null;
  }

  if (link.kind === "url" && typeof link.url === "string") {
    const m = EDITOR_FILE_URL_RE.exec(link.url);
    if (!m) return null;
    let rawPath = m[2].replace(TRAILING_COORD_RE, "");
    try {
      rawPath = decodeURIComponent(rawPath);
    } catch {
      return null;
    }
    if (!rawPath.startsWith("/") || !TARGET_EXT_RE.test(rawPath)) {
      return null;
    }
    return rawPath;
  }

  return null;
}
