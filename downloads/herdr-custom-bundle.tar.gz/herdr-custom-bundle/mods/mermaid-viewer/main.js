import { View, div, image, svg } from "gpui-kit";
import { v_flex, h_flex, Editor, EditorState } from "gpui-base";
import {
  appHome,
  checking,
  closeOverlay,
  exec,
  focused,
  hc,
  layout,
  notify,
  openOverlay,
  panes,
  props,
  settings,
  theme,
  window,
} from "herdr";
import { extractMermaidBlocks } from "./extract.js";

const BUN_BIN = "/opt/homebrew/bin/bun";

function toBase64(str) {
  const bytes = [];
  for (let i = 0; i < str.length; i++) {
    let cp = str.codePointAt(i);
    if (cp > 0xffff) i++;
    if (cp < 0x80) {
      bytes.push(cp);
    } else if (cp < 0x800) {
      bytes.push(0xc0 | (cp >> 6), 0x80 | (cp & 0x3f));
    } else if (cp < 0x10000) {
      bytes.push(0xe0 | (cp >> 12), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
    } else {
      bytes.push(
        0xf0 | (cp >> 18),
        0x80 | ((cp >> 12) & 0x3f),
        0x80 | ((cp >> 6) & 0x3f),
        0x80 | (cp & 0x3f),
      );
    }
  }
  const table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i];
    const b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
    const b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
    const n = (b0 << 16) | (b1 << 8) | b2;
    out += table[(n >> 18) & 63];
    out += table[(n >> 12) & 63];
    out += i + 1 < bytes.length ? table[(n >> 6) & 63] : "=";
    out += i + 2 < bytes.length ? table[n & 63] : "=";
  }
  return out;
}

function isDarkColor(hex) {
  if (typeof hex !== "string" || !hex.startsWith("#")) return true;
  const clean = hex.slice(1);
  if (clean.length < 6) return true;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return true;
  const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luma < 140;
}

function currentThemeInfo() {
  const t = theme();
  const s = settings();
  const dark = typeof s?.dark === "boolean" ? s.dark : isDarkColor(t.background);
  return {
    t,
    mode: dark ? "dark" : "light",
    bg: t.background || (dark ? "#18181b" : "#ffffff"),
  };
}

function targetTerminal() {
  const f = focused();
  if (f?.terminal) return f.terminal;
  const p = panes().find((x) => x.focused && x.terminal);
  return p?.terminal ?? null;
}

function findNode(node, id) {
  if (node?.id === id) return node;
  for (const child of node?.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

function isMermaidPanelVisible() {
  const root = layout();
  const panel = findNode(root, "panel");
  const body = findNode(root, "panel-body");
  return Boolean(panel && !panel.hidden && body?.active === "mermaid");
}

function pillButton(t, id, label, active, onClick) {
  return div()
    .id(id)
    .px(8)
    .h(24)
    .flex()
    .items_center()
    .rounded(6)
    .cursor_pointer()
    .text_size(11.5)
    .bg(active ? t.selected : t.surface)
    .border_1()
    .border_color(active ? t.accent : t.border)
    .text_color(active ? t.foreground : t.muted)
    .hover((s) => s.bg(t.hover).text_color(t.foreground))
    .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
    .on_click(onClick)
    .child(label);
}

export default class MermaidViewer extends View {
  init(initialProps, cx) {
    const p = initialProps ?? props() ?? {};
    this.isWindow = Boolean(p.overlay || p.mode === "window");
    this.windowProps = p;
    this.zoom = 1;
    this.panelWidth = 340;
    this.blocks = [];
    this.selectedHash = null;
    this.showCode = false;
    this.codeState = null;
    this.codeStateHash = null;
    this.renders = new Map();
    this.errors = new Map();
    this.renderingKeys = new Set();
    this.scanning = false;
    this.lastTerminal = null;
    this.lastSnapshot = "";
    this.sourceLabel = "";
    this.clipboardBlocks = [];
    this.wasVisible = false;

    if (checking()) return;

    if (this.isWindow) {
      if (p.code) this.syncCodeState(p.code, p.hash ?? "window");
      return;
    }

    this.wasVisible = isMermaidPanelVisible();
    if (this.wasVisible) {
      this.scanTerminal(cx, true);
    }
    cx.timer.every(5000, (cx) => {
      if (!isMermaidPanelVisible()) return;
      const w = window();
      if (w && (w.visible === false || w.active === false)) return;
      this.scanTerminal(cx, false);
    });
  }

  close() {
    this.codeState?.release();
    this.codeState = null;
  }

  syncCodeState(code, hash) {
    if (!code) {
      this.codeState?.release();
      this.codeState = null;
      this.codeStateHash = null;
      return;
    }
    if (this.codeState && this.codeStateHash === hash) return;
    this.codeState?.release();
    const t = theme();
    this.codeState = EditorState.new({
      language: "markdown",
      readonly: true,
      value: code,
      syntax: {
        keyword: t.ansi5,
        string: t.ansi2,
        comment: t.dim,
        function: t.ansi4,
        type: t.ansi3,
        number: t.ansi1,
        constant: t.ansi6,
      },
    });
    this.codeStateHash = hash;
  }

  renderKey(block, mode, bg) {
    return `${block.hash}:${mode}:${bg}`;
  }

  ensureRendered(block, cx) {
    if (!block) return;
    const { mode, bg } = currentThemeInfo();
    const key = this.renderKey(block, mode, bg);
    if (this.renders.has(key) || this.errors.has(key) || this.renderingKeys.has(key)) return;

    this.renderingKeys.add(key);
    const dataDir = `${appHome()}/data/mermaid-viewer`;
    const renderScript = `${dataDir}/render.mjs`;
    const b64 = toBase64(block.code);

    cx.spawn(async (cx) => {
      try {
        const res = await exec(
          BUN_BIN,
          [renderScript, "--theme", mode, "--bg", bg, "--out-dir", dataDir, "--code-b64", b64],
          { timeout: 30000 },
        );
        if (res.code === 0) {
          const parsed = JSON.parse(res.stdout.trim());
          this.renders.set(key, parsed);
          this.errors.delete(key);
        } else {
          this.errors.set(key, (res.stderr || res.stdout || "Failed to render Mermaid diagram").trim());
        }
      } catch (err) {
        this.errors.set(key, String(err));
      } finally {
        this.renderingKeys.delete(key);
        cx.notify();
      }
    });
  }

  scanTerminal(cx, force) {
    if (!force && !isMermaidPanelVisible()) return;
    const term = targetTerminal();
    if (!term) {
      if (this.lastTerminal !== null) {
        this.lastTerminal = null;
        this.blocks = [...this.clipboardBlocks];
        this.selectedHash = this.blocks[0]?.hash ?? null;
        cx.notify();
      }
      return;
    }
    if (this.scanning && !force) return;
    const terminalChanged = term !== this.lastTerminal;
    this.lastTerminal = term;
    this.scanning = true;

    cx.spawn(async (cx) => {
      let changed = false;
      try {
        const res = await hc(["read", term, "--lines", "400"]);
        if (res.code !== 0) return;
        const raw = res.stdout ?? "";
        if (!force && !terminalChanged && raw === this.lastSnapshot) return;
        this.lastSnapshot = raw;
        const termBlocks = extractMermaidBlocks(raw);
        const merged = [...termBlocks];
        for (const cb of this.clipboardBlocks) {
          if (!merged.some((b) => b.code === cb.code)) merged.push(cb);
        }
        const prevKey = this.blocks.map((b) => b.hash).join(",");
        const nextKey = merged.map((b) => b.hash).join(",");
        const prevSelected = this.selectedHash;
        if (prevKey !== nextKey || this.sourceLabel !== term) {
          this.blocks = merged;
          this.sourceLabel = term;
          changed = true;
        }
        if (!merged.some((b) => b.hash === this.selectedHash)) {
          this.selectedHash = merged[0]?.hash ?? null;
          if (this.selectedHash !== prevSelected) changed = true;
        }
        const active = this.selectedBlock();
        if (active) this.ensureRendered(active, cx);
      } catch {
        // Ignore transient terminal read errors.
      } finally {
        this.scanning = false;
        if (changed || force) cx.notify();
      }
    });
  }

  loadClipboard(cx) {
    cx.spawn(async (cx) => {
      try {
        const res = await exec("pbpaste", []);
        if (res.code !== 0 || !res.stdout?.trim()) {
          notify({ title: "Clipboard is empty", level: "info", timeout: 1800 });
          return;
        }
        let found = extractMermaidBlocks(res.stdout);
        if (found.length === 0) {
          const raw = res.stdout.trim();
          found = [{ code: raw, type: raw.split(/\s+/)[0] || "diagram", hash: `clip-${Date.now()}`, fenced: false }];
        }
        this.clipboardBlocks = found.map((b) => ({ ...b, fromClipboard: true }));
        const merged = [...this.clipboardBlocks, ...this.blocks.filter((b) => !b.fromClipboard)];
        this.blocks = merged;
        this.selectedHash = merged[0]?.hash ?? null;
        this.showCode = false;
        const active = this.selectedBlock();
        if (active) this.ensureRendered(active, cx);
      } catch (err) {
        notify({ title: "Could not read clipboard", body: String(err), level: "error" });
      } finally {
        cx.notify();
      }
    });
  }

  copyCode(code, cx) {
    const b64 = toBase64(code);
    cx.spawn(async () => {
      try {
        const r = await exec(BUN_BIN, [
          "-e",
          "const c = Buffer.from(process.argv[1], 'base64'); const p = Bun.spawnSync(['pbcopy'], { stdin: c }); process.exit(p.exitCode);",
          b64,
        ]);
        if (r.code === 0) {
          notify({ title: "Copied Mermaid code", level: "success", timeout: 1500 });
        } else {
          notify({ title: "Copy failed", body: r.stderr || "pbcopy failed", level: "error" });
        }
      } catch (err) {
        notify({ title: "Copy failed", body: String(err), level: "error" });
      }
    });
  }

  openBrowser(htmlPath, cx) {
    if (!htmlPath) return;
    cx.spawn(async () => {
      try {
        const r = await exec("open", [htmlPath]);
        if (r.code !== 0) {
          notify({ title: "Could not open browser", body: r.stderr || htmlPath, level: "error" });
        }
      } catch (err) {
        notify({ title: "Could not open browser", body: String(err), level: "error" });
      }
    });
  }

  selectedBlock() {
    return this.blocks.find((b) => b.hash === this.selectedHash) ?? this.blocks[0] ?? null;
  }

  renderWindow(cx) {
    const { t } = currentThemeInfo();
    const p = this.windowProps;
    const width = Math.max(100, Number(p.width || 600));
    const height = Math.max(80, Number(p.height || 400));
    const drawW = Math.round(width * this.zoom);
    const drawH = Math.round(height * this.zoom);
    const font = settings();

    return v_flex()
      .id("mermaid-window")
      .size_full()
      .min_h(0)
      .rounded(10)
      .overflow_hidden()
      .bg(t.background)
      .border_1()
      .border_color(t.border)
      .text_color(t.foreground)
      .text_size(13)
      .child(
        h_flex()
          .h(42)
          .flex_none()
          .px(14)
          .gap(8)
          .items_center()
          .bg(t.chrome)
          .border_b(1)
          .border_color(t.border)
          .child(svg("mods/mermaid-viewer/icon.svg").size(14).flex_none().text_color(t.accent))
          .child(div().font_semibold().child(p.title || "Mermaid Diagram"))
          .child(div().flex_1())
          .when(!this.showCode, (el) =>
            el
              .child(pillButton(t, "win-zoom-out", "−", false, (_e, cx) => { this.zoom = Math.max(0.4, +(this.zoom - 0.15).toFixed(2)); cx.notify(); }))
              .child(pillButton(t, "win-zoom-reset", `${Math.round(this.zoom * 100)}%`, false, (_e, cx) => { this.zoom = 1; cx.notify(); }))
              .child(pillButton(t, "win-zoom-in", "+", false, (_e, cx) => { this.zoom = Math.min(2.5, +(this.zoom + 0.15).toFixed(2)); cx.notify(); })),
          )
          .when(Boolean(p.code), (el) =>
            el.child(
              pillButton(t, "win-toggle-code", this.showCode ? "Diagram" : "Code", this.showCode, (_e, cx) => {
                this.showCode = !this.showCode;
                if (this.showCode) this.syncCodeState(p.code, p.hash ?? "window");
                cx.notify();
              }),
            ),
          )
          .when(Boolean(p.htmlPath), (el) =>
            el.child(pillButton(t, "win-browser", "Browser", false, (_e, cx) => this.openBrowser(p.htmlPath, cx))),
          )
          .when(Boolean(p.code), (el) =>
            el.child(pillButton(t, "win-copy", "Copy", false, (_e, cx) => this.copyCode(p.code, cx))),
          )
          .child(
            pillButton(t, "win-close", "Close", false, () => {
              if (p.overlay) closeOverlay(p.overlay);
            }),
          ),
      )
      .when(this.showCode && Boolean(this.codeState), (el) =>
        el.child(Editor.new(this.codeState).font_family(font.font_family).text_size(font.font_size).flex_1().min_h(0)),
      )
      .when(!this.showCode, (el) =>
        el.child(
          v_flex()
            .id("win-canvas")
            .flex_1()
            .min_h(0)
            .overflow_scrollbar()
            .p(20)
            .items_center()
            .child(
              div()
                .rounded(8)
                .border_1()
                .border_color(t.border)
                .overflow_hidden()
                .child(image(p.relPath).w(drawW).h(drawH).flex_none()),
            ),
        ),
      );
  }

  render(cx) {
    if (this.isWindow) return this.renderWindow(cx);

    const visible = isMermaidPanelVisible();
    if (!visible) {
      this.wasVisible = false;
      return div();
    }
    const curTerm = targetTerminal();
    if (!checking() && !this.scanning && (!this.wasVisible || curTerm !== this.lastTerminal)) {
      this.wasVisible = true;
      this.scanTerminal(cx, false);
    } else {
      this.wasVisible = true;
    }

    const { t, mode, bg } = currentThemeInfo();
    const block = this.selectedBlock();
    const key = block ? this.renderKey(block, mode, bg) : null;
    const rendered = key ? this.renders.get(key) : null;
    const err = key ? this.errors.get(key) : null;
    const isRendering = key ? this.renderingKeys.has(key) : false;

    if (block && !rendered && !err && !isRendering && !checking()) {
      this.ensureRendered(block, cx);
    }

    if (this.showCode && block) {
      this.syncCodeState(block.code, block.hash);
    }

    const availW = Math.max(180, (this.panelWidth || 340) - 32);
    const drawW = rendered ? Math.round(rendered.width * Math.min(1, availW / Math.max(1, rendered.width))) : 0;
    const drawH = rendered ? Math.round(rendered.height * Math.min(1, availW / Math.max(1, rendered.width))) : 0;
    const font = this.showCode && this.codeState ? settings() : null;

    return v_flex()
      .id("mermaid-root")
      .size_full()
      .min_h(0)
      .rounded(10)
      .overflow_hidden()
      .bg(t.background)
      .border_1()
      .border_color(t.border)
      .text_color(t.foreground)
      .text_size(13)
      .on_size_change((size, cx) => {
        const w = size.width / (settings().zoom || 1);
        if (Math.abs(w - this.panelWidth) > 2) {
          this.panelWidth = w;
          cx.notify();
        }
      })
      .child(
        h_flex()
          .h(42)
          .flex_none()
          .px(12)
          .gap(6)
          .items_center()
          .border_b(1)
          .border_color(t.border)
          .child(svg("mods/mermaid-viewer/icon.svg").size(14).flex_none().text_color(t.accent))
          .child(div().font_semibold().child("Mermaid"))
          .when(this.blocks.length > 0, (el) =>
            el.child(
              div()
                .px(6)
                .h(18)
                .flex()
                .items_center()
                .rounded(5)
                .bg(t.surface)
                .text_size(11)
                .text_color(t.muted)
                .child(String(this.blocks.length)),
            ),
          )
          .child(div().flex_1())
          .child(pillButton(t, "mmd-clip", "Clipboard", false, (_e, cx) => this.loadClipboard(cx)))
          .child(pillButton(t, "mmd-refresh", "Refresh", false, (_e, cx) => this.scanTerminal(cx, true))),
      )
      .when(this.blocks.length > 1, (el) =>
        el.child(
          h_flex()
            .id("mmd-switcher")
            .flex_none()
            .px(10)
            .py(6)
            .gap(6)
            .overflow_x_scrollbar()
            .border_b(1)
            .border_color(t.border)
            .children(
              this.blocks.map((b, i) =>
                pillButton(
                  t,
                  `mmd-pick-${i}`,
                  `#${i + 1} ${b.type}${b.fromClipboard ? " (clip)" : ""}`,
                  b.hash === block?.hash,
                  (_e, cx) => {
                    this.selectedHash = b.hash;
                    this.ensureRendered(b, cx);
                    cx.notify();
                  },
                ),
              ),
            ),
        ),
      )
      .when(Boolean(block), (el) =>
        el.child(
          h_flex()
            .flex_none()
            .px(10)
            .py(6)
            .gap(6)
            .items_center()
            .border_b(1)
            .border_color(t.border)
            .when(Boolean(rendered), (el2) =>
              el2.child(
                pillButton(t, "mmd-pop", "Pop out", false, () => {
                  openOverlay({
                    mod: "mermaid-viewer",
                    kind: "window",
                    width: 960,
                    height: 700,
                    props: {
                      mode: "window",
                      hash: block.hash,
                      code: block.code,
                      relPath: rendered.relPath,
                      absPath: rendered.absPath,
                      htmlPath: rendered.htmlPath,
                      width: rendered.width,
                      height: rendered.height,
                      title: `${block.type} (${this.sourceLabel || "Mermaid"})`,
                    },
                  });
                }),
              ),
            )
            .when(Boolean(rendered?.htmlPath), (el2) =>
              el2.child(pillButton(t, "mmd-browser", "Browser", false, (_e, cx) => this.openBrowser(rendered.htmlPath, cx))),
            )
            .child(
              pillButton(t, "mmd-code", this.showCode ? "Diagram" : "Code", this.showCode, (_e, cx) => {
                this.showCode = !this.showCode;
                if (this.showCode) this.syncCodeState(block.code, block.hash);
                cx.notify();
              }),
            )
            .child(pillButton(t, "mmd-copy", "Copy", false, (_e, cx) => this.copyCode(block.code, cx))),
        ),
      )
      .when(!block, (el) =>
        el.child(
          v_flex()
            .flex_1()
            .p(16)
            .gap(10)
            .items_center()
            .justify_center()
            .child(div().text_color(t.muted).font_medium().child("No Mermaid diagrams detected"))
            .child(
              div()
                .text_size(12)
                .text_color(t.dim)
                .text_center()
                .child("Waiting for ```mermaid blocks or diagram code in the focused terminal, or paste code and click Clipboard."),
            ),
        ),
      )
      .when(Boolean(block) && this.showCode && Boolean(this.codeState), (el) =>
        el.child(Editor.new(this.codeState).font_family(font.font_family).text_size(font.font_size).flex_1().min_h(0)),
      )
      .when(Boolean(block) && !this.showCode, (el) =>
        el.child(
          v_flex()
            .id("mmd-body")
            .flex_1()
            .min_h(0)
            .overflow_y_scrollbar()
            .p(12)
            .gap(10)
            .when(Boolean(rendered), (el2) =>
              el2.child(
                div()
                  .rounded(8)
                  .border_1()
                  .border_color(t.border)
                  .overflow_hidden()
                  .child(image(rendered.relPath).w(drawW).h(drawH).flex_none()),
              ),
            )
            .when(!rendered && isRendering, (el2) =>
              el2.child(div().p(12).text_size(12).text_color(t.dim).child("Rendering diagram…")),
            )
            .when(Boolean(err), (el2) =>
              el2.child(
                v_flex()
                  .p(10)
                  .gap(8)
                  .rounded(8)
                  .bg(t.surface)
                  .border_1()
                  .border_color(t.blocked)
                  .child(div().text_size(12).font_semibold().text_color(t.blocked).child("Mermaid render error"))
                  .child(div().text_size(11.5).text_color(t.muted).child(err))
                  .child(div().text_size(11.5).text_color(t.dim).child(block.code)),
              ),
            ),
        ),
      );
  }
}
