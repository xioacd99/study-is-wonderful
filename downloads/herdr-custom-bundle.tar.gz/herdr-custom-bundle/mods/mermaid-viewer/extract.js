const DIAGRAM_HEADER_RE =
  /^(?:flowchart(?:\s+(?:TB|TD|BT|RL|LR))?|graph(?:\s+(?:TB|TD|BT|RL|LR))?|sequenceDiagram|classDiagram(?:-v2)?|stateDiagram(?:-v2)?|erDiagram|gantt|pie(?:\s+showData)?|gitGraph|mindmap|timeline|journey|quadrantChart|requirementDiagram|xychart-beta|block-beta|packet-beta|sankey-beta|architecture-beta|kanban|C4Context|C4Container|C4Component|C4Dynamic|C4Deployment|%%\{init:)\b/;

const FENCE_OPEN_RE = /^([`~]{3,})\s*mermaid\b.*$/i;
const TUI_DIVIDER_RE = /^[\s─━═\-_┄┈╌╍╭╮╰╯┌┐└┘┬┴┼├┤]{6,}$/;
const PROMPT_RE = /^(?:[>❯›$#%]\s+|Worked for\s+\d|↳\s+Recap:|Context\s+\d+%)/;
const HEADING_RE = /^#{1,6}\s+\S/;
const MERMAID_BODY_HINT_RE =
  /(?:-->|---|-\.-|==>|-.->|--x|--o|<-->|<<->>|->>|-->>|->|:|\{|\}|\[|\]|\(|\)|subgraph\b|end\b|participant\b|actor\b|class\b|state\b|section\b|title\b|direction\b|style\b|classDef\b|click\b|linkStyle\b|loop\b|alt\b|else\b|opt\b|par\b|note\b|Note\b|%%)/;

export function stripAnsi(text) {
  return String(text ?? "")
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, "")
    .replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "")
    .replace(/\r/g, "");
}

function cleanTuiLine(line) {
  let s = line.replace(/\s+$/g, "");
  // Strip TUI box borders when wrapped in │ ... │ or ┃ ... ┃ or leading ▎/▏
  s = s.replace(/^\s*[│┃▎▏]\s?/, "").replace(/\s*[│┃]\s*$/, "");
  return s;
}

function dedentLines(lines) {
  const nonEmpty = lines.filter((l) => l.trim().length > 0);
  if (nonEmpty.length === 0) return "";
  let minIndent = Infinity;
  for (const l of nonEmpty) {
    const m = l.match(/^(\s*)/);
    if (m && m[1].length < minIndent) minIndent = m[1].length;
  }
  if (!Number.isFinite(minIndent) || minIndent === 0) {
    return lines.join("\n").trim();
  }
  return lines.map((l) => l.slice(minIndent)).join("\n").trim();
}

function detectType(code) {
  const lines = code.split("\n").map((l) => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (line.startsWith("%%")) continue;
    const m = line.match(/^([A-Za-z][A-Za-z0-9_-]*)/);
    if (m) return m[1];
  }
  return "diagram";
}

function quickHash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}

function looksLikeMermaidLine(trimmed) {
  if (!trimmed) return false;
  if (trimmed.startsWith("%%")) return true;
  if (DIAGRAM_HEADER_RE.test(trimmed)) return true;
  return MERMAID_BODY_HINT_RE.test(trimmed);
}

export function extractMermaidBlocks(rawText) {
  const cleanLines = stripAnsi(rawText).split("\n").map(cleanTuiLine);
  const found = [];
  const fencedLineRanges = [];

  // Pass 1: fenced ```mermaid or ~~~mermaid blocks
  for (let i = 0; i < cleanLines.length; i++) {
    const trimmed = cleanLines[i].trim();
    const openMatch = FENCE_OPEN_RE.exec(trimmed);
    if (!openMatch) continue;
    const fenceChar = openMatch[1][0];
    const fenceLen = openMatch[1].length;
    const closeRe = new RegExp(`^${fenceChar}{${fenceLen},}\\s*$`);
    const blockLines = [];
    let closedAt = -1;
    for (let j = i + 1; j < cleanLines.length; j++) {
      if (closeRe.test(cleanLines[j].trim())) {
        closedAt = j;
        break;
      }
      if (TUI_DIVIDER_RE.test(cleanLines[j].trim()) || PROMPT_RE.test(cleanLines[j].trim())) {
        break;
      }
      blockLines.push(cleanLines[j]);
    }
    if (closedAt !== -1 && blockLines.some((l) => l.trim().length > 0)) {
      const code = dedentLines(blockLines);
      if (code) {
        found.push({ code, type: detectType(code), hash: quickHash(code), fenced: true });
        fencedLineRanges.push([i, closedAt]);
        i = closedAt;
      }
    }
  }

  const inFencedRange = (idx) => fencedLineRanges.some(([s, e]) => idx >= s && idx <= e);

  // Pass 2: unfenced/TUI-rendered Mermaid blocks
  for (let i = 0; i < cleanLines.length; i++) {
    if (inFencedRange(i)) continue;
    const trimmed = cleanLines[i].trim();
    if (!DIAGRAM_HEADER_RE.test(trimmed)) continue;

    const blockLines = [cleanLines[i]];
    let j = i + 1;
    for (; j < cleanLines.length; j++) {
      if (inFencedRange(j)) break;
      const cur = cleanLines[j];
      const curTrimmed = cur.trim();
      if (TUI_DIVIDER_RE.test(curTrimmed) || PROMPT_RE.test(curTrimmed) || HEADING_RE.test(curTrimmed)) {
        break;
      }
      if (/^[`~]{3,}/.test(curTrimmed)) break;
      if (!curTrimmed) {
        // Look ahead past blank lines; stop if next non-empty line is prose or a new unrelated block
        let k = j + 1;
        while (k < cleanLines.length && !cleanLines[k].trim()) k++;
        if (k >= cleanLines.length) break;
        const nextTrimmed = cleanLines[k].trim();
        if (
          TUI_DIVIDER_RE.test(nextTrimmed) ||
          PROMPT_RE.test(nextTrimmed) ||
          HEADING_RE.test(nextTrimmed) ||
          DIAGRAM_HEADER_RE.test(nextTrimmed) ||
          !looksLikeMermaidLine(nextTrimmed)
        ) {
          break;
        }
        blockLines.push(cur);
        continue;
      }
      if (!looksLikeMermaidLine(curTrimmed) && blockLines.filter((l) => l.trim()).length >= 2) {
        // Likely prose after the diagram ended without a blank line
        if (/^[-*•●]\s+|^\d+\.\s+/.test(curTrimmed) || /[。.!?]$/.test(curTrimmed)) {
          break;
        }
      }
      blockLines.push(cur);
    }

    const nonEmptyCount = blockLines.filter((l) => l.trim().length > 0).length;
    if (nonEmptyCount >= 2) {
      const code = dedentLines(blockLines);
      if (code) {
        found.push({ code, type: detectType(code), hash: quickHash(code), fenced: false });
      }
    }
    i = j - 1;
  }

  // Deduplicate keeping newest last, then return newest first
  const deduped = new Map();
  for (const item of found) {
    if (deduped.has(item.code)) deduped.delete(item.code);
    deduped.set(item.code, item);
  }
  return Array.from(deduped.values()).reverse();
}
