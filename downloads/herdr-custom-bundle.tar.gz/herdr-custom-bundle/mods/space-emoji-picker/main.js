// Categorized click-to-select emoji menu popup for a space, with a randomizer.
import { View, div } from "gpui-kit";
import { v_flex, h_flex } from "gpui-base";
import { props, closeOverlay, theme, shared, setShared } from "herdr";

const CATEGORIES = [
  {
    id: "work",
    icon: "🚀",
    label: "Work",
    emojis: [
      "🚀", "⚡", "🔥", "✨", "🎯", "🧠", "🛠️", "📦",
      "💻", "🖥️", "⌨️", "🐛", "🧪", "📡", "🔧", "⚙️",
      "🧩", "🔑", "💡", "📌", "📊", "📈", "🗂️", "📁",
      "📝", "🔍", "🔒", "🛡️", "🤖", "🦾", "🌐", "☁️",
    ],
  },
  {
    id: "nature",
    icon: "🌿",
    label: "Nature",
    emojis: [
      "🌿", "🌊", "🌙", "☀️", "🌈", "❄️", "🍀", "🌵",
      "🌸", "🌻", "🍁", "🌲", "⛰️", "🏔️", "🏝️", "🌋",
      "🌍", "🪐", "⭐", "☄️", "⛅", "🌩️", "💧", "🪴",
    ],
  },
  {
    id: "animals",
    icon: "🦊",
    label: "Animals",
    emojis: [
      "🦊", "🐙", "🐳", "🦉", "🐝", "🦋", "🐢", "🦄",
      "🐱", "🐶", "🐻", "🐼", "🐨", "🐯", "🦁", "🐸",
      "🐧", "🦅", "🦈", "🐬", "🦖", "🐉", "🦩", "🦜",
    ],
  },
  {
    id: "food",
    icon: "☕",
    label: "Food",
    emojis: [
      "☕", "🍵", "🧋", "🍺", "🍷", "🍎", "🍋", "🍑",
      "🥑", "🍓", "🍒", "🍉", "🍕", "🍜", "🍣", "🌮",
      "🍔", "🥐", "🍩", "🍪", "🎂", "🍫", "🍿", "🌶️",
    ],
  },
  {
    id: "fun",
    icon: "🎨",
    label: "Fun",
    emojis: [
      "🎨", "🎵", "🎮", "📚", "🔬", "🧭", "💎", "🔮",
      "🏙️", "🏠", "🛸", "⛵", "🚂", "🚲", "✈️", "🎈",
      "🎁", "🏆", "🥇", "🎲", "🎬", "📷", "🎸", "🪩",
    ],
  },
  {
    id: "symbols",
    icon: "💜",
    label: "Symbols",
    emojis: [
      "💜", "💙", "💚", "🧡", "❤️", "💛", "🤍", "🖤",
      "🩷", "🩵", "✅", "⭕", "🔺", "🔷", "🔶", "💠",
      "♻️", "♾️", "⚜️", "✳️", "✴️", "❇️", "🏁", "🚩",
    ],
  },
];

const ALL_EMOJIS = CATEGORIES.flatMap((c) => c.emojis);

function categoryOf(emoji) {
  return CATEGORIES.find((c) => c.emojis.includes(emoji))?.id ?? CATEGORIES[0].id;
}

function pickRandom(current, used) {
  const usedSet = new Set(used ?? []);
  const fresh = ALL_EMOJIS.filter((e) => e !== current && !usedSet.has(e));
  const pool = fresh.length ? fresh : ALL_EMOJIS.filter((e) => e !== current);
  return pool[Math.floor(Math.random() * pool.length)] ?? ALL_EMOJIS[0];
}

export default class SpaceEmojiPicker extends View {
  init(_props, cx) {
    const p = props() ?? {};
    const current = (shared("space.emojis") ?? {})[p.spaceId];
    this.category = current ? categoryOf(current) : CATEGORIES[0].id;
    this.handle = cx.focus_handle();
    this.handle.focus();
  }

  setEmoji(emoji, close = true) {
    const p = props() ?? {};
    if (!p.spaceId || !emoji) return;
    const map = { ...(shared("space.emojis") ?? {}), [p.spaceId]: emoji };
    setShared("space.emojis", map);
    if (close && p.overlay) closeOverlay(p.overlay);
  }

  randomize(cx) {
    const p = props() ?? {};
    const map = shared("space.emojis") ?? {};
    const current = map[p.spaceId];
    const next = pickRandom(current, Object.values(map));
    this.setEmoji(next, false);
    this.category = categoryOf(next);
    cx.notify();
  }

  render() {
    const t = theme();
    const p = props() ?? {};
    const current = (shared("space.emojis") ?? {})[p.spaceId] ?? "✨";
    const activeCat = CATEGORIES.find((c) => c.id === this.category) ?? CATEGORIES[0];

    const rows = [];
    for (let i = 0; i < activeCat.emojis.length; i += 8) {
      rows.push(activeCat.emojis.slice(i, i + 8));
    }

    return v_flex()
      .id("space-emoji-picker")
      .track_focus(this.handle)
      .on_key_down((e, cx) => {
        if (e.key === "escape") {
          closeOverlay(p.overlay);
          cx.stop_propagation();
        }
      })
      .w_full()
      .p(12)
      .gap(8)
      .bg(t.popover)
      .text_color(t.foreground)
      .child(
        h_flex()
          .items_center()
          .gap(8)
          .child(
            h_flex()
              .size(24)
              .flex_none()
              .items_center()
              .justify_center()
              .text_size(16)
              .child(current),
          )
          .child(
            div()
              .flex_1()
              .min_w(0)
              .truncate()
              .text_size(13)
              .font_semibold()
              .child(p.spaceName ?? "Space Icon"),
          )
          .child(
            h_flex()
              .id("emoji-random-btn")
              .h(26)
              .px(8)
              .gap(4)
              .items_center()
              .rounded(6)
              .border_1()
              .border_color(t.border)
              .bg(t.raised)
              .text_size(12)
              .cursor_pointer()
              .hover((s) => s.bg(t.hover))
              .on_click((_e, cx) => this.randomize(cx))
              .child("🎲 Random"),
          ),
      )
      .child(
        h_flex()
          .gap(4)
          .items_center()
          .children(
            CATEGORIES.map((cat) => {
              const selected = cat.id === activeCat.id;
              return h_flex()
                .id(`emoji-cat-${cat.id}`)
                .h(26)
                .flex_1()
                .rounded(6)
                .items_center()
                .justify_center()
                .text_size(14)
                .cursor_pointer()
                .tooltip(cat.label)
                .when(selected, (el) => el.bg(t.selected))
                .when(!selected, (el) => el.hover((s) => s.bg(t.hover)))
                .on_click((_e, cx) => {
                  this.category = cat.id;
                  cx.notify();
                })
                .child(cat.icon);
            }),
          ),
      )
      .child(div().h(1).bg(t.border))
      .child(
        v_flex()
          .w_full()
          .min_h(132)
          .gap(4)
          .children(
            rows.map((row, rowIdx) =>
              h_flex()
                .w_full()
                .gap(4)
                .justify_between()
                .children(
                  row.map((em, colIdx) => {
                    const idx = rowIdx * 8 + colIdx;
                    const active = em === current;
                    return h_flex()
                      .id(`emoji-opt-${activeCat.id}-${idx}`)
                      .size(30)
                      .rounded(6)
                      .items_center()
                      .justify_center()
                      .text_size(16)
                      .cursor_pointer()
                      .when(active, (el) => el.bg(t.selected).border_1().border_color(t.accent))
                      .when(!active, (el) => el.hover((s) => s.bg(t.hover)))
                      .on_click(() => this.setEmoji(em, true))
                      .child(em);
                  }),
                ),
            ),
          ),
      );
  }
}
