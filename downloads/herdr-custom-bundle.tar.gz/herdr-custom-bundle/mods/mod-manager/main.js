import { View, div, svg } from "gpui-kit";
import { v_flex, h_flex, ScrollHandle } from "gpui-base";
import { theme, shared, setShared, run, layout, props, closeOverlay, keys, window } from "herdr";

const DEFAULT_PANELS = ["files", "changes", "subagents", "mermaid", "asks"];

const PANEL_ITEMS = [
  {
    id: "files",
    name: "Files 文件浏览器",
    desc: "自定义文件树与快速预览 (files-custom)",
    icon: "mods/files-custom/file.svg",
    command: "workspace-helper.toggle_files",
  },
  {
    id: "changes",
    name: "Changes Git 变更",
    desc: "查看当前工作区已修改文件与 diff (changes)",
    icon: "mods/changes/changes.svg",
    command: "workspace-helper.toggle_changes",
  },
  {
    id: "subagents",
    name: "Subagents 多智能体树",
    desc: "实时树形展示 Multi-Agent 与 Subagent 执行/待办/完成分组 (subagent-tree)",
    icon: "mods/subagent-tree/icon.svg",
    command: "workspace-helper.toggle_subagents",
  },
  {
    id: "mermaid",
    name: "Mermaid 图表预览",
    desc: "自动提取并渲染终端/文档中的 Mermaid 图表 (mermaid-viewer)",
    icon: "mods/mermaid-viewer/icon.svg",
    command: "workspace-helper.toggle_mermaid",
  },
  {
    id: "asks",
    name: "Asks Agent 提问聚合",
    desc: "汇总等待你确认或回答的 Agent 问题并直接回复 (asks)",
    icon: "mods/asks/asks.svg",
    command: "workspace-helper.toggle_asks",
  },
];

const SPECIAL_KEY_NAMES = {
  left: "←",
  right: "→",
  up: "↑",
  down: "↓",
  enter: "↵",
  return: "↵",
  backspace: "⌫",
  tab: "⇥",
  escape: "Esc",
  esc: "Esc",
  space: "Space",
};

function formatKeystroke(raw) {
  if (!raw) return "";
  if (raw.endsWith("1–9")) {
    const prefix = raw.slice(0, -3).replace(/-$/, "");
    return `${prefix ? formatKeystroke(prefix) : ""}1–9`;
  }
  const mac = window()?.platform === "macos";
  const mod = {
    cmd: mac ? "⌘" : "Ctrl+",
    ctrl: mac ? "⌃" : "Ctrl+",
    shift: mac ? "⇧" : "Shift+",
    alt: mac ? "⌥" : "Alt+",
    option: mac ? "⌥" : "Alt+",
  };
  const parts = raw.endsWith("--") ? [...raw.slice(0, -2).split("-"), "-"] : raw.split("-");
  return parts
    .filter((p) => p.length > 0)
    .map((p) => {
      const lower = p.toLowerCase();
      return mod[lower] ?? SPECIAL_KEY_NAMES[lower] ?? p.toUpperCase();
    })
    .join("");
}

const ACTION_LABELS = {
  "workspace-helper.toggle_files": "切换 Files 面板",
  "workspace-helper.toggle_changes": "切换 Changes 面板",
  "workspace-helper.toggle_subagents": "切换 Subagents 面板",
  "workspace-helper.toggle_mermaid": "切换 Mermaid 面板",
  "workspace-helper.toggle_asks": "切换 Asks 面板",
  "mod.open:mod-manager": "打开 Mod Manager",
  "mod.open:picker": "快速搜索 Picker",
  "layout.toggle:sidebar": "显隐左侧边栏",
  "layout.switch": "切换窗口布局",
  "space.new": "新建工作区",
  "space.prev": "上一个工作区",
  "space.next": "下一个工作区",
  "space.rename": "重命名当前工作区",
  "tab.new": "新建标签页",
  "tab.close": "关闭当前标签页",
  "tab.prev": "上一个标签页",
  "tab.next": "下一个标签页",
  "tab.rename": "重命名当前标签页",
  "agent.prev": "上一个 Agent",
  "agent.next": "下一个 Agent",
  "pane.split:right": "向右分屏",
  "pane.split:down": "向下分屏",
  "pane.close": "关闭当前分屏",
  "pane.zoom": "缩放/还原当前分屏",
  "pane.go:left": "焦点移至左侧分屏",
  "pane.go:right": "焦点移至右侧分屏",
  "pane.go:up": "焦点移至上方分屏",
  "pane.go:down": "焦点移至下方分屏",
  "pane.swap:left": "与左侧分屏交换位置",
  "pane.swap:right": "与右侧分屏交换位置",
  "pane.swap:up": "与上方分屏交换位置",
  "pane.swap:down": "与下方分屏交换位置",
  "app.palette": "打开命令面板",
  "app.settings": "打开应用设置",
  "app.help": "打开快捷键列表",
  "app.zoom_in": "放大界面字体",
  "app.zoom_out": "缩小界面字体",
  "app.zoom_reset": "重置界面缩放",
  "app.hide": "隐藏 Herdr 窗口",
  "app.hide_others": "隐藏其他应用",
  "app.quit": "退出 Herdr",
  "window.minimize": "最小化窗口",
  "terminal.copy": "复制终端选中内容",
  "terminal.paste": "粘贴到终端",
  "terminal.paste_image": "粘贴剪贴板图片到终端",
  "terminal.select_all": "全选终端内容",
  "terminal.search": "在终端内搜索",
};

const SEND_LABELS = {
  "\u0017": "删除前一个单词",
  "\u001bb": "光标左移一个单词",
  "\u001bf": "光标右移一个单词",
  "\u0015": "清空光标前输入",
  "\u0001": "移动到行首",
  "\u0005": "移动到行尾",
};

function describeAction(action) {
  if (ACTION_LABELS[action]) return ACTION_LABELS[action];
  if (action.startsWith("send:")) {
    const payload = action.slice(5);
    return SEND_LABELS[payload] ?? `发送序列 ${JSON.stringify(payload)}`;
  }
  const [name, arg] = action.split(":");
  const words = name.replace(/[._]/g, " ");
  return arg ? `${words} ${arg}` : words;
}

const KEY_CATEGORIES = [
  { id: "all", title: "全部" },
  { id: "panels", title: "面板与 Mod", test: (k) => /^(workspace-helper\.|mod\.open:|layout\.)/.test(k.action) },
  { id: "nav", title: "工作区与标签", test: (k) => /^(space\.|tab\.|agent\.)/.test(k.action) },
  { id: "pane", title: "分屏 Pane", test: (k) => /^pane\./.test(k.action) },
  { id: "app", title: "应用与窗口", test: (k) => /^(app\.|window\.)/.test(k.action) },
  { id: "terminal", title: "终端", test: (k) => k.section === "terminal" || /^(terminal\.|send:)/.test(k.action) },
];

function compactSelectRange(entries, prefixAction, label) {
  const matched = new Map();
  const others = [];
  for (const entry of entries) {
    if (entry.section === "global" && entry.action.startsWith(`${prefixAction}:`)) {
      const idx = entry.action.slice(prefixAction.length + 1);
      if (/^[1-9]$/.test(idx) && entry.rawKeys.length === 1) {
        matched.set(idx, entry);
        continue;
      }
    }
    others.push(entry);
  }
  if (matched.size === 9) {
    const prefixes = new Set([...matched.values()].map((e) => e.rawKeys[0].slice(0, -1)));
    const firstKey = matched.get("1").rawKeys[0];
    if (prefixes.size === 1 && firstKey.endsWith("1")) {
      const prefix = firstKey.slice(0, -1);
      return [
        {
          section: "global",
          action: `${prefixAction}:1..9`,
          rawKeys: [`${prefix}1–9`],
          rawHint: `${prefix}1..9`,
          label,
        },
        ...others,
      ];
    }
  }
  return entries;
}

function buildKeyGroups(allKeys) {
  const merged = [];
  const byKey = new Map();
  for (const k of allKeys) {
    const id = `${k.section}::${k.action}`;
    let entry = byKey.get(id);
    if (!entry) {
      entry = {
        section: k.section,
        action: k.action,
        rawKeys: [],
        label: describeAction(k.action),
      };
      byKey.set(id, entry);
      merged.push(entry);
    }
    if (!entry.rawKeys.includes(k.keys)) {
      entry.rawKeys.push(k.keys);
    }
  }

  let compacted = compactSelectRange(merged, "tab.select", "切换到第 1–9 个标签");
  compacted = compactSelectRange(compacted, "space.select", "切换到第 1–9 个工作区");

  const used = new Set();
  const groups = [];
  for (const cat of KEY_CATEGORIES) {
    if (cat.id === "all") continue;
    const rows = compacted.filter((entry) => !used.has(entry) && cat.test(entry));
    for (const row of rows) used.add(row);
    if (rows.length > 0) groups.push({ id: cat.id, title: cat.title, rows });
  }
  const rest = compacted.filter((entry) => !used.has(entry));
  if (rest.length > 0) {
    groups.push({ id: "other", title: "其他", rows: rest });
  }
  return groups;
}

function findNode(node, id) {
  if (node?.id === id) return node;
  for (const child of node?.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
}

export default class ModManager extends View {
  init(_props, cx) {
    this.scroll = ScrollHandle.new();
    this.keyFilter = "all";
    this.handle = cx.focus_handle();
    this.handle.focus();
  }

  close() {
    const id = props()?.overlay;
    if (id) closeOverlay(id);
  }

  enabledPanels() {
    const saved = shared("mods.panels");
    if (!Array.isArray(saved)) return [...DEFAULT_PANELS];
    const set = new Set(saved);
    return DEFAULT_PANELS.filter((id) => set.has(id));
  }

  togglePanelEnabled(panelId) {
    const current = new Set(this.enabledPanels());
    if (current.has(panelId)) {
      current.delete(panelId);
      const root = layout();
      const panel = findNode(root, "panel");
      const body = findNode(root, "panel-body");
      if (panel && !panel.hidden && body?.active === panelId) {
        run("layout.hide", { id: "panel" });
      }
    } else {
      current.add(panelId);
    }
    const next = DEFAULT_PANELS.filter((id) => current.has(id));
    setShared("mods.panels", next);
  }

  openPanel(panelId) {
    const current = new Set(this.enabledPanels());
    if (!current.has(panelId)) {
      current.add(panelId);
      setShared("mods.panels", DEFAULT_PANELS.filter((id) => current.has(id)));
    }
    run("layout.select", { stack: "panel-body", child: panelId });
    run("layout.show", { id: "panel" });
    this.close();
  }

  renderSwitch(id, on, t, onClick) {
    return h_flex()
      .id(id)
      .w(34)
      .h(20)
      .px(3)
      .rounded_full()
      .items_center()
      .justify_end()
      .when(!on, (el) => el.justify_start())
      .bg(on ? t.accent : t.border)
      .cursor_pointer()
      .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
      .on_click(onClick)
      .child(div().size(14).rounded_full().bg(on ? t.accent_foreground : t.foreground));
  }

  renderKeyCaps(rawKeys, t) {
    if (!rawKeys || rawKeys.length === 0) return null;
    return h_flex()
      .gap(4)
      .items_center()
      .flex_none()
      .children(
        rawKeys.map((raw) =>
          div()
            .px(5)
            .py(1)
            .rounded(4)
            .bg(t.chrome)
            .border_1()
            .border_color(t.border)
            .text_size(10.5)
            .font_semibold()
            .text_color(t.accent)
            .tooltip(raw)
            .child(formatKeystroke(raw)),
        ),
      );
  }

  renderRow({ id, icon, title, titleExtra, desc, right }) {
    const t = theme();
    return h_flex()
      .id(id)
      .w_full()
      .px(12)
      .py(9)
      .gap(10)
      .items_center()
      .rounded(8)
      .bg(t.surface)
      .border_1()
      .border_color(t.border)
      .child(
        div()
          .size(28)
          .flex_none()
          .rounded(7)
          .bg(t.chrome)
          .border_1()
          .border_color(t.border)
          .flex()
          .items_center()
          .justify_center()
          .child(svg(icon).size(15).text_color(t.foreground)),
      )
      .child(
        v_flex()
          .flex_1()
          .min_w(0)
          .gap(2)
          .child(
            h_flex()
              .gap(6)
              .items_center()
              .min_w(0)
              .child(div().text_size(13).font_semibold().text_color(t.foreground).truncate().child(title))
              .when(Boolean(titleExtra), (el) => el.child(titleExtra)),
          )
          .child(div().text_size(11.5).text_color(t.muted).truncate().child(desc)),
      )
      .child(right);
  }

  renderSectionTitle(text, t) {
    return div()
      .px(2)
      .pt(6)
      .pb(4)
      .text_size(11.5)
      .font_semibold()
      .text_color(t.dim)
      .child(text);
  }

  renderActionBtn(id, label, t, onClick, primary = false) {
    return div()
      .id(id)
      .h(26)
      .px(10)
      .rounded(6)
      .flex()
      .items_center()
      .justify_center()
      .text_size(11.8)
      .font_semibold()
      .bg(primary ? t.accent : t.chrome)
      .text_color(primary ? t.accent_foreground : t.foreground)
      .border_1()
      .border_color(primary ? t.accent : t.border)
      .hover((s) => s.bg(primary ? t.accent : t.hover))
      .cursor_pointer()
      .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
      .on_click(onClick)
      .child(label);
  }

  renderFilterPill(cat, active, t) {
    return div()
      .id(`key-cat-${cat.id}`)
      .h(22)
      .px(8)
      .rounded(6)
      .flex()
      .items_center()
      .justify_center()
      .text_size(11)
      .font_medium()
      .bg(active ? t.accent : t.surface)
      .text_color(active ? t.accent_foreground : t.muted)
      .border_1()
      .border_color(active ? t.accent : t.border)
      .hover((s) => s.when(!active, (h) => h.bg(t.hover).text_color(t.foreground)))
      .cursor_pointer()
      .on_mouse_down("left", (_e, cx) => cx.stop_propagation())
      .on_click((_e, cx) => {
        this.keyFilter = cat.id;
        cx.notify();
      })
      .child(cat.title);
  }

  renderKeySection(keyGroups, t) {
    const visibleGroups =
      this.keyFilter === "all" ? keyGroups : keyGroups.filter((g) => g.id === this.keyFilter);

    return v_flex()
      .gap(6)
      .child(
        h_flex()
          .px(2)
          .pt(6)
          .pb(2)
          .items_center()
          .justify_between()
          .gap(8)
          .child(
            h_flex()
              .gap(6)
              .items_center()
              .child(svg("frame/settings/keyboard.svg").size(13).text_color(t.dim))
              .child(div().text_size(11.5).font_semibold().text_color(t.dim).child("快捷键绑定"))
              .child(div().text_size(10.5).text_color(t.muted).child("~/.config/herdr-app/keys.json")),
          )
          .child(
            this.renderActionBtn(
              "open-all-keys",
              "全部快捷键",
              t,
              () => {
                this.close();
                run("app.help");
              },
              false,
            ),
          ),
      )
      .child(
        h_flex()
          .gap(4)
          .flex_wrap()
          .children(KEY_CATEGORIES.map((cat) => this.renderFilterPill(cat, this.keyFilter === cat.id, t))),
      )
      .children(
        visibleGroups.map((group) =>
          v_flex()
            .gap(4)
            .when(this.keyFilter === "all", (el) =>
              el.child(div().px(2).pt(2).text_size(11).font_medium().text_color(t.dim).child(group.title)),
            )
            .child(
              v_flex()
                .rounded(8)
                .bg(t.surface)
                .border_1()
                .border_color(t.border)
                .children(
                  group.rows.map((entry, idx) => {
                    const rawSyntax = entry.rawHint ?? entry.rawKeys.join(" / ");
                    return h_flex()
                      .id(`key-row-${entry.section}-${entry.action}`)
                      .w_full()
                      .px(12)
                      .py(7)
                      .gap(8)
                      .items_center()
                      .justify_between()
                      .when(idx > 0, (el) => el.border_t(1).border_color(t.border))
                      .child(
                        h_flex()
                          .flex_1()
                          .min_w(0)
                          .gap(6)
                          .items_center()
                          .child(
                            div()
                              .text_size(12.2)
                              .text_color(t.foreground)
                              .truncate()
                              .child(entry.label),
                          )
                          .child(
                            div()
                              .text_size(10.5)
                              .text_color(t.dim)
                              .truncate()
                              .child(entry.action),
                          ),
                      )
                      .child(
                        h_flex()
                          .gap(6)
                          .items_center()
                          .flex_none()
                          .child(div().text_size(10.5).text_color(t.muted).child(rawSyntax))
                          .child(this.renderKeyCaps(entry.rawKeys, t)),
                      );
                  }),
                ),
            ),
        ),
      );
  }

  render() {
    const t = theme();
    const enabled = new Set(this.enabledPanels());
    const root = layout();
    const panelNode = findNode(root, "panel");
    const bodyNode = findNode(root, "panel-body");
    const activePanel = panelNode && !panelNode.hidden ? bodyNode?.active : null;

    const notifyOn = shared("mods.notifications") !== false;
    const openDefaultOn = shared("mods.open_default") !== false;
    const showPanelLabels = shared("mods.panel_labels") === true;

    const allKeys = keys();
    const modManagerBindings = allKeys
      .filter((k) => k.section === "global" && k.action === "mod.open:mod-manager")
      .map((k) => formatKeystroke(k.keys));
    const headerShortcut = modManagerBindings.length > 0 ? modManagerBindings.join(" / ") : "⌘⇧M";

    const byCommand = new Map();
    for (const k of allKeys) {
      if (k.section !== "global") continue;
      const list = byCommand.get(k.action) ?? [];
      if (!list.includes(k.keys)) list.push(k.keys);
      byCommand.set(k.action, list);
    }

    const keyGroups = buildKeyGroups(allKeys);

    return v_flex()
      .id("mod-manager-root")
      .size_full()
      .bg(t.popover)
      .text_color(t.foreground)
      .track_focus(this.handle)
      .on_key_down((e) => {
        if (e.keystroke?.key === "escape") this.close();
      })
      .child(
        h_flex()
          .h(48)
          .px(16)
          .gap(10)
          .items_center()
          .border_b(1)
          .border_color(t.border)
          .child(svg("mods/workspace-chrome/layers.svg").size(16).text_color(t.accent))
          .child(
            v_flex()
              .flex_1()
              .gap(1)
              .child(div().text_size(14.5).font_semibold().text_color(t.foreground).child("Mod Manager"))
              .child(div().text_size(11).text_color(t.dim).child(`启停右侧面板与自定义功能  ·  ${headerShortcut}`)),
          )
          .child(
            div()
              .id("mod-manager-close")
              .size(26)
              .rounded(6)
              .flex()
              .items_center()
              .justify_center()
              .text_color(t.muted)
              .hover((s) => s.bg(t.hover).text_color(t.foreground))
              .cursor_pointer()
              .on_click(() => this.close())
              .child(svg("mods/workspace-chrome/x.svg").size(14)),
          ),
      )
      .child(
        v_flex()
          .id("mod-manager-scroll")
          .flex_1()
          .min_h(0)
          .p(14)
          .gap(6)
          .overflow_y_scrollbar()
          .track_scroll(this.scroll)
          .child(this.renderSectionTitle("右侧功能面板（在顶部栏显示按钮）", t))
          .children(
            PANEL_ITEMS.map((item) => {
              const on = enabled.has(item.id);
              const active = activePanel === item.id;
              const panelKeys = byCommand.get(item.command) ?? [];
              return this.renderRow({
                id: `panel-row-${item.id}`,
                icon: item.icon,
                title: item.name,
                titleExtra: this.renderKeyCaps(panelKeys, t),
                desc: item.desc,
                right: h_flex()
                  .gap(8)
                  .items_center()
                  .flex_none()
                  .when(on, (el) =>
                    el.child(
                      this.renderActionBtn(
                        `open-${item.id}`,
                        active ? "已打开" : "打开",
                        t,
                        () => this.openPanel(item.id),
                        false,
                      ),
                    ),
                  )
                  .child(
                    this.renderSwitch(`sw-${item.id}`, on, t, () => this.togglePanelEnabled(item.id)),
                  ),
              });
            }),
          )
          .child(this.renderSectionTitle("自定义能力", t))
          .child(
            this.renderRow({
              id: "feat-panel-labels",
              icon: "mods/workspace-chrome/panel-right.svg",
              title: "右上角面板按钮显示文字",
              desc: "开启后右上角面板按钮同时显示图标与文字，关闭则仅显示图标",
              right: this.renderSwitch("sw-panel-labels", showPanelLabels, t, () =>
                setShared("mods.panel_labels", !showPanelLabels),
              ),
            }),
          )
          .child(
            this.renderRow({
              id: "feat-notifications",
              icon: "mods/workspace-chrome/circle-check.svg",
              title: "Agent 桌面通知 (HerdrNotify)",
              desc: "Agent 完成任务或等待输入时弹出 macOS 系统通知",
              right: this.renderSwitch("sw-notifications", notifyOn, t, () =>
                setShared("mods.notifications", !notifyOn),
              ),
            }),
          )
          .child(
            this.renderRow({
              id: "feat-open-default",
              icon: "mods/workspace-chrome/file-text.svg",
              title: "默认应用打开 Markdown / HTML 链接",
              desc: "点击终端里的 .md / .html 路径时用系统默认应用打开",
              right: this.renderSwitch("sw-open-default", openDefaultOn, t, () =>
                setShared("mods.open_default", !openDefaultOn),
              ),
            }),
          )
          .child(this.renderKeySection(keyGroups, t)),
      );
  }
}
