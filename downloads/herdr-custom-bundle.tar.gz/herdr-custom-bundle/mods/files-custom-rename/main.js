import { View, div } from "gpui-kit";
import { v_flex, h_flex, InputState, Input } from "gpui-base";
import { run, props, closeOverlay, exec, theme } from "herdr";

const pendingActions = (globalThis[Symbol.for("herdr.filesCustom.actions.v1")] ??= []);

export default class FilesCustomRename extends View {
  init(_props, cx) {
    const p = props() ?? {};
    this.text = p.name ?? "";
    this.error = null;
    this.busy = false;
    this.input = InputState.new({ value: this.text });
    if (this.text) {
      const lastDot = this.text.lastIndexOf(".");
      const selEnd = !p.dir && lastDot > 0 ? lastDot : this.text.length;
      this.input.set_selected_range({ start: 0, end: selEnd });
    }
    this.input.on("change", (_e, cx) => {
      this.text = this.input.value();
      this.error = null;
      cx.notify();
    });
    this.input.on("submit", (_e, cx) => this.submit(cx));
    this.inputFocused = true;
    this.input.on("focus", (_e, cx) => {
      this.inputFocused = true;
      cx.notify();
    });
    this.input.on("blur", (_e, cx) => {
      this.inputFocused = false;
      cx.notify();
    });
    this.input.focus();
    cx.timer.after(150, () => this.input.focus());
    this.handle = cx.focus_handle();
  }

  submit(cx) {
    if (this.busy) return;
    const p = props() ?? {};
    const oldName = p.name ?? "";
    const newName = this.text.trim();
    if (!newName) {
      this.error = "名称不能为空";
      cx.notify();
      return;
    }
    if (newName === "." || newName === ".." || /[\\/]/.test(newName)) {
      this.error = "名称不能包含斜杠或为 . / ..";
      cx.notify();
      return;
    }
    if (newName === oldName) {
      closeOverlay(p.overlay);
      return;
    }

    const oldRel = p.path ?? oldName;
    const slashIdx = oldRel.lastIndexOf("/");
    const parentRel = slashIdx >= 0 ? oldRel.slice(0, slashIdx) : "";
    const newRel = parentRel ? `${parentRel}/${newName}` : newName;
    const baseRoot = (p.root ?? "").replace(/\/+$/, "");
    const oldFull = baseRoot ? `${baseRoot}/${oldRel}` : oldRel;
    const newFull = baseRoot ? `${baseRoot}/${newRel}` : newRel;
    const caseOnly = oldName.toLowerCase() === newName.toLowerCase() ? "1" : "0";

    this.busy = true;
    this.error = null;
    cx.notify();

    cx.spawn(async (cx) => {
      try {
        const script =
          'if [ "$3" != "1" ] && { [ -e "$2" ] || [ -L "$2" ]; }; then echo "目标名称已存在" >&2; exit 1; fi; mv -- "$1" "$2"';
        const r = await exec("sh", ["-c", script, "rename", oldFull, newFull, caseOnly], { on: p.on ?? null });
        if (r.code === 0) {
          pendingActions.push({ type: "renamed", oldPath: oldRel, newPath: newRel });
          run("files-custom.action");
          closeOverlay(p.overlay);
          return;
        }
        this.error = (r.stderr || r.stdout || "重命名失败").trim();
      } catch (e) {
        this.error = String(e);
      }
      this.busy = false;
      cx.notify();
    });
  }

  key(e, cx) {
    if (e.key === "escape") {
      closeOverlay((props() ?? {}).overlay);
      cx.stop_propagation();
    }
  }

  render() {
    const t = theme();
    const p = props() ?? {};
    const button = (id, text, primary, disabled, action) =>
      h_flex()
        .id(id)
        .h(32)
        .px(14)
        .items_center()
        .rounded(8)
        .border_1()
        .border_color(primary ? (disabled ? t.border : t.solid) : t.input)
        .bg(primary ? (disabled ? t.raised : t.solid) : t.raised)
        .text_color(primary ? (disabled ? t.dim : t.solid_foreground) : t.foreground)
        .text_size(12.5)
        .font_medium()
        .when(!disabled, (el) => el.cursor_pointer().hover((s) => s.opacity(0.88)).on_click(action))
        .child(text);

    return v_flex()
      .id("files-custom-rename")
      .track_focus(this.handle)
      .on_key_down((e, cx) => this.key(e, cx))
      .w_full()
      .min_h(0)
      .p(18)
      .bg(t.popover)
      .text_color(t.foreground)
      .child(
        h_flex()
          .items_center()
          .child(div().flex_1().text_size(15).font_semibold().child(p.dir ? "重命名文件夹" : "重命名文件"))
          .child(div().text_size(11).text_color(t.dim).child("Esc")),
      )
      .child(div().pt(14).pb(7).text_size(11.5).text_color(t.dim).child("新名称"))
      .child(
        Input.new(this.input)
          .h(36)
          .px(10)
          .rounded(9)
          .border_1()
          .border_color(this.error ? t.ansi1 : this.inputFocused ? t.accent : t.input)
          .bg(t.background)
          .text_size(12.8)
          .text_color(t.foreground),
      )
      .when(Boolean(this.error), (el) => el.child(div().pt(6).text_size(11.5).text_color(t.ansi1).child(this.error)))
      .child(
        h_flex()
          .pt(18)
          .gap(8)
          .justify_end()
          .child(button("fcr-cancel", "取消", false, this.busy, () => closeOverlay(p.overlay)))
          .child(button("fcr-save", this.busy ? "重命名中…" : "重命名", true, this.busy, (_e, cx) => this.submit(cx))),
      );
  }
}
