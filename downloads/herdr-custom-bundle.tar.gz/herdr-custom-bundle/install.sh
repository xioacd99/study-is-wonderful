#!/usr/bin/env bash
set -euo pipefail

SKIP_MERMAID=0
SKIP_NOTIFY=0
SKIP_KEYS=0

for arg in "$@"; do
  case "$arg" in
    --skip-mermaid) SKIP_MERMAID=1 ;;
    --skip-notify) SKIP_NOTIFY=1 ;;
    --skip-keys) SKIP_KEYS=1 ;;
    -h|--help)
      cat <<'EOF'
Usage: ./install.sh [options]
  --skip-mermaid   Skip running bun install for data/mermaid-viewer
  --skip-notify    Skip compiling ~/Applications/HerdrNotify.app
  --skip-keys      Do not overwrite ~/.config/herdr-app/keys.json
EOF
      exit 0
      ;;
    *)
      echo "Unknown option: $arg" >&2
      exit 1
      ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HERDR_HOME="${HERDR_APP_HOME:-$HOME/.config/herdr-app}"

if [ ! -d "$HERDR_HOME" ]; then
  echo "ERROR: $HERDR_HOME not found. Please install and launch official Herdr.app at least once first." >&2
  exit 1
fi

BACKUP_DIR="$HERDR_HOME/.backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

if [ -f "$HERDR_HOME/keys.json" ]; then
  cp "$HERDR_HOME/keys.json" "$BACKUP_DIR/keys.json"
fi
if [ -d "$HERDR_HOME/mods/workspace-chrome" ]; then
  cp -R "$HERDR_HOME/mods/workspace-chrome" "$BACKUP_DIR/workspace-chrome"
fi

echo "==> Installing mods and layout into $HERDR_HOME"
mkdir -p "$HERDR_HOME/mods" "$HERDR_HOME/layouts" "$HERDR_HOME/data"

MODS=(
  asks
  changes-custom
  changes-diff-fullscreen
  files-custom
  files-custom-menu
  files-custom-rename
  mermaid-viewer
  mod-manager
  open-default
  space-emoji-picker
  spaces-custom
  spaces-custom-menu
  subagent-tree
  tabs-custom
  workspace-chrome
  workspace-helper
)

for m in "${MODS[@]}"; do
  rm -rf "$HERDR_HOME/mods/$m"
  cp -R "$SCRIPT_DIR/mods/$m" "$HERDR_HOME/mods/$m"
done

cp "$SCRIPT_DIR/layouts/main-custom.json" "$HERDR_HOME/layouts/main-custom.json"

if [ "$SKIP_KEYS" -eq 0 ]; then
  cp "$SCRIPT_DIR/keys.json" "$HERDR_HOME/keys.json"
fi

mkdir -p "$HERDR_HOME/data/workspace-helper"
cp "$SCRIPT_DIR/data/workspace-helper/HerdrNotify.swift" "$HERDR_HOME/data/workspace-helper/HerdrNotify.swift"
rm -rf "$HERDR_HOME/data/workspace-helper/icons"
cp -R "$SCRIPT_DIR/data/workspace-helper/icons" "$HERDR_HOME/data/workspace-helper/icons"

mkdir -p "$HERDR_HOME/data/mermaid-viewer"
for f in index.ts render.mjs package.json bun.lock tsconfig.json README.md; do
  if [ -f "$SCRIPT_DIR/data/mermaid-viewer/$f" ]; then
    cp "$SCRIPT_DIR/data/mermaid-viewer/$f" "$HERDR_HOME/data/mermaid-viewer/$f"
  fi
done

MERMAID_STATUS="skipped"
if [ "$SKIP_MERMAID" -eq 0 ]; then
  if command -v bun >/dev/null 2>&1; then
    echo "==> Installing Mermaid viewer dependencies via bun"
    (cd "$HERDR_HOME/data/mermaid-viewer" && bun install)
    MERMAID_STATUS="installed"
  else
    echo "WARN: bun not found; skipping mermaid-viewer dependency install."
    MERMAID_STATUS="skipped (bun not found)"
  fi
fi

NOTIFY_STATUS="skipped"
if [ "$SKIP_NOTIFY" -eq 0 ]; then
  if [ "$(uname -s)" = "Darwin" ] && command -v swiftc >/dev/null 2>&1; then
    echo "==> Building $HOME/Applications/HerdrNotify.app"
    APP_DIR="$HOME/Applications/HerdrNotify.app"
    mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
    cp "$SCRIPT_DIR/data/workspace-helper/Info.plist" "$APP_DIR/Contents/Info.plist"
    cp "$SCRIPT_DIR/data/workspace-helper/Herdr.icns" "$APP_DIR/Contents/Resources/Herdr.icns"
    swiftc -O "$HERDR_HOME/data/workspace-helper/HerdrNotify.swift" -o "$APP_DIR/Contents/MacOS/HerdrNotify"
    codesign --force --deep --sign - "$APP_DIR"
    NOTIFY_STATUS="built at $APP_DIR"
  else
    echo "WARN: swiftc (or macOS) not available; skipping HerdrNotify.app build."
    NOTIFY_STATUS="skipped (swiftc not found)"
  fi
fi

HERDR_CLI=""
if [ -x "$HOME/.local/bin/herdr-app" ]; then
  HERDR_CLI="$HOME/.local/bin/herdr-app"
elif command -v herdr-app >/dev/null 2>&1; then
  HERDR_CLI="$(command -v herdr-app)"
fi

CLI_STATUS="skipped (herdr-app CLI not found)"
if [ -n "$HERDR_CLI" ]; then
  echo "==> Checking installed mods with $HERDR_CLI"
  for m in "${MODS[@]}"; do
    "$HERDR_CLI" check "$HERDR_HOME/mods/$m"
  done
  echo "==> Switching layout to main-custom (if Herdr window is running)"
  "$HERDR_CLI" do layout.switch --name main-custom >/dev/null 2>&1 || true
  "$HERDR_CLI" status || true
  CLI_STATUS="checked all ${#MODS[@]} mods"
fi

echo ""
echo "=== Install Summary ==="
echo "Herdr Home : $HERDR_HOME"
echo "Backup Dir : $BACKUP_DIR"
echo "Mods       : ${#MODS[@]} installed"
echo "Layout     : main-custom.json"
echo "Keys       : $([ "$SKIP_KEYS" -eq 0 ] && echo "updated (previous backed up)" || echo "kept existing")"
echo "Mermaid    : $MERMAID_STATUS"
echo "HerdrNotify: $NOTIFY_STATUS"
echo "Verify     : $CLI_STATUS"
echo ""
echo "Tip: Press Cmd+Shift+M (or click 'Mods' in the sidebar) to open Mod Manager."
