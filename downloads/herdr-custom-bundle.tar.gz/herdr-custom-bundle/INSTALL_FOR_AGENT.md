# Herdr-app 自定义套件安装指南（供 AI Agent 执行）

这个压缩包包含一套已经调试好的 Herdr-app 自定义 Mods、布局、快捷键与辅助组件。你可以把本文件直接交给你的 AI Agent（Codex / Claude Code / Antigravity），让它帮你完成安装和校验。

## 包内内容

- `mods/`：16 个 Mod（15 个自定义 + 1 个扩展后的 `workspace-chrome`）：
  - `mod-manager`：Mod 管理面板（`⌘⇧M` 打开，支持启停右侧面板、控制右上角面板按钮是否显示文字、展示当前 `keys.json` 快捷键绑定）
  - `tabs-custom`：增强标签栏 + 右上角面板按钮（支持图标/文字切换与 Asks 角标）
  - `spaces-custom` / `spaces-custom-menu` / `space-emoji-picker`：工作区列表、右键菜单与 Emoji 选择
  - `files-custom` / `files-custom-menu` / `files-custom-rename`：文件树面板与操作菜单
  - `changes-custom` / `changes-diff-fullscreen`：Git 变更面板与全屏 Diff 查看
  - `subagent-tree`：Multi-Agent / Subagent 树形状态面板
  - `mermaid-viewer`：自动提取并渲染终端/文档里的 Mermaid 图表
  - `asks`：Agent 提问聚合面板
  - `open-default`：点击终端内 `.md` / `.html` 路径时用系统默认应用打开
  - `workspace-helper`：面板快捷键调度、Asks 后台引擎与系统通知桥接
  - `workspace-chrome`：在左侧栏底部增加 `Mods` 入口
- `layouts/main-custom.json`：配套的主布局文件
- `keys.json`：配套快捷键配置
- `data/workspace-helper/`：macOS 原生通知辅助程序源码（`HerdrNotify.swift`）、清单、图标
- `data/mermaid-viewer/`：Mermaid 渲染服务源码（需 `bun install`）
- `install.sh`：一键安装与校验脚本

---

## 前置条件

1. 同事本机已安装并至少启动过一次官方 `Herdr.app`（存在 `~/.config/herdr-app/` 目录）。
2. 可选依赖：
   - `bun`：用于安装 `mermaid-viewer` 依赖（没有则无法渲染 Mermaid 图表，可先跳过）。
   - Xcode Command Line Tools（`swiftc`）：用于在 macOS 上编译 `~/Applications/HerdrNotify.app`（没有可在 Mod Manager 中关闭桌面通知开关）。

---

## 给 Agent 的执行步骤

请按以下顺序在用户的终端中执行并汇报结果：

1. **确认基础目录存在**
   - 检查 `${HERDR_APP_HOME:-$HOME/.config/herdr-app}` 是否存在；若不存在请提示用户先安装并打开一次官方 `Herdr.app`。

2. **确认 `keys.json` 处理方式**
   - 如果用户已经自定义过 `~/.config/herdr-app/keys.json`，先向用户展示差异或询问是要**备份后覆盖**还是**合并**；如果用户没有个性化修改（或同意覆盖），直接运行 `install.sh`（它会自动备份原 `keys.json` 到 `~/.config/herdr-app/.backup-<timestamp>/`）。
   - 如果需要保留用户原有的 `keys.json`，可运行 `./install.sh --skip-keys`，再手动把包内 `keys.json` 中的 `workspace-helper.*` 和 `mod.open:mod-manager` 等快捷键合并进去。

3. **执行安装脚本**
   ```bash
   chmod +x ./install.sh
   ./install.sh
   ```
   - 如本机未安装 `bun`，可加上 `--skip-mermaid`（或先提醒用户安装 `bun` 后再在 `~/.config/herdr-app/data/mermaid-viewer` 下执行 `bun install`）。
   - 如本机未安装 `swiftc`，可加上 `--skip-notify`。

4. **切换布局并验证**
   - 确认 `herdr-app` 在运行后执行：
     ```bash
     herdr-app do layout.switch --name main-custom
     herdr-app status
     ```
   - 确认 `layout` 为 `"main-custom"` 且 `errors` 为空数组 `[]`。
   - 如果刚才 `Herdr.app` 尚未打开或界面未刷新，请启动/重启一次 `Herdr.app`。

5. **向用户说明如何使用**
   - 按 `⌘⇧M`（或点击左侧栏底部 `Mods`）打开 **Mod Manager**。
   - 在 Mod Manager 中可：
     - 启停右侧 5 个功能面板（Files / Changes / Subagents / Mermaid / Asks）；
     - 开关 **“右上角面板按钮显示文字”**（控制右上角面板按钮仅显示图标还是图标+文字）；
     - 开关桌面通知和默认应用打开链接；
     - 在下方 **“快捷键绑定”** 区域直接查看当前生效的快捷键。
